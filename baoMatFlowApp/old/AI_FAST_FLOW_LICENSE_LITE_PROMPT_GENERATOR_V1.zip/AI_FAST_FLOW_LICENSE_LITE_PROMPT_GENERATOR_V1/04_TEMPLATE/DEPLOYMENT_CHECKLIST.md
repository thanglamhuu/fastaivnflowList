Checklist:

[ ] Create Config
[ ] Create Machine ID
[ ] Create Verifier
[ ] Create Manager
[ ] License Gate
[ ] Startup Check
[ ] Feature Guard
[ ] Test Token