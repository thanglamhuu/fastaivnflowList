# STEP 00 LOCK

Dán trước khi tạo License Core.

Bạn đang triển khai:

AI FAST FLOW LICENSE LITE V1

Không tạo hệ thống License mới.

Không dùng:
- Firebase
- API
- Server
- JWT
- Private Key

Chuẩn:

ECDSA
P-256
SHA-256

Flow App chỉ verify bằng Public Key.