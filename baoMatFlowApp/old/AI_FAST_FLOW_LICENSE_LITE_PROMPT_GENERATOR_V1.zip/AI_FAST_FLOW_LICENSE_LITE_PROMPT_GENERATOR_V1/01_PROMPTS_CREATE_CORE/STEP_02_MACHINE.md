# STEP 02 CREATE MACHINE

Tạo file:

src/license/aifastMachine.ts

Function:

getOrCreateMachineId()

Yêu cầu:

- Tạo UUID lần đầu.
- Lưu localStorage.
- Trả về machineId cố định cho thiết bị.

Không gọi server.