# STEP 04 CREATE MANAGER

Tạo file:

src/license/aifastLicenseManager.ts

Public API:

activateLicense(token)

checkLicense()

getLicenseStatus()

Nhiệm vụ:

- Lưu token.
- Gọi verifier.
- Trả kết quả cho UI.

UI không gọi crypto trực tiếp.