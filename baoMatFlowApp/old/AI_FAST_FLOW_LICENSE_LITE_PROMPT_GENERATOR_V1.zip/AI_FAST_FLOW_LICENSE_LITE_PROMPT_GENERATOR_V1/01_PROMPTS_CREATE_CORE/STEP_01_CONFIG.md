# STEP 01 CREATE CONFIG

Tạo file:

src/license/aifastLicenseConfig.ts

Nội dung:

Chứa:

PROJECT_ID

APP_NAME

PUBLIC_JWK

ISSUER

AUDIENCE

Không chứa private key.

Đây là file duy nhất thay đổi giữa các Flow App.