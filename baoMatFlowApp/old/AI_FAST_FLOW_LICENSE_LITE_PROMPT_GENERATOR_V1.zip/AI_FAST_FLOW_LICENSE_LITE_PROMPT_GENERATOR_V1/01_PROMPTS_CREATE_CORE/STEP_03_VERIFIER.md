# STEP 03 CREATE VERIFIER

Tạo file:

src/license/aifastLicenseVerifier.ts

Function:

verifyLicense(token)

Luồng:

1. Split token:
payload.signature

2. Verify signature bằng Public Key.

3. Decode payload.

4. Kiểm tra:

payload.projectId === PROJECT_ID

payload.machineId === currentMachineId

payload.expiresAt > currentTime

5. Return:

{
 valid:true
}

hoặc:

{
 valid:false,
 reason:"..."
}

Không parse payload trước khi verify signature.