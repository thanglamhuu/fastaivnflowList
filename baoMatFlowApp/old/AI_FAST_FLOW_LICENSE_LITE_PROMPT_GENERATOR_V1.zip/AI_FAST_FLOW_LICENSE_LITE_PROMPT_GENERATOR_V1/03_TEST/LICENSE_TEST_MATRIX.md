# Test Matrix

Test:

1. Token đúng
Expected:
PASS

2. Sai Project ID
Expected:
FAIL

3. Sai Machine ID
Expected:
FAIL

4. Hết hạn
Expected:
FAIL

5. Sai chữ ký
Expected:
FAIL