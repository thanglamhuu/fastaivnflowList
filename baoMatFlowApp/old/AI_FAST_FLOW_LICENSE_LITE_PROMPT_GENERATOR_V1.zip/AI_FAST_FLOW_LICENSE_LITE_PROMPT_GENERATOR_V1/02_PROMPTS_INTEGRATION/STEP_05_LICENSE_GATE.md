# STEP 05 LICENSE GATE

Tạo màn hình nhập License.

Hiển thị:

- App Name
- Machine ID
- License Token

Button:

Activate

Gọi:

activateLicense(token)