# STEP 07 FEATURE GUARD

Các tính năng cần khóa:

AI Generate
Export
Premium Feature

Trước khi chạy:

checkLicense()

Nếu false:
block action.