# STEP 06 STARTUP PROTECTION

Khi mở App:

checkLicense()

Nếu valid:

Mở toàn bộ tính năng.

Nếu invalid:

Hiện License Gate.

Không hiển thị chức năng trước khi kiểm tra.