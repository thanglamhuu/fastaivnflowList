# Target Structure

src/license/

aifastLicenseConfig.ts
- App config
- Public Key
- Project ID

aifastMachine.ts
- Generate Machine ID

aifastLicenseVerifier.ts
- Verify token

aifastLicenseManager.ts
- App interface