# AI FAST FLOW LICENSE LITE V1

Mục tiêu:
Thiết kế License Core phù hợp cho Google Flow App.

Flow App chỉ làm nhiệm vụ:

1. Nhận License Token.
2. Verify chữ ký bằng Public Key.
3. Kiểm tra:
- Project ID
- Machine ID
- Expiry
4. Nếu hợp lệ:
- mở tính năng.

Không triển khai:
- Firebase License Check
- Backend
- Private Key
- License Database
- Migration phức tạp

Luồng:

ADMIN:
Private Key
 -> Sign Token

FLOW APP:
Token
 -> Verify Signature
 -> Check Payload
 -> Unlock Feature