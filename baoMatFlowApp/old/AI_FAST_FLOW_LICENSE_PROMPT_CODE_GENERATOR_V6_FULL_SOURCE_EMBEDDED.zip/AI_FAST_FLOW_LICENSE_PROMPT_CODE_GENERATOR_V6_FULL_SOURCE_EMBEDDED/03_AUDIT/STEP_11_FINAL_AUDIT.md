Audit:

PASS:

- Không private key
- Không Firebase verify
- Không duplicate crypto
- Token Admin verify OK
- Token Flow verify OK