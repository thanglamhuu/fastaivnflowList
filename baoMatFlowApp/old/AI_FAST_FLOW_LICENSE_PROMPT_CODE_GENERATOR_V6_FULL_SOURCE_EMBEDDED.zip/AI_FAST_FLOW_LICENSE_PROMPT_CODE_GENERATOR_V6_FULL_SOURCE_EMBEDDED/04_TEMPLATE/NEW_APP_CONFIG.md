APP_NAME:

PROJECT_ID:

SIGNING_KEY_ID:

PUBLIC_JWK:

Chỉ thay các giá trị này.