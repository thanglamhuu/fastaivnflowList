# AI FAST FLOW LICENSE PROMPT CODE GENERATOR V6

V6 là phiên bản FULL SOURCE EMBEDDED.

Mục tiêu:
- Prompt chứa trực tiếp code TypeScript canonical.
- Google Flow chỉ tạo file theo source được cung cấp.
- Không để AI tự implement crypto.

Nguyên tắc:
- Copy nguyên source.
- Không refactor.
- Không đổi function.
- Không đổi protocol.

Flow App mới chỉ thay:
APP_NAME
PROJECT_ID
SIGNING_KEY_ID
PUBLIC_JWK