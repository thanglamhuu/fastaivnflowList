# INSTALL ORDER

STEP 00:
Khóa protocol.

STEP 01-07:
Tạo toàn bộ License Core.

STEP 08:
License Gate.

STEP 09:
Startup Protection.

STEP 10:
Action Guard.

STEP 11:
Audit.