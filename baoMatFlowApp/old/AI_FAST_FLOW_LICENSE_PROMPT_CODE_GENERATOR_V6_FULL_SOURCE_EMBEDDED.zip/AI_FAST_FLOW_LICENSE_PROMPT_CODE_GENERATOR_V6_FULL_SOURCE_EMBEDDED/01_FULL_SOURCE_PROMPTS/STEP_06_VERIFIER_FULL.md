# CREATE FILE

src/license/aifastLicenseVerifier.ts

verifyLicenseToken phải:

1. split token bằng dấu .
2. verify signature
3. decode payload
4. validate:
- version
- issuer
- audience
- projectId
- machineId
- expiresAt

Không parse payload trước signature.