# CREATE FILE

src/license/aifastLicenseTypes.ts

Dùng chính xác:

```typescript
export interface SignedLicensePayloadV1 {
  version:number;
  keyId:string;
  issuer:string;
  audience:string;
  licenseId:string;
  projectId:string;
  machineId:string;
  licensedEmailMasked:string;
  planLabel:string;
  issuedAt:number;
  expiresAt:number;
}

export type LicenseVerifyResult =
 | {valid:true; payload:SignedLicensePayloadV1}
 | {valid:false; code:string; message:string};
```

Không thay đổi schema.