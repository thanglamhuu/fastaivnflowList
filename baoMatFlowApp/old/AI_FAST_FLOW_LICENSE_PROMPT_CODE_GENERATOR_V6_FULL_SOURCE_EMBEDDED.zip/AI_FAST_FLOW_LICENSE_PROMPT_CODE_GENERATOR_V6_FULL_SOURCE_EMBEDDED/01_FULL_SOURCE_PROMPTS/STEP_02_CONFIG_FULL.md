# CREATE FILE

src/license/aifastLicenseConfig.ts

```typescript
export const LICENSE_CONFIG = {
 appName:"",
 projectId:"",
 tokenVersion:1,
 issuer:"aifast-license-admin",
 audience:"aifast-flow-offline",
 signingKeyId:""
} as const;

export const LICENSE_PUBLIC_JWK: JsonWebKey = {};
```

Chỉ thay giá trị config.