# CREATE FILE

src/license/aifastLicenseCrypto.ts

Canonical source contract:

```typescript
export async function verifySignature(
 publicKey: CryptoKey,
 signature: Uint8Array,
 payloadPart: string
): Promise<boolean> {

 return await crypto.subtle.verify(
  {
   name:"ECDSA",
   hash:"SHA-256"
  },
  publicKey,
  signature,
  new TextEncoder().encode(payloadPart)
 );
}
```

Không đổi signing input.