# CREATE FILE

src/license/aifastLicenseMachine.ts

```typescript
export function getOrCreateMachineId(){

 const key='aifast.machineId';

 let id=localStorage.getItem(key);

 if(!id){
  id=crypto.randomUUID();
  localStorage.setItem(key,id);
 }

 return id;
}
```