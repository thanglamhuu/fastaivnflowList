# STEP 00 PROTOCOL LOCK

Đây là AI FAST LICENSE CORE V1 canonical source.

Không được:
- tự viết lại
- tối ưu
- đổi thuật toán
- đổi API

Protocol:

ECDSA
P-256
SHA-256

Token:

payloadPart.signaturePart

Verify input:

UTF8(payloadPart)