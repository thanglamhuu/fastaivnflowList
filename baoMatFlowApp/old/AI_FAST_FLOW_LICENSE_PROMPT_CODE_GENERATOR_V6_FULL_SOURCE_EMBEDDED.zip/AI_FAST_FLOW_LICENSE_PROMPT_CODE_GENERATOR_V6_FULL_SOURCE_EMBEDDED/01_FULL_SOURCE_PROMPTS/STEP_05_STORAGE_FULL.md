# CREATE FILE

src/license/aifastLicenseStorage.ts

```typescript
const KEY='aifast.licenseToken';

export function getLicenseToken(){
 return localStorage.getItem(KEY);
}

export function saveLicenseToken(token:string){
 localStorage.setItem(KEY,token);
}

export function removeLicenseToken(){
 localStorage.removeItem(KEY);
}
```