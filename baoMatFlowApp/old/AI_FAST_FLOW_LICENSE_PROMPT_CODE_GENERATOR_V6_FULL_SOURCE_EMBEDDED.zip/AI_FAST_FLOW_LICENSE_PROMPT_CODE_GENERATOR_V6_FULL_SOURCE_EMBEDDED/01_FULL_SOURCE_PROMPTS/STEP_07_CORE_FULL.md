# CREATE FILE

src/license/aifastLicenseCore.ts

Public API:

```typescript
export {
 activateLicense,
 restoreLicense,
 validateLicenseAccess,
 getMachineId
}
```

Không cho component gọi crypto.