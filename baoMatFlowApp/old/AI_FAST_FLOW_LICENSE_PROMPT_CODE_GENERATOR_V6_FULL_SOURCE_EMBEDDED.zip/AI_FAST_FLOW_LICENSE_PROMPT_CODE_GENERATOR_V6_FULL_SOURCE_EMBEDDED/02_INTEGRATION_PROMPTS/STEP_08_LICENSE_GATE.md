Tạo License Gate UI.

Gọi:

activateLicense()

Hiển thị:
- App Name
- Machine ID
- License input