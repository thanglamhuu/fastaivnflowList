Startup bắt buộc:

restoreLicense()

valid:
render app

invalid:
License Gate