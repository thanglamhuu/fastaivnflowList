Các chức năng AI:

Generate
Analyze
Create
Export

phải gọi:

validateLicenseAccess()