# STEP FLOW 4 — License Gate UI

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 4 – CREATE LICENSE ACTIVATION GATE

Mục tiêu:
Nếu chưa có License hợp lệ,
không cho user vào Main App.

Không thay đổi giao diện chức năng chính của Main App.

==================================================
1. LICENSE GATE
==================================================

Tạo component:

LicenseGate

Style:
phù hợp dark theme hiện tại của App.

==================================================
2. HIỂN THỊ
==================================================

Title:

Kích hoạt ứng dụng

Subtitle:

Nhập License Key được cấp để tiếp tục sử dụng.

Hiển thị:

Ứng dụng
{{APP_NAME}}

Project ID
{{PROJECT_ID}}

Machine ID
[current machine id]

Button:

SAO CHÉP MACHINE ID

Instruction:

"Gửi Machine ID này cho Admin để được cấp License."

==================================================
3. TOKEN INPUT
==================================================

Label:

License Key

Dù kỹ thuật là Signed Token,
UI vẫn dùng tên License Key để user dễ hiểu.

Textarea hoặc input hỗ trợ chuỗi dài.

Placeholder:

Dán License Key tại đây...

==================================================
4. CHECK BUTTON
==================================================

Button:

KIỂM TRA LICENSE

Khi click:

1. trim input
2. verifyLicenseToken()
3. nếu valid:
   saveLicenseToken()
4. gọi onVerified(payload)
5. vào Main App

==================================================
5. ERROR MESSAGE
==================================================

Map lỗi:

INVALID_FORMAT
→ "Định dạng License không hợp lệ."

INVALID_SIGNATURE
→ "License không hợp lệ."

PROJECT_MISMATCH
→ "License không thuộc ứng dụng này."

DEVICE_MISMATCH
→ "License được cấp cho thiết bị khác."

EXPIRED
→ "License đã hết hạn."

INVALID_ISSUER / INVALID_AUDIENCE
→ "License không hợp lệ."

Không hiển thị technical crypto detail.

==================================================
6. LICENSE INFO
==================================================

Sau verify thành công có thể giữ payload trong memory.

Payload có:

licensedEmailMasked
planLabel
expiresAt

Không cho user sửa.

==================================================
7. OUTPUT
==================================================

Báo:

1. Component tạo
2. Error mapping
3. Machine ID copy action
4. Token save flow
```
