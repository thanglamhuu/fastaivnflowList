# STEP FLOW 7 — Runtime Expiration Monitor

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 7 – RUNTIME EXPIRATION MONITOR

Mục tiêu:
License hết hạn trong khi App vẫn đang mở
thì App phải khóa lại.

==================================================
1. EXPIRY MONITOR
==================================================

Khi License valid:

đọc payload.expiresAt

Tạo lightweight timer.

Không cần verify signature mỗi giây.

Có thể kiểm tra current Unix seconds
theo interval khoảng:

30 giây
hoặc 60 giây.

==================================================
2. WHEN EXPIRED
==================================================

Nếu:

currentTime >= expiresAt

thì:

clearStoredLicenseToken()

clear license state

set App status invalid

render LicenseGate

Không tiếp tục cho chạy protected operation mới.

==================================================
3. CLEANUP
==================================================

Clear interval khi:

component unmount

License thay đổi

License invalid

==================================================
4. LICENSE STATUS UI
==================================================

Nếu App có Settings/About,
hiển thị:

Cấp cho:
licensedEmailMasked

Gói:
planLabel

Hết hạn:
formatted expiresAt

Trạng thái:
Đang hoạt động

Nếu còn <= 7 ngày:

hiển thị:

License sắp hết hạn.

==================================================
5. OUTPUT
==================================================

Báo:

1. Interval
2. Expiry handling
3. Cleanup
4. License info location
```
