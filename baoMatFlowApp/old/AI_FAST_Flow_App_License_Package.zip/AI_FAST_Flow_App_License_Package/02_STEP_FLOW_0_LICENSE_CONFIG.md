# STEP FLOW 0 — Chuẩn hóa License Config

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 0 – PREPARE REUSABLE LICENSE CONFIGURATION

BỐI CẢNH:

Ứng dụng này chạy bên trong Google Flow sandbox.

Flow App KHÔNG được kết nối Firebase/Firestore.

Flow App KHÔNG có backend.

Flow App KHÔNG đăng nhập Firebase.

License sẽ được xác minh hoàn toàn offline bằng:

ECDSA
P-256
SHA-256
Web Crypto API

Admin AI Fast sẽ tạo Signed License Token bên ngoài Flow App.

Không sửa chức năng chính của App trong step này.

==================================================
1. TẠO CONFIG RIÊNG CHO APP
==================================================

Tạo file:

src/config/licenseConfig.ts

hoặc vị trí tương đương theo cấu trúc project hiện tại.

Config gồm:

export const LICENSE_CONFIG = {
  projectId: "{{PROJECT_ID}}",
  appName: "{{APP_NAME}}",

  tokenVersion: 1,

  issuer: "aifast-license-admin",

  audience: "aifast-flow-offline"
};

PROJECT_ID phải là ID cố định của App.

User không được sửa projectId qua UI.

==================================================
2. PUBLIC KEY
==================================================

Chuẩn bị constant:

LICENSE_PUBLIC_JWK

Public Key này sẽ giống nhau cho tất cả Flow App sử dụng hệ License AI Fast.

Chưa cần nhập Private Key.

Flow App TUYỆT ĐỐI không được chứa:

privateJwk
Private Key
Firebase Admin Credential
serviceAccount
signing secret

Chỉ Public Key được phép tồn tại trong Flow App.

==================================================
3. NAMESPACE STORAGE
==================================================

Mọi local storage key phải chứa projectId để các App không đè dữ liệu lên nhau.

Ví dụ:

aifast.{projectId}.machineId

aifast.{projectId}.licenseToken

Không sử dụng key chung chung như:

license
machineId
license_key

==================================================
4. KHÔNG LÀM
==================================================

Chưa tạo LicenseGate.

Chưa verify Token.

Chưa khóa Main App.

Chưa sửa chức năng App.

Chỉ tạo config chuẩn để các step tiếp theo sử dụng.

==================================================
5. OUTPUT
==================================================

Sau khi hoàn thành báo:

1. File config
2. Project ID
3. App Name
4. Token Version
5. Issuer
6. Audience
7. Storage namespace
```
