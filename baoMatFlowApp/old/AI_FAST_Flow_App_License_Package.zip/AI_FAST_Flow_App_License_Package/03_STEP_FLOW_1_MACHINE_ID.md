# STEP FLOW 1 — Tạo Machine ID

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 1 – IMPLEMENT MACHINE ID

Chỉ thực hiện Machine ID.

Không làm Token Verification trong step này.

==================================================
1. MACHINE ID
==================================================

Tạo service:

src/services/machineIdService.ts

hoặc vị trí tương đương.

Function chính:

getOrCreateMachineId()

==================================================
2. LOGIC
==================================================

Storage key phải sử dụng projectId:

aifast.{PROJECT_ID}.machineId

Khi function chạy:

1. Đọc Machine ID hiện tại từ persistent local storage.

2. Nếu tồn tại:
return đúng ID cũ.

3. Nếu chưa tồn tại:
tạo bằng:

crypto.randomUUID()

4. Lưu persistent.

5. Return ID.

Không tạo ID mới mỗi lần reload.

==================================================
3. SAFE STORAGE
==================================================

Tạo wrapper an toàn:

safeStorage.getItem()
safeStorage.setItem()
safeStorage.removeItem()

Dùng try/catch vì Flow App có thể chạy trong sandboxed iframe.

Nếu localStorage không khả dụng:
phải trả lỗi rõ ràng thay vì crash toàn App.

==================================================
4. DISPLAY FORMAT
==================================================

Internal Machine ID giữ nguyên UUID đầy đủ.

Ví dụ:

4b89f6cc-4d16-48ab-b709-xxxxxxxxxxxx

UI có thể hiển thị đầy đủ.

Có button:

Sao chép Machine ID

User sẽ gửi Machine ID này cho Admin để Admin cấp Token.

==================================================
5. KHÔNG LÀM
==================================================

Không dùng:

MAC Address
CPU Serial
Mainboard Serial
Disk Serial
IMEI

Không dùng fingerprinting phức tạp.

Không Firebase.

Không external request.

==================================================
6. OUTPUT
==================================================

Báo:

1. Machine ID function
2. Storage key
3. Cách persist
4. Có tạo lại ID khi reload không
```
