# STEP FLOW 6 — Action-Level License Guard

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 6 – ADD ACTION LEVEL LICENSE GUARD

Mục tiêu:
Không chỉ kiểm tra License lúc App khởi động.

Các chức năng AI quan trọng phải kiểm tra License trước khi chạy.

==================================================
1. CREATE VALIDATE ACCESS
==================================================

Tạo helper:

validateLicenseAccess()

Logic:

1. đọc License Token đã lưu
2. verifyLicenseToken()
3. nếu valid:
return payload
4. nếu expired/invalid:
clear Token nếu cần
throw LicenseAccessError

==================================================
2. APPLY TO PROTECTED ACTIONS
==================================================

Tìm các action quan trọng như:

Generate
Analyze
Create Script
Create Storyboard
Generate Image
Generate Video
Batch Generate
Export nếu phù hợp

Không cần guard các action UI đơn giản như:

đổi tab
mở modal
nhập text

Trước protected operation:

await validateLicenseAccess()

Nếu fail:
không chạy operation.

Chuyển UI về LicenseGate hoặc hiển thị yêu cầu kích hoạt lại.

==================================================
3. CENTRALIZE
==================================================

Không copy logic verify vào từng button.

Tất cả phải dùng cùng:

validateLicenseAccess()

==================================================
4. OUTPUT
==================================================

Báo:

1. Protected actions
2. Helper được dùng
3. Có action AI quan trọng nào chưa guard không
```
