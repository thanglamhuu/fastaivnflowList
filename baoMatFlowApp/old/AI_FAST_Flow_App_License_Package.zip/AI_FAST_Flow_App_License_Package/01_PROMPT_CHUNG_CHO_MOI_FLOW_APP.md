# PROMPT CHUNG CHO MỌI FLOW APP MỚI

```text
QUAN TRỌNG:

Không tự sáng tạo một cơ chế License mới.

App này phải sử dụng đúng:

AI Fast Offline License Protocol V1

Token format:
payloadPart.signaturePart

Algorithm:
ECDSA

Curve:
P-256

Hash:
SHA-256

Signing / verification input:
UTF8(payloadPart)

Issuer:
aifast-license-admin

Audience:
aifast-flow-offline

Token Version:
1

Flow App:
- không Firebase
- không Firestore
- không backend
- không external License API
- chỉ Public Key
- không Private Key

Chỉ thay đổi:

PROJECT_ID
APP_NAME
```

## Cách dùng

Trước khi chạy các Step, thay:

```text
{{PROJECT_ID}}
{{APP_NAME}}
```

bằng thông tin thật của Flow App hiện tại.
