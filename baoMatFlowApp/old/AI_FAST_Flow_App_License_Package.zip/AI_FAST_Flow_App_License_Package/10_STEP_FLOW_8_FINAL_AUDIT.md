# STEP FLOW 8 — Final Security Audit

```text
FLOW APP OFFLINE LICENSE
FINAL SECURITY AUDIT

KHÔNG thêm feature mới.

Kiểm tra implementation hiện tại.

==================================================
TEST 1
==================================================

Không có License Token.

Expected:
Main App không mở.

==================================================
TEST 2
==================================================

Token đúng chữ ký,
đúng Project,
đúng Machine,
còn hạn.

Expected:
PASS.

==================================================
TEST 3
==================================================

Sửa expiresAt trong payload nhưng giữ signature cũ.

Expected:
INVALID_SIGNATURE.

==================================================
TEST 4
==================================================

Sửa machineId trong payload.

Expected:
INVALID_SIGNATURE.

==================================================
TEST 5
==================================================

Token App A dùng App B.

Expected:
PROJECT_MISMATCH.

==================================================
TEST 6
==================================================

Token Machine A dùng Machine B.

Expected:
DEVICE_MISMATCH.

==================================================
TEST 7
==================================================

expiresAt đã qua.

Expected:
EXPIRED.

==================================================
TEST 8
==================================================

issuer sai.

Expected:
INVALID_ISSUER.

==================================================
TEST 9
==================================================

audience sai.

Expected:
INVALID_AUDIENCE.

==================================================
TEST 10
==================================================

version sai.

Expected:
UNSUPPORTED_VERSION.

==================================================
TEST 11
==================================================

Search source code.

Không được tồn tại:

Firebase
Firestore
firestore.googleapis.com
Private Key
privateJwk
serviceAccount
Admin credential

trong License implementation.

==================================================
TEST 12
==================================================

Kiểm tra Public Key.

Expected:
chỉ có PUBLIC JWK.

==================================================
TEST 13
==================================================

Reload App.

Expected:
Stored Token được verify lại.
Không chỉ dựa vào isLicensed boolean.

==================================================
TEST 14
==================================================

License hết hạn khi App đang mở.

Expected:
App tự khóa lại.

==================================================
TEST 15
==================================================

Protected AI action khi License invalid.

Expected:
Không chạy.

==================================================
OUTPUT
==================================================

Trả bảng:

TEST
PASS / FAIL / NEEDS FIX
DETAIL
```
