# AI FAST Offline License Protocol V1
## Mô tả luồng triển khai và ý nghĩa từng file

Tài liệu này chỉ mô tả cơ chế hoạt động của hệ thống License cho Flow App và vai trò của từng file trong gói triển khai.
**Không chứa prompt để đưa vào AI Studio.**

---

## 1. Mục tiêu kiến trúc

Mục tiêu là dùng một chuẩn License Offline dùng chung cho nhiều Flow App.

Mỗi Flow App chỉ cần có:
- `PROJECT_ID` riêng
- `APP_NAME` riêng
- `Machine ID` riêng của từng installation
- cùng một `Public Key` của hệ thống AI Fast

Admin AI Fast giữ Private Key và dùng Private Key để ký License Token.
Flow App không có Private Key và không kết nối Firebase để kiểm tra License.

Flow App xác minh Token hoàn toàn offline bằng Web Crypto API.

---

## 2. Luồng tổng thể

```text
ADMIN AI FAST
     │
     │ tạo payload License
     │ ký bằng Private Key
     ▼
SIGNED LICENSE TOKEN
     │
     │ user copy/paste
     ▼
FLOW APP
     │
     ├─ đọc PROJECT_ID
     ├─ đọc Machine ID
     ├─ đọc Public Key
     └─ verify chữ ký offline
            │
            ├─ Signature đúng?
            ├─ Token Version đúng?
            ├─ Issuer đúng?
            ├─ Audience đúng?
            ├─ Project đúng?
            ├─ Machine đúng?
            └─ Chưa hết hạn?
                    │
                    ▼
                  MỞ APP
```

---

## 3. Chuẩn kỹ thuật dùng chung

Tất cả Flow App dùng cùng chuẩn:

- Token Version: `1`
- Issuer: `aifast-license-admin`
- Audience: `aifast-flow-offline`
- Algorithm: `ECDSA`
- Curve: `P-256`
- Hash: `SHA-256`
- Token format: `payloadPart.signaturePart`
- Admin ký trên: `UTF8(payloadPart)`
- Flow App verify trên: `UTF8(payloadPart)`

Cấu trúc token:

```text
payloadJson
    ↓ JSON.stringify
payloadBytes
    ↓ UTF8
payloadPart
    ↓ Base64URL
signingInput = UTF8(payloadPart)
    ↓ ECDSA P-256 SHA-256
signature
    ↓ Base64URL
payloadPart.signaturePart
```

---

## 4. Payload License

Payload chuẩn V1 gồm:

```text
version
keyId
issuer
audience

licenseId
projectId
machineId

licensedEmailMasked
planLabel

issuedAt
expiresAt
```

Ý nghĩa:

- `version`: phiên bản protocol.
- `keyId`: mã cặp Signing Key đã dùng để ký.
- `issuer`: xác định token do hệ thống AI Fast phát hành.
- `audience`: xác định token dành cho Flow App offline.
- `licenseId`: mã License trong hệ quản trị.
- `projectId`: khóa token vào đúng Flow App.
- `machineId`: khóa token vào đúng installation.
- `licensedEmailMasked`: email đã che bớt để hiển thị cho user.
- `planLabel`: tên gói, ví dụ 1 tháng / 3 tháng / 12 tháng.
- `issuedAt`: thời điểm phát hành theo Unix seconds.
- `expiresAt`: thời điểm hết hạn theo Unix seconds.

---

## 5. Machine ID

Mỗi installation của Flow App tự tạo Machine ID bằng:

```text
crypto.randomUUID()
```

Machine ID được lưu persistent theo namespace có `PROJECT_ID`.

Ví dụ:

```text
aifast.{PROJECT_ID}.machineId
```

Machine ID không dùng MAC Address, CPU Serial hay các fingerprint phần cứng phức tạp.

Khi user cần mua License:
1. mở Flow App;
2. copy Machine ID;
3. gửi cho Admin;
4. Admin phát hành token cho đúng `PROJECT_ID + Machine ID`.

---

## 6. Token storage

Sau khi user nhập Token và Token verify thành công, Flow App mới lưu Token local.

Storage key:

```text
aifast.{PROJECT_ID}.licenseToken
```

Không lưu một biến đơn giản như:

```text
isLicensed = true
```

để làm bằng chứng License.

Mỗi lần mở App, Token phải được verify lại.

---

## 7. Các lớp kiểm tra License trong Flow App

### Lớp 1 — Startup Gate

Khi App khởi động:
- chưa có token → hiện License Gate;
- có token → verify;
- hợp lệ → mới render Main App;
- không hợp lệ / hết hạn → không render Main App.

### Lớp 2 — Action Guard

Các thao tác quan trọng như:
- Generate
- Analyze
- Create Script
- Create Storyboard
- Generate Image
- Generate Video
- Batch Generate
- Export nếu cần

phải gọi lại helper kiểm tra quyền trước khi thực thi.

### Lớp 3 — Runtime Expiration

Nếu App đang mở và License hết hạn trong lúc user vẫn dùng:
- xóa token local;
- chuyển trạng thái License về invalid;
- đưa user về License Gate;
- không cho chạy action mới.

---

## 8. Giới hạn của cơ chế Offline License

Vì Flow App xác minh hoàn toàn client-side và không có backend:

- Admin không thể revoke ngay một token đã phát hành.
- Token cũ có thể tiếp tục chạy đến `expiresAt`.
- Gia hạn cần phát hành token mới.
- Đổi Machine cần phát hành token mới.
- Người dùng có kỹ thuật cao vẫn có thể sửa client code nếu có toàn quyền đối với source/runtime.

Cơ chế này nhằm:
- chống sửa nội dung token;
- chống sửa thời hạn;
- chống mang token sang App khác;
- chống dùng token trên Machine khác;
- quản lý thời hạn;
- dùng chung một Admin cho nhiều Flow App.

---

## 9. Trình tự triển khai cho mỗi Flow App

```text
STEP FLOW 0
License Config
   ↓
STEP FLOW 1
Machine ID
   ↓
STEP FLOW 2
Signed Token Verifier
   ↓
STEP FLOW 3
Token Storage / Restore
   ↓
STEP FLOW 4
License Gate UI
   ↓
STEP FLOW 5
Protect App Startup
   ↓
STEP FLOW 6
Action-Level Guard
   ↓
STEP FLOW 7
Runtime Expiration Monitor
   ↓
STEP FLOW 8
Final Security Audit
```

Nên chạy từng bước riêng biệt và kiểm tra xong mới chuyển bước tiếp theo.

---

## 10. Ý nghĩa từng file trong ZIP

### `00_MO_TA_LUONG_VA_CAU_TRUC.md`
File hiện tại. Chỉ mô tả kiến trúc, luồng hoạt động, dữ liệu và vai trò của các bước. Không chứa prompt.

### `01_PROMPT_CHUNG_CHO_MOI_FLOW_APP.md`
Prompt nền dùng chung cho mọi Flow App mới. Mục đích là khóa AI Studio vào đúng `AI Fast Offline License Protocol V1`, tránh AI tự sáng tạo cơ chế khác.

### `02_STEP_FLOW_0_LICENSE_CONFIG.md`
Tạo cấu hình License riêng cho App: Project ID, App Name, Version, Issuer, Audience, Public Key placeholder, namespace storage.

### `03_STEP_FLOW_1_MACHINE_ID.md`
Tạo Machine ID ổn định cho từng installation bằng `crypto.randomUUID()` và lưu persistent.

### `04_STEP_FLOW_2_TOKEN_VERIFIER.md`
Tạo phần crypto verifier. Đây là file quan trọng nhất ở Flow App vì phải verify đúng byte contract mà Admin đã ký.

### `05_STEP_FLOW_3_TOKEN_STORAGE_RESTORE.md`
Quản lý việc lưu Token sau khi verify thành công và restore/verify lại Token khi mở App.

### `06_STEP_FLOW_4_LICENSE_GATE_UI.md`
Tạo màn hình kích hoạt License cho người dùng: App Name, Project ID, Machine ID, ô nhập License Key, error messages.

### `07_STEP_FLOW_5_PROTECT_STARTUP.md`
Khóa Main App tại startup. Main App không được render trước khi License được xác minh.

### `08_STEP_FLOW_6_ACTION_GUARD.md`
Thêm guard cho các action AI quan trọng để không chỉ kiểm tra License một lần lúc mở App.

### `09_STEP_FLOW_7_RUNTIME_EXPIRATION.md`
Theo dõi thời hạn trong lúc App đang mở. Nếu hết hạn thì khóa lại App.

### `10_STEP_FLOW_8_FINAL_AUDIT.md`
Bộ kiểm thử cuối cùng nhằm xác nhận signature, project binding, machine binding, expiry và các yêu cầu bảo mật đều hoạt động.

---

## 11. Các giá trị riêng và dùng chung

### Dùng chung cho mọi App

```text
TOKEN_VERSION = 1
ISSUER = aifast-license-admin
AUDIENCE = aifast-flow-offline
ALGORITHM = ECDSA
CURVE = P-256
HASH = SHA-256
TOKEN FORMAT = payloadPart.signaturePart
SIGN / VERIFY INPUT = UTF8(payloadPart)
PUBLIC KEY = Public Signing Key hiện tại của AI Fast
```

### Riêng cho từng App

```text
PROJECT_ID
APP_NAME
```

Machine ID sẽ tự sinh theo từng installation.

---

## 12. Checklist sau khi triển khai

- Có `PROJECT_ID` riêng.
- Có `APP_NAME`.
- Dùng cùng Public JWK AI Fast.
- Token Version = 1.
- Issuer đúng.
- Audience đúng.
- ECDSA P-256 SHA-256.
- Verify `UTF8(payloadPart)`.
- Machine ID persistent.
- Storage namespace theo Project ID.
- Không Firebase trong License logic.
- Không Private Key trong Flow App.
- Startup bị khóa trước verify.
- AI actions có guard.
- Runtime expiration hoạt động.
- Final Security Audit PASS.
