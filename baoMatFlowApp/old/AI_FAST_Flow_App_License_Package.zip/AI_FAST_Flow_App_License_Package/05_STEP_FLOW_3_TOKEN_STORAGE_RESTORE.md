# STEP FLOW 3 — Token Storage & Restore

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 3 – LICENSE TOKEN STORAGE AND RESTORE

Chỉ bổ sung lưu và restore Token.

Không sửa Main App logic trong step này.

==================================================
1. STORAGE KEY
==================================================

Sử dụng namespace theo Project ID:

aifast.{PROJECT_ID}.licenseToken

==================================================
2. FUNCTIONS
==================================================

Tạo:

getStoredLicenseToken()

saveLicenseToken(token)

clearStoredLicenseToken()

==================================================
3. SAVE RULE
==================================================

KHÔNG lưu Token ngay khi user nhập.

Chỉ gọi:

saveLicenseToken()

SAU KHI:

verifyLicenseToken(token)

trả về:

valid: true

==================================================
4. RESTORE
==================================================

Tạo:

restoreLicense()

Logic:

1. Load stored Token

2. Nếu không có:
return NO_LICENSE

3. Verify lại bằng:

verifyLicenseToken()

4. Nếu valid:
return license payload

5. Nếu EXPIRED:
clearStoredLicenseToken()

6. Nếu INVALID_SIGNATURE / PROJECT_MISMATCH / DEVICE_MISMATCH:
clear Token

7. Không dùng một boolean:

isLicensed=true

lưu local như nguồn xác thực.

Mỗi lần restore phải verify Token lại.

==================================================
5. OUTPUT
==================================================

Báo:

1. Token storage key
2. Khi nào Token được lưu
3. Khi nào Token bị xóa
4. Có boolean isLicensed persistent không
Expected: NO
```
