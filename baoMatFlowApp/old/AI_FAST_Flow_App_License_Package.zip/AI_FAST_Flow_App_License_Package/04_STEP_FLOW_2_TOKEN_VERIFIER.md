# STEP FLOW 2 — Tạo Signed License Token Verifier

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 2 – IMPLEMENT SIGNED LICENSE TOKEN VERIFIER

QUAN TRỌNG:

Token được tạo bởi AI Fast Admin.

Admin sử dụng canonical crypto contract:

payloadJson = JSON.stringify(payload)

payloadBytes = UTF8(payloadJson)

payloadPart = base64url(payloadBytes)

signingInput = UTF8(payloadPart)

signature =
ECDSA P-256 SHA-256(signingInput)

token =
payloadPart + "." + base64url(signature)

Flow App phải verify CHÍNH XÁC contract này.

Không được thay đổi cách verify.

==================================================
1. FILE
==================================================

Tạo:

src/services/offlineLicenseService.ts

hoặc tên tương đương.

==================================================
2. TOKEN FORMAT
==================================================

Token có đúng 2 phần:

PAYLOAD_PART.SIGNATURE_PART

Split:

const parts = token.trim().split(".");

Nếu:

parts.length !== 2

return:

INVALID_FORMAT

==================================================
3. BASE64URL DECODE
==================================================

Tạo helper:

base64UrlDecode()

Quy tắc:

"-" -> "+"
"_" -> "/"

restore "=" padding

decode thành Uint8Array.

Không dùng decode hack làm thay đổi bytes.

==================================================
4. PUBLIC KEY
==================================================

Import:

LICENSE_PUBLIC_JWK

bằng:

crypto.subtle.importKey(
  "jwk",
  LICENSE_PUBLIC_JWK,
  {
    name: "ECDSA",
    namedCurve: "P-256"
  },
  false,
  ["verify"]
)

Không fetch Public Key từ Internet.

Không Firebase.

==================================================
5. SIGNATURE VERIFY
==================================================

Lấy:

payloadPart
signaturePart

Decode signaturePart thành Uint8Array.

Tạo:

signingInput =
new TextEncoder().encode(payloadPart)

Verify:

crypto.subtle.verify(
  {
    name: "ECDSA",
    hash: "SHA-256"
  },
  publicKey,
  signatureBytes,
  signingInput
)

Nếu false:

return:

INVALID_SIGNATURE

QUAN TRỌNG:

Không verify decoded JSON bytes.

Không verify payloadJson.

Không verify toàn Token.

Chỉ verify:

UTF8(payloadPart)

==================================================
6. CHỈ DECODE PAYLOAD SAU SIGNATURE
==================================================

Chỉ sau khi signature valid:

decode payloadPart

UTF8 decode

JSON.parse()

Không tin bất kỳ field nào trước khi signature PASS.

==================================================
7. PAYLOAD EXPECTED
==================================================

Payload V1 gồm:

version
keyId
issuer
audience

licenseId
projectId
machineId

licensedEmailMasked
planLabel

issuedAt
expiresAt

==================================================
8. VERIFY METADATA
==================================================

Check:

payload.version === LICENSE_CONFIG.tokenVersion

nếu sai:
UNSUPPORTED_VERSION

Check:

payload.issuer === LICENSE_CONFIG.issuer

nếu sai:
INVALID_ISSUER

Check:

payload.audience === LICENSE_CONFIG.audience

nếu sai:
INVALID_AUDIENCE

==================================================
9. VERIFY PROJECT
==================================================

Check:

payload.projectId === LICENSE_CONFIG.projectId

Nếu sai:

PROJECT_MISMATCH

Token của App A tuyệt đối không dùng được App B.

==================================================
10. VERIFY MACHINE
==================================================

Lấy:

currentMachineId =
getOrCreateMachineId()

Check:

payload.machineId === currentMachineId

Nếu sai:

DEVICE_MISMATCH

==================================================
11. VERIFY TIME
==================================================

issuedAt và expiresAt phải là:

number
safe integer
Unix seconds

Reject nếu format sai.

Current time:

Math.floor(Date.now() / 1000)

Nếu:

currentTime >= payload.expiresAt

return:

EXPIRED

Nếu:

payload.expiresAt <= payload.issuedAt

return:

INVALID_PAYLOAD

==================================================
12. RESULT
==================================================

Function:

verifyLicenseToken(token)

Return dạng discriminated result.

Success:

{
  valid: true,
  payload
}

Failure:

{
  valid: false,
  code,
  message
}

Các error code:

INVALID_FORMAT
INVALID_SIGNATURE
INVALID_PAYLOAD
UNSUPPORTED_VERSION
INVALID_ISSUER
INVALID_AUDIENCE
PROJECT_MISMATCH
DEVICE_MISMATCH
EXPIRED

==================================================
13. KHÔNG LÀM
==================================================

Không external fetch.

Không Firebase.

Không Firestore.

Không backend.

Không JWT library.

Không JOSE library.

Dùng native Web Crypto API.

==================================================
14. OUTPUT
==================================================

Báo:

1. Function verify
2. Exact signingInput đang verify
3. Algorithm
4. Curve
5. Hash
6. Error codes
```
