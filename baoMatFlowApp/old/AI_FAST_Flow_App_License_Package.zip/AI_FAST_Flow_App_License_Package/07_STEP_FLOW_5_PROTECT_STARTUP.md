# STEP FLOW 5 — Protect App Startup

```text
FLOW APP OFFLINE LICENSE SECURITY
STEP 5 – PROTECT APP STARTUP

Mục tiêu:
Main App không được render trước khi License được xác minh.

==================================================
1. LICENSE STATE
==================================================

Trong root App tạo state:

checking
valid
invalid

Không default thành valid.

==================================================
2. APP START
==================================================

Khi App mount:

1. Hiển thị:
"Đang kiểm tra License..."

2. gọi:
restoreLicense()

3. Nếu valid:
lưu payload vào memory
render Main App

4. Nếu không có hoặc invalid:
render LicenseGate

==================================================
3. KHÔNG FLASH MAIN UI
==================================================

Trong thời gian checking:

Main App không được render rồi mới bị ẩn.

Chỉ hiển thị loading screen.

==================================================
4. AFTER ACTIVATION
==================================================

Khi LicenseGate verify thành công:

set license payload

set state valid

render Main App

Không reload page nếu không cần.

==================================================
5. EXPIRED TOKEN
==================================================

Nếu restore trả EXPIRED:

clear Token

show LicenseGate

==================================================
6. OUTPUT
==================================================

Báo:

1. App startup flow
2. Main App có render trước verify không
Expected: NO
3. Restore function được gọi ở đâu
```
