Tích hợp License Manager.

Startup gọi:

checkLicense()

Nếu valid:
mở app

Nếu false:
hiện License Gate.

Không gọi verify crypto trực tiếp từ UI.