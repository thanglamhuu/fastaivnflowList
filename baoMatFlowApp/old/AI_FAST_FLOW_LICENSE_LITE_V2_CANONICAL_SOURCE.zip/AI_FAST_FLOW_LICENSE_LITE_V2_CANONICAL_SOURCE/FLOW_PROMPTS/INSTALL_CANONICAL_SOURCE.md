Tạo thư mục src/license.

Copy nguyên 4 file canonical source được cung cấp.

Không:
- sửa crypto
- đổi public key
- đổi function
- thêm Firebase

Chỉ thay:
PROJECT_ID
APP_NAME

Sau khi tạo xong báo danh sách file.