import { LICENSE_CONFIG, LICENSE_PUBLIC_JWK } from "./aifastLicenseConfig";
import { getOrCreateMachineId } from "./aifastMachine";

function base64UrlToBytes(input:string):Uint8Array {
  const pad = "=".repeat((4 - input.length % 4) % 4);
  const base64 = (input + pad)
    .replace(/-/g, "+")
    .replace(/_/g, "/");
  return Uint8Array.from(atob(base64), c => c.charCodeAt(0));
}

function base64UrlToJson(input:string){
  return JSON.parse(
    new TextDecoder().decode(base64UrlToBytes(input))
  );
}

async function importPublicKey(){
  return crypto.subtle.importKey(
    "jwk",
    LICENSE_PUBLIC_JWK,
    {
      name:"ECDSA",
      namedCurve:"P-256"
    },
    false,
    ["verify"]
  );
}

export async function verifyLicense(token:string){
  try {
    const parts = token.split(".");
    if(parts.length !== 2){
      return {valid:false, reason:"INVALID_FORMAT"};
    }

    const [payloadPart, signaturePart] = parts;

    const key = await importPublicKey();

    const valid = await crypto.subtle.verify(
      {
        name:"ECDSA",
        hash:"SHA-256"
      },
      key,
      base64UrlToBytes(signaturePart),
      new TextEncoder().encode(payloadPart)
    );

    if(!valid){
      return {valid:false, reason:"INVALID_SIGNATURE"};
    }

    const payload = base64UrlToJson(payloadPart);

    if(payload.projectId !== LICENSE_CONFIG.PROJECT_ID)
      return {valid:false, reason:"PROJECT_MISMATCH"};

    if(payload.machineId !== getOrCreateMachineId())
      return {valid:false, reason:"DEVICE_MISMATCH"};

    if(payload.expiresAt < Math.floor(Date.now()/1000))
      return {valid:false, reason:"EXPIRED"};

    return {
      valid:true,
      payload
    };

  } catch(e){
    return {
      valid:false,
      reason:"VERIFY_ERROR"
    };
  }
}