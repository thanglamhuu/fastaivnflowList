import {verifyLicense} from "./aifastLicenseVerifier";

const LICENSE_KEY = "aifast.licenseToken";

export async function activateLicense(token:string){
  const result = await verifyLicense(token);

  if(result.valid){
    localStorage.setItem(LICENSE_KEY, token);
  }

  return result;
}

export async function checkLicense(){
  const token = localStorage.getItem(LICENSE_KEY);

  if(!token){
    return {valid:false, reason:"NO_LICENSE"};
  }

  return verifyLicense(token);
}

export async function getLicenseStatus(){
  return checkLicense();
}