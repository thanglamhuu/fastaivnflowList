# Định dạng và công cụ

JSON chuẩn hóa lỗi cú pháp trong mẫu ban đầu: `grade` không có dấu cách cuối; `correct_answer` không có dấu gạch chéo; mọi phương án có `content`; không có dấu phẩy dư.

```json
{
  "name": "Tên đề thực tế",
  "grade": "12",
  "time": 50,
  "questions": [
    {
      "type": "one",
      "tag": "BTCB",
      "question": {"text": "Nội dung câu hỏi", "img": ""},
      "score": 0.25,
      "answers": {
        "A": {"type": "text", "content": "Nội dung A"},
        "B": {"type": "html", "content": "2 × 10<sup>3</sup> J"},
        "C": {"type": "text", "content": "Nội dung C"},
        "D": {"type": "text", "content": "Nội dung D"}
      },
      "correct_answer": "B"
    }
  ]
}
```

- `yesno`: cùng cấu trúc phương án A–D; `correct_answer` là `{"A":"D","B":"S","C":"D","D":"S"}`. D = Đúng, S = Sai, không phải chữ cái của phương án.
- `short`: không có `answers`; `correct_answer` là chuỗi, ví dụ `"0,15"`; bắt buộc `answer_content: {"type":"image","content":"cau_23_giai.png"}` khi có lời giải nguồn.
- `multi_short`: `correct_answer` là đối tượng các khóa con với giá trị chuỗi, ví dụ `{"A":"Black","B":"Blue"}`; ảnh giải ở `answer_content` tương tự.
- `question.text` và `question.img` luôn có; một trong hai có thể rỗng. Tên ảnh là tên tệp cùng thư mục, không chứa đường dẫn tuyệt đối hoặc thư mục con.
- Không invent tên đề/lớp khi nguồn không cho biết; dùng ngữ cảnh đáng tin cậy hoặc hỏi người dùng nếu cần.

## Cắt ảnh

Chạy với Python của runtime:

```text
python exam_tools.py crop input.pdf manifest.json output_dir
```

Manifest minh họa (tọa độ phải đo lại cho từng PDF):

```json
{
  "scale": 3,
  "images": [
    {
      "file": "cau_01_B.png",
      "parts": [
        {"page": 1, "bbox": [115, 250, 325, 280]}
      ]
    },
    {
      "file": "cau_23_giai.png",
      "parts": [
        {"page": 8, "bbox": [50, 730, 570, 805]},
        {"page": 9, "bbox": [50, 20, 570, 110]}
      ]
    }
  ]
}
```

`page` bắt đầu từ 1; `bbox` là `[trái, trên, phải, dưới]` theo point PDF, gốc trên trái, cùng hệ tọa độ `pdfplumber`. `scale: 3` = 216 dpi. Mỗi part có thể thêm `masks: [[x0,y0,x1,y1]]` để che nội dung lân cận, cũng là tọa độ trang. Xác minh PDF có rotation/cropbox bằng ảnh render trước khi dùng tọa độ. Các part rỗng được bỏ qua; một ảnh hoàn toàn rỗng gây lỗi.

## Đóng gói

Chuẩn bị thư mục riêng gồm `de_thi.json` và ảnh đã rà. Notes JSON là mảng chuỗi, chỉ chứa lưu ý của đề hiện tại.

```text
python exam_tools.py package output_dir de_trac_nghiem.zip --notes notes.json
```

Lệnh kiểm tra cấu trúc và tham chiếu ảnh, tạo `kiem_thu.html` từ mẫu, rồi ZIP đúng những tệp được sử dụng ở cùng cấp. `--notes` có thể bỏ qua. Lệnh không thay thế việc tự kiểm tra tính đúng đắn vật lý, nội dung ảnh hoặc chạy trình duyệt. Mọi lỗi validation phải giải quyết trước khi giao.

## Quy định cập nhật

- `time` là số phút (mặc định 50), `grade` mặc định "12".
- Mỗi câu có `tag` thuộc LT/BTCB/BTVD/BTNC và `score` số: one 0.25, yesno 1, short 0.25. multi_short cần điểm được xác định riêng.
- Phương án hỗ trợ `text`, `html`, `image`. Ưu tiên text/HTML chính xác; HTML chỉ dùng thẻ đơn giản như sup, sub, b, strong, i, em, span, br, p. Không dùng script, iframe, sự kiện, CSS hoặc tài nguyên từ mạng. Trình xem lọc bỏ thẻ/thuộc tính không được phép.
- Toàn bộ lời giải trả lời ngắn vẫn là ảnh nguồn; đáp số vẫn lưu chuỗi hoặc đối tượng cho multi_short.
- Chấm điểm kiểm thử: đúng toàn bộ câu mới nhận score; ý đúng/sai được thống kê riêng, chưa áp dụng điểm từng ý nếu chưa được quy định.
