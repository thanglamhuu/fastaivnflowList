"""Crop reviewed PDF regions and package a validated offline exam. No OCR or answer inference."""
import argparse
import json
import math
from pathlib import Path
import zipfile


def filename(value):
    if not isinstance(value, str) or not value or value in ('.', '..') or any(c in value for c in '/\\:'):
        raise ValueError(f'Expected a flat filename: {value!r}')
    return value


def validate(data, folder):
    if not isinstance(data.get('name'), str) or not data['name'].strip():
        raise ValueError('Missing exam name')
    if not isinstance(data.get('grade'), str):
        raise ValueError('grade must be a string')
    if type(data.get('time')) not in (int, float) or not math.isfinite(data['time']) or data['time'] <= 0:
        raise ValueError('time must be positive minutes')
    if not isinstance(data.get('questions'), list) or not data['questions']:
        raise ValueError('No questions')
    refs = set()

    def image_ref(f):
        f = filename(f)
        if Path(f).suffix.lower() != '.png':
            raise ValueError('Use PNG images')
        if not (folder / f).is_file():
            raise ValueError(f'Missing image: {f}')
        refs.add(f)

    def content(a):
        if a.get('type') not in ('text', 'html', 'image') or not isinstance(a.get('content'), str) or not a['content'].strip():
            raise ValueError('Invalid answer content')
        if a['type'] == 'image':
            image_ref(a['content'])

    for i, q in enumerate(data['questions'], 1):
        try:
            typ = q['type']; stem = q['question']; key = q['correct_answer']
            if q.get('tag') not in ('LT','BTCB','BTVD','BTNC'):
                raise ValueError('Missing/invalid tag')
            if 'score' not in q:
                raise ValueError('Missing score')
            if typ not in ('one', 'yesno', 'short', 'multi_short'):
                raise ValueError('Unsupported question type')
            if not all(isinstance(stem.get(k), str) for k in ('text', 'img')) or not (stem['text'].strip() or stem['img']):
                raise ValueError('Empty/invalid question')
            if stem['img']:
                image_ref(stem['img'])
            if 'score' in q and (type(q['score']) not in (int, float) or not math.isfinite(q['score']) or q['score'] < 0):
                raise ValueError('Invalid score')
            if typ in ('one', 'yesno'):
                if set(q['answers']) != set('ABCD'):
                    raise ValueError('Expected answers A–D')
                for a in q['answers'].values():
                    content(a)
                if typ == 'one' and key not in list('ABCD'):
                    raise ValueError('Invalid single-choice key')
                if typ == 'yesno' and (not isinstance(key, dict) or set(key) != set('ABCD') or any(v not in ('D', 'S') for v in key.values())):
                    raise ValueError('Invalid true/false key')
            else:
                if typ == 'short' and (not isinstance(key, str) or not key.strip()):
                    raise ValueError('Short key must be a nonempty string')
                if typ == 'multi_short' and (not isinstance(key, dict) or not key or any(not isinstance(v, str) or not v.strip() for v in key.values())):
                    raise ValueError('Invalid multiple short-answer key')
                content(q['answer_content'])
                if q['answer_content']['type'] != 'image':
                    raise ValueError('Short solution must be a source image')
        except (KeyError, TypeError, ValueError) as e:
            raise ValueError(f'Question {i}: {e}') from e
    return refs


def crop(args):
    import pypdfium2 as pdfium
    from PIL import Image, ImageChops, ImageDraw, ImageOps
    config = json.loads(args.manifest.read_text(encoding='utf-8-sig'))
    scale = float(config.get('scale', 3))
    if not 1 <= scale <= 8:
        raise ValueError('scale must be 1–8')
    args.output.mkdir(parents=True, exist_ok=True)
    pdf = pdfium.PdfDocument(args.pdf)
    cache = {}; seen = set()
    for item in config['images']:
        name = filename(item['file'])
        if not name.lower().endswith('.png') or name in seen:
            raise ValueError('Image names must be unique PNG filenames')
        seen.add(name); pieces = []
        for part in item['parts']:
            n = part['page'] - 1
            if not 0 <= n < len(pdf):
                raise ValueError('Page out of range')
            if n not in cache:
                cache[n] = pdf[n].render(scale=scale).to_pil().convert('RGB')
            x0, y0, x1, y1 = part['bbox']
            if not (0 <= x0 < x1 <= cache[n].width / scale + .5 and 0 <= y0 < y1 <= cache[n].height / scale + .5):
                raise ValueError(f'Invalid crop on page {n+1}')
            im = cache[n].crop(tuple(round(v * scale) for v in (x0,y0,x1,y1)))
            draw = ImageDraw.Draw(im)
            for a,b,c,d in part.get('masks', []):
                draw.rectangle(((a-x0)*scale,(b-y0)*scale,(c-x0)*scale,(d-y0)*scale), fill='white')
            bbox = ImageChops.difference(im, Image.new('RGB', im.size, 'white')).getbbox()
            if bbox:
                pieces.append(im.crop(bbox))
        if not pieces:
            raise ValueError(f'Empty image: {name}')
        canvas = Image.new('RGB', (max(p.width for p in pieces),sum(p.height for p in pieces)+12*(len(pieces)-1)), 'white')
        top = 0
        for p in pieces:
            canvas.paste(p,(0,top)); top += p.height + 12
        ImageOps.expand(canvas,border=2,fill='white').save(args.output / name)
    pdf.close()
    print(f'Cropped {len(seen)} images. Visual review still required.')


def package(args):
    folder = args.folder
    data = json.loads((folder / 'de_thi.json').read_text(encoding='utf-8-sig'))
    refs = validate(data, folder)
    notes = json.loads(args.notes.read_text(encoding='utf-8-sig')) if args.notes else []
    if not isinstance(notes,list) or any(not isinstance(n,str) for n in notes):
        raise ValueError('Notes must be an array of strings')
    template = (Path(__file__).resolve().parent.parent/'assets/preview.html').read_text(encoding='utf-8')
    payload = json.dumps({'exam':data,'notes':notes},ensure_ascii=False).replace('<','\\u003c')
    (folder/'kiem_thu.html').write_text(template.replace('__PAYLOAD__',payload),encoding='utf-8')
    args.zip.parent.mkdir(parents=True, exist_ok=True)
    files = ['de_thi.json','kiem_thu.html',*sorted(refs)]
    if args.zip.resolve() in [(folder/f).resolve() for f in files]:
        raise ValueError('ZIP path overlaps an input file')
    with zipfile.ZipFile(args.zip,'w',zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(folder/f,f)
    print(f'Packaged {len(data["questions"])} questions, {len(refs)} images: {args.zip}')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command',required=True)
    c = sub.add_parser('crop')
    for name in ('pdf','manifest','output'):
        c.add_argument(name,type=Path)
    c.set_defaults(run=crop)
    c = sub.add_parser('package')
    for name in ('folder','zip'):
        c.add_argument(name,type=Path)
    c.add_argument('--notes',type=Path)
    c.set_defaults(run=package)
    args = p.parse_args(); args.run(args)
