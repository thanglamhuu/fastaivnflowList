# Khung phân tích và sổ bằng chứng

## Sổ video
Giữ mỗi Reel một dòng, cập nhật khi kiểm tra. Dùng bảng hoặc dữ liệu có cấu trúc, không bắt buộc một định dạng cố định.

| Trường | Nội dung |
|---|---|
| Trang / Page ID | Nhận diện đã đối chiếu |
| Reel ID / link | Nguồn truy cập trực tiếp |
| Ngày đăng / độ chắc chắn | Ngày giờ quan sát được hoặc chưa xác minh |
| Thời điểm lấy số liệu | Múi giờ và ngày giờ |
| Views, reactions, comments, shares | Giá trị công khai; giữ nhãn làm tròn và giá trị xấp xỉ; thiếu = null |
| Thời lượng | Giây quan sát được |
| Điều kiện lọc | Nhân vật có mặt, ngưỡng views, kết quả đủ/không đủ/chưa xác định |
| Trạng thái xem | Đầy đủ/một phần/metadata/không truy cập |
| Audio | Nghe được/không có/không truy cập |
| Chủ đề / dạng content | Phân loại thống nhất toàn kỳ |
| Hook 0–3s | Hình, hành động, chữ, lời thoại thực tế |
| Các beat / timestamp | Biến cố, hành động, phản ứng, payoff |
| Camera / dựng / âm thanh | Quan sát cụ thể, mốc thời gian và phần chưa chắc |
| CTA / thương mại | Link, nhãn, sản phẩm, booking, hợp tác |
| Nhóm trùng nội dung | Chỉ ghi khi xác minh |
| Nguồn / ghi chú | Bằng chứng và giới hạn |

## Phân tích từng clip
- Chủ đề: xung đột nhỏ, trêu chọc, ghen em, chăm em, bắt chước, tình cảm, tình huống sinh hoạt, review/bán hàng hoặc nhóm phát hiện được.
- Hook: điều gì xảy ra ngay; người xem muốn biết gì; có cần caption để hiểu không; không tự tạo lời thoại rồi gán cho clip.
- Kịch bản: setup → biến cố → phản ứng → đổi chiều/payoff. Ghi nhân vật chủ động, người phản ứng, đạo cụ và tình huống lặp.
- Diễn xuất: ánh mắt, ngập ngừng, nét mặt, cử chỉ, thay đổi vị trí; chỉ mô tả hành vi nhìn thấy, không chẩn đoán tính cách trẻ thật.
- Dựng: số shot, cỡ cảnh, khoảng thời lượng shot, điểm cắt, jump cut, chữ, tốc độ, loop và âm thanh; thiếu dữ liệu thì không điền giả.
- Camera: vị trí tương đối, cao độ, framing; đánh dấu đoạn đứng máy, handheld, pan, tilt, tracking/dolly, zoom/crop hoặc chưa rõ. Lấy ít nhất vài thời điểm trong shot và hai phía mỗi điểm cắt khi cần. Parallax là dấu hiệu hỗ trợ chuyển vị trí, không phải chứng cứ tuyệt đối.
- Viral: nối chi tiết quan sát với cơ chế khả dĩ (tò mò, nhận diện bản thân, phản ứng đáng yêu, bất ngờ, dễ hiểu, muốn tag người thân, payoff nhanh). Kiểm tra phản ví dụ: clip dùng cùng công thức nhưng views thấp.

## Bảng mẫu công thức
| Công thức | Hook thực tế + nguồn | Các beat | Payoff | Camera/dựng thực tế | Hiệu suất + n | Biến số để viết mới |
|---|---|---|---|---|---|---|

## Đánh giá có căn cứ
Dùng nhận xét định tính mạnh/vừa/yếu cho độ rõ hook, diễn biến, payoff, khả năng lặp và khả năng sản xuất. Nếu dùng thang điểm, công bố tiêu chí, coi là đánh giá biên tập chứ không phải dự báo thuật toán. Không gộp views vào “điểm viral” để tạo độ chính xác giả.

## Trường hợp thiếu dữ liệu
- Có 30 bài nhưng chỉ xem 6: ghi 6/30, kết luận từ 6 mẫu; tiếp tục 24 bài nếu chưa có chặn hoặc lệnh dừng.
- Video có trẻ 149K/150K làm tròn: chưa xác định với bộ lọc >150K; không tự thêm.
- Video ghim đăng ngoài kỳ: loại khỏi số liệu kỳ; nếu dùng làm tham chiếu, đặt mục riêng.
- Có nhãn hoa hồng: bằng chứng về affiliate, không chứng minh có đơn hay số tiền.
- Có quảng cáo bán sản phẩm: bằng chứng trang chạy quảng cáo đó, không chứng minh trả phí cho Reel đã xem.
- Bình luận giống nhau: dấu hiệu cần kiểm chứng, chưa đủ xác nhận seeding.
- Ảnh đầu/cuối gần giống: không đủ kết luận shot đứng máy; kiểm tra chuỗi video.
