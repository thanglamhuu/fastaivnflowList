# Chuyển phân tích thành content nguyên bản

## Kịch bản
Tạo ý tưởng dựa trên cấu trúc hiệu quả đã quan sát, thay tình huống, đạo cụ, lời thoại và cách giải quyết. Không sao chép nguyên clip hoặc dùng mặt/giọng gia đình mẫu khi chưa được phép. Mỗi kịch bản gồm hook, mục tiêu nhân vật, các beat, thoại, hành động, payoff, camera/dựng và lý do lựa chọn gắn với bằng chứng mẫu. Không áp mặc định mọi gia đình đều phải có bốn người trong shot.

## Video AI khi người dùng yêu cầu
- Xác minh model/workflow, thời lượng clip, ảnh đầu-cuối và tham chiếu hiện có trước khi chọn cấu trúc. Không bịa khả năng model; tra tài liệu chính thức nếu cần thông tin hiện hành.
- Với đầu-cuối: N ảnh ranh giới tạo N−1 đoạn; 4 ảnh tạo 3×8s = 24s. Ảnh cuối đoạn trước là ảnh đầu đoạn sau; giữ nhận diện, đồ mặc, vị trí, đạo cụ, ánh sáng và hướng chuyển động.
- Viết mỗi đoạn thành prompt riêng: tham chiếu đầu/cuối, hành động theo giây, thoại nguyên văn, người nói, giọng, audio, camera và trạng thái cuối. Không đưa cả lưới storyboard vào một đoạn trừ khi model hỗ trợ và mục tiêu rõ; ưu tiên ảnh riêng.
- Mô tả giọng từng người bằng tuổi, âm vực, sắc thái, vùng giọng người dùng chọn. Trẻ chưa nói chỉ bập bẹ; không gán câu thoại. Không đổi độ tuổi để né bộ lọc. Không bảo đảm giọng nhất quán chỉ nhờ mô tả; dùng voice preset/reference nếu sản phẩm hỗ trợ.
- Chọn camera từ dữ liệu mẫu. Không mặc định cinematic dolly/orbit cho content quay điện thoại. Để hành động, nét mặt, ánh mắt, động tác tay và tương tác tạo nhịp; dùng pan/tilt/reframe nhẹ khi có mục đích.
- Nếu muốn camera đổi vị trí/cỡ cảnh rõ, kiểm tra bố cục ảnh đầu-cuối có tương thích. Đề xuất chỉnh ảnh tham chiếu khi cần; không hứa câu “camera moves” sẽ thắng ràng buộc ảnh.
- Khi người dùng gửi clip lỗi, xem clip thực tế và các thời điểm trước khi chẩn đoán. Tách lỗi nhân vật, hành động, camera, thoại, liên tục và điểm cắt. Không tuyên bố đã xem file chỉ dựa vào tên.
- Giữ tỷ lệ người dùng chỉ định; nếu Reels chưa chỉ định, dùng 9:16. Không watermark/logo nền tảng/username/UI/chữ ngoài yêu cầu. Với yêu cầu hình thật, dùng live-action photoreal, không CGI/3D. Áp dụng phong cách hình ảnh người dùng đã chọn, nhưng không gán phong cách đó cho kênh mẫu.
