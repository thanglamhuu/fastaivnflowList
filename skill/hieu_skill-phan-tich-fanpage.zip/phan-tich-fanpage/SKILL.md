---
name: phan-tich-fanpage
description: Phân tích fanpage Facebook và Reels từ link người dùng cung cấp; khảo sát toàn bộ video trong 15 ngày gần nhất hoặc theo bộ lọc được yêu cầu, phân tích chủ đề, hook, kịch bản, dựng, camera, lý do có thể viral, công thức lặp lại, kiếm tiền, quảng cáo và seeding có bằng chứng. Dùng khi người dùng muốn nghiên cứu kênh mẫu, so sánh fanpage, tìm công thức content hoặc chuyển kết quả thành kịch bản và prompt video AI.
---

# Phân tích Fanpage & Reels

Trả lời bằng tiếng Việt, trừ khi người dùng yêu cầu khác. Bắt đầu làm từ link đã cung cấp; không hỏi lại các tiêu chí mặc định. Đọc [khung phân tích](references/analysis-framework.md) trước khi phân tích và [chuyển thành content](references/content-production.md) khi viết kịch bản hoặc prompt AI.

## 1. Xác lập phạm vi và nhận diện trang

- Mặc định khảo sát toàn bộ Reels đăng trong 15 ngày lịch gần nhất, gồm hôm nay theo múi giờ người dùng (mặc định Asia/Saigon): từ 00:00 ngày D−14 đến thời điểm kiểm tra ngày D. Ghi ngày bắt đầu, kết thúc và thời điểm lấy số liệu. Ưu tiên khoảng ngày người dùng chỉ định.
- Áp dụng đúng bộ lọc: có mặt trẻ/nhân vật cụ thể, views lớn hơn hoặc bằng ngưỡng, loại nội dung. Phân biệt rõ >150K với ≥150K. Với chỉ số làm tròn sát ngưỡng, đánh dấu chưa xác định thay vì tự suy diễn.
- Nếu nhiều trang, tạo dữ liệu riêng từng trang rồi so sánh trên cùng kỳ và cùng bộ lọc; không trộn điều kiện khác nhau.
- Xác minh tên, URL, Page ID nếu thấy, follower và mô tả công khai. Đối chiếu Page ID khi tìm quảng cáo để tránh trang trùng tên.
- Sử dụng công cụ tìm kiếm cho tra cứu công khai; connector phù hợp nếu có. Dùng browser được hỗ trợ để trực tiếp xem/phát video khi cần, theo hướng dẫn browser và đăng nhập hiện có. Không giả định phiên đăng nhập; không yêu cầu mật khẩu trong chat. Không vượt chặn truy cập hoặc dùng phương thức UI không được hỗ trợ.

## 2. Kiểm kê trước, xem toàn bộ video đủ điều kiện

- Duyệt danh sách Reels đến khi xác minh đã qua đầu kỳ. Không dùng thứ tự lưới, ghim hoặc mức views để suy đoán ngày đăng. Giữ bản đăng lại là bài riêng, ghi nhóm trùng nội dung nếu xác minh được.
- Lập sổ video theo mẫu trong khung phân tích. Ghi ngày chưa xác minh là chưa xác minh; không tự xếp vào kỳ.
- Xem/phát toàn bộ thời lượng từng video đủ điều kiện. Ghi trạng thái riêng: xem đầy đủ, xem một phần, chỉ có metadata, không truy cập được. Nếu chỉ có ảnh mẫu, không nói đã xem video; nếu thiếu audio, không bịa lời thoại/giọng nói.
- Không thay yêu cầu toàn bộ bằng vài clip nổi bật. Có thể phân tích sâu clip đại diện sau khi hoàn thành khảo sát toàn bộ. Cập nhật tiến độ ngắn gọn và lưu checkpoint với công cụ lưu trữ phù hợp để tiếp tục đúng chỗ khi công việc dài.
- Nếu gặp giới hạn thật sự, tiếp tục phần truy cập được; báo chính xác số đã xem, số chưa xem và nguyên nhân. Không dùng kết luận toàn kênh khi chỉ có mẫu nhỏ. Khi người dùng yêu cầu dừng, dừng khảo sát và tổng hợp phần đã có.

## 3. Ghi bằng chứng nội dung và camera

- Ghi hook 0–3s, diễn biến theo thời gian, hành động, lời thoại nghe được, phản ứng, cao trào, kết thúc và khả năng loop. Gắn video và mốc giây cho nhận xét quan trọng.
- Phân biệt camera di chuyển thật, pan/tilt từ một vị trí, rung tay, zoom/crop hậu kỳ, cắt cảnh và nhân vật di chuyển. So sánh nhiều thời điểm và các mốc hậu cảnh; không suy ra chuyển động từ một ảnh.
- Chỉ dùng “thường dùng/đa số” nếu có mẫu đủ và đếm được. Nêu n/N cùng tập mẫu; nếu chưa chắc đó là digital zoom hay tiến máy, ghi không xác định. Không kết luận thiết bị/gimbal/tripod từ cảm giác hình ảnh.

## 4. Tính số liệu và diễn giải

- Tính số bài, số đủ điều kiện, độ phủ xem, tần suất đăng, median views, khoảng views, median thời lượng, số trên các ngưỡng phù hợp. Dùng đúng mẫu có số liệu; hiển thị mẫu số và số thiếu.
- Views tại thời điểm kiểm tra là views tích lũy của bài đăng trong kỳ, không phải views phát sinh trong kỳ. Khi cộng số làm tròn, ghi tổng xấp xỉ. Không coi views là người xem duy nhất.
- Chỉ tính tỷ lệ (reactions+comments+shares)/views khi có đủ ba thành phần và views >0; ghi công thức, không gọi là retention. Không thay số thiếu bằng 0. Không suy ra watch time, completion, save hoặc traffic source khi không có analytics.
- Phân nhóm content, so sánh clip tốt và yếu trong cùng kênh, lưu ý tuổi bài, độ dài, cỡ mẫu và yếu tố ngoại lệ. Không lấy clip tốt nhất đại diện cho tất cả.
- Tách “quan sát được”, “giả thuyết có căn cứ” và “chưa xác minh”. Giải thích cơ chế có thể viral bằng hành vi cụ thể và clip dẫn chứng; không khẳng định quan hệ nhân quả hoặc bảo đảm viral từ views công khai.

## 5. Kiếm tiền, quảng cáo và seeding

- Kiểm tra mô tả, link, lời kêu gọi mua, sản phẩm, livestream, affiliate/hoa hồng, booking và nội dung hợp tác công khai. Phân biệt nguồn thu có bằng chứng với nguồn thu khả dĩ. Không tự ước doanh thu/RPM hoặc xác nhận bật monetization.
- Kiểm tra Meta Ad Library/Thông tin minh bạch nếu truy cập được; xác minh đúng trang, thời điểm, bộ lọc, trạng thái và ví dụ quảng cáo/ID/link. “Không thấy quảng cáo đang hoạt động” không có nghĩa chưa từng chạy. Trang có quảng cáo không chứng minh Reel được boost hay viral nhờ ads.
- Đọc bình luận trên nhóm clip đại diện có hiệu suất cao, trung bình và thấp. Chỉ ghi dấu hiệu quan sát được như lời lặp, thời gian đăng dồn, tài khoản lặp; đó chưa đủ chứng minh seeding. Phản hồi của chủ trang không tự động là seeding. Không cáo buộc hoặc suy đoán danh tính người bình luận; nếu không có bằng chứng, kết luận chưa đủ cơ sở xác nhận.

## 6. Xuất báo cáo và công thức tái sử dụng

Trình bày theo thứ tự:
1. Kết luận chính và phạm vi/độ phủ thực tế.
2. Bảng tổng quan và danh sách video trong kỳ (đủ dữ liệu hoặc phần phụ lục nếu dài).
3. Chủ đề, hook, cấu trúc kịch bản, nhân vật, dựng, âm thanh và camera có ví dụ/mốc giây.
4. Lý do có thể viral, bằng chứng và yếu tố chưa kiểm chứng.
5. Công thức lặp lại: biến cố → hành động → phản ứng → payoff; biến số có thể đổi và điều cần giữ.
6. Kiếm tiền, quảng cáo, seeding: kết quả kiểm tra và mức chắc chắn.
7. Đề xuất content nguyên bản có thể áp dụng, tránh sao chép nguyên lời thoại hoặc nhận diện gia đình mẫu.
8. Giới hạn dữ liệu và các bước cần thêm để kiểm chứng.

Nếu chỉ nhận link, mặc định thực hiện toàn quy trình và trả báo cáo trong chat; giữ sổ khảo sát để dùng lại với công cụ lưu trữ phù hợp. Xuất Word/Excel khi người dùng yêu cầu hoặc dữ liệu quá dài để xem hữu ích trong chat; dùng skill tài liệu/bảng tính và lưu deliverable theo quy định môi trường. Dẫn link trực tiếp/bằng chứng phù hợp với công cụ; không tạo citation hoặc số liệu giả.

Trước khi hoàn thành, kiểm tra: đúng trang/kỳ/bộ lọc; không bỏ video mà vẫn tuyên bố đầy đủ; có mẫu số; tách metadata với xem thực tế; phân tích camera có chuỗi thời điểm; không gán ads/seeding/doanh thu vô căn cứ; công thức có thể dùng để viết content.
