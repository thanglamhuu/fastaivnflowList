# HƯỚNG DẪN SỬ DỤNG FASTAIVN FAMILY STUDIO AUTO

**Phiên bản Skill: 1.9 · Dành cho Codex và Claude Code · Ngôn ngữ hướng dẫn: tiếng Việt**

> Bạn chỉ cần trò chuyện bằng **tiếng Việt**. Skill sẽ giải thích, hỏi duyệt và trình bày kịch bản bằng tiếng Việt. **Chỉ prompt dùng để tạo video mới phải viết bằng tiếng Anh.**

## 1. Skill giúp bạn làm gì?

- Tạo các câu chuyện hài gia đình từ nhân vật do **bạn** cung cấp, không tự mặc định sử dụng gia đình minh họa.
- Lưu quy tắc nhất quán về ngoại hình, trang phục, tính cách và giọng nói (Voice Lock) theo từng nhân vật.
- Đề xuất 5 kịch bản hài dạng **đoạn văn thuần túy**, có hook và cú chốt, **không timeline**.
- Sau khi bạn **chọn một kịch bản**, mới phân tích bối cảnh, chia shot, thời lượng và hành động.
- Tạo prompt **tiếng Anh**, bảo đảm mô tả có trình tự, điểm neo không gian (Spatial Anchor), phong cách điện ảnh, cảnh gia đình an toàn và giọng nói nhất quán.
- Hiển thị **tất cả prompt để bạn duyệt** trước bất kỳ bước tạo video nào.

**Giới hạn quan trọng:** Cài Skill không tự cấp tài khoản Google Flow, API Veo/Omni, quyền sử dụng dịch vụ, hay bộ máy render. Skill chỉ tự xuất video nếu môi trường thực tế được kết nối với công cụ hợp lệ, có hỗ trợ loại nội dung và quyền truy cập cần thiết. Không có tích hợp thì bạn vẫn có thể dùng prompt để chạy thủ công.

## 2. Cài đặt trên Windows

Giải nén tệp ZIP để được **một thư mục** có tên `fastaivn-family-studio` chứa file `SKILL.md`, thư mục `references`, `templates` và tài liệu này.

**Codex (cài ở cấp cá nhân):**

```text
C:\Users\<TenWindows>\.agents\skills\fastaivn-family-studio\SKILL.md
```

**Claude Code (cài ở cấp cá nhân):**

```text
C:\Users\<TenWindows>\.claude\skills\fastaivn-family-studio\SKILL.md
```

Mở PowerShell **ngay tại thư mục chứa `fastaivn-family-studio` sau khi giải nén**, chạy:

```powershell
# Cho Codex
New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null
Copy-Item -Path ".\fastaivn-family-studio" -Destination "$HOME\.agents\skills\" -Recurse -Force

# Cho Claude Code
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Copy-Item -Path ".\fastaivn-family-studio" -Destination "$HOME\.claude\skills\" -Recurse -Force
```

Nếu bản cũ đã có sẵn, kiểm tra/xóa hoặc đổi tên thư mục cũ trước khi chép để tránh trộn phiên bản. Mở phiên Codex/Claude Code mới sau khi cài.

**Cài cho riêng một dự án:** dùng `<DuAn>\.agents\skills\fastaivn-family-studio\` (Codex), hoặc `<DuAn>\.claude\skills\fastaivn-family-studio\` (Claude Code).

**Phân biệt:** Claude Code (ứng dụng/CLI lập trình) và Claude trên trình duyệt không phải lúc nào cũng hỗ trợ cùng cách cài Skill dạng thư mục; hướng dẫn này dành cho **Claude Code**.

## 3. Quy trình sử dụng từ đầu đến cuối

### Bước A — Tạo hồ sơ gia đình

Bạn nhập:

```text
Dùng skill fastaivn-family-studio. Tôi muốn tạo gia đình có 4 người:
Bố 35 tuổi, hài hước; Mẹ 28 tuổi, hay dỗi yêu;
Gạo 3 tuổi, nhanh trí; Khoai 9 tháng, hay cười.
Hãy giúp tôi thiết lập hồ sơ nhân vật và hỏi ảnh tham chiếu khi cần.
```

Có thể gửi **ảnh mặt, ảnh toàn thân và ảnh trang phục riêng**. Trước khi khóa, Skill phải xác nhận đúng ai là ai và hỏi bạn duyệt ngoại hình, trang phục. Nếu không gửi ảnh, có thể yêu cầu nhân vật hư cấu bằng AI.

### Bước B — Chỉnh giọng (VOICE LOCK)

```text
Thiết lập Voice Lock: Bố là nam người Bắc Việt Nam,
độ tuổi giọng 35, giọng trầm ấm, phát âm rõ, nói tự nhiên,
hơi tinh nghịch. Mẹ giọng nữ Bắc nhẹ nhàng, dịu dàng.
Gạo dùng giọng trẻ con tự nhiên, Khoai chỉ cười và bi bô.
Hãy nhắc lại hồ sơ để tôi duyệt.
```

Giọng mô tả bằng chữ giúp định hướng nhưng **không đảm bảo giống hệt giữa các lần render**. Muốn dùng giọng mẫu thực, cần sự cho phép của chủ giọng và công cụ hỗ trợ phù hợp.

### Bước C — Yêu cầu kịch bản (KHÔNG TIMELINE)

```text
Viết 5 kịch bản hài gia đình dài 20 giây, ít thoại,
hook rõ, bất ngờ ở cuối. Chỉ xuất câu chuyện dạng text,
không timeline, không shot, không prompt, không tạo ảnh.
```

**Kết quả đúng:** 5 câu chuyện bằng văn xuôi tiếng Việt, mỗi chuyện có tên, nội dung và cú chốt. **Tại đây Skill phải dừng**, không tự chọn chuyện hoặc sang bước tạo bối cảnh.

Bạn có thể trả lời:

```text
Tôi chọn kịch bản 3.
```

Hoặc:

```text
Sửa kịch bản 3 để Gạo là người tạo cú chốt. Vẫn chỉ trình bày text.
```

Hoặc:

```text
Viết tiếp 5 ý tưởng khác, không trùng nội dung cũ.
```

### Bước D — Chọn bối cảnh sau khi chốt kịch bản

```text
Tôi chọn phòng khách gia đình làm bối cảnh. Hãy tư vấn
vị trí nhân vật và vật dụng. Chưa tạo ảnh cho đến khi tôi duyệt.
```

Bạn có thể tải ảnh bối cảnh có sẵn, yêu cầu sửa ảnh hoặc cho AI thiết kế mới nếu công cụ ảnh hiện diện.

### Bước E — Duyệt timeline và hướng diễn

```text
Tôi duyệt bối cảnh. Hãy chia kịch bản 20 giây thành các shot
có thời lượng phù hợp, mô tả trạng thái đầu và cuối,
hành động chính và cảm xúc. Sử dụng Spatial Anchor Logic.
```

**Chỉ từ bước này** mới xuất timeline và shot. Thời lượng shot phải hợp lượng hành động, không cố nhồi hoặc kéo dài. Tùy năng lực model được kết nối, có thể có 4s, 6s, 8s hoặc 10s; Skill không được tự khẳng định tùy chọn nào cũng luôn khả dụng.

### Bước F — Tạo prompt tiếng Anh và duyệt

```text
Viết toàn bộ prompt tạo video cho các shot bằng tiếng Anh.
Đảm bảo Cinematic Visual Core, Character Lock, Voice Lock,
Family-Life Context, Spatial Anchor Logic và tính liên tục.
Hiển thị đủ prompt để tôi kiểm tra trước khi render.
```

**Bạn phải được xem và duyệt toàn bộ prompt cuối cùng.** Nếu sai, bạn có thể yêu cầu:

```text
Sửa prompt Shot 2: Gạo chỉ đi đến bên Mẹ, chưa đưa quà.
Giữ nguyên kịch bản, nhân vật và giọng nói. Cho tôi duyệt lại.
```

### Bước G — Chỉ render sau khi duyệt

```text
Tôi duyệt toàn bộ prompt phiên bản vừa hiển thị.
Nếu hệ thống có tích hợp video hợp lệ và hỗ trợ nội dung,
hãy tạo video, kiểm tra lỗi và xuất bản MP4.
```

Nếu không có renderer tương thích, Skill **phải nói rõ** và xuất prompt/ảnh/hướng dẫn sử dụng thủ công — không được báo đã render.

## 4. Nguyên tắc cần đặc biệt lưu ý

**Kịch bản TEXT trước:** Không timeline, không shot, không prompt khi đang đề xuất ý tưởng. Người dùng chủ động chọn chuyện.

**Hai lần duyệt:** ① chọn kịch bản; ② duyệt prompt cuối cùng. Chưa duyệt thì không chuyển bước sản xuất.

**Spatial Anchor:** Nêu vị trí dựa vào nhân vật/vật thể thực trong hình: “Gạo sits between her parents; Dad sits beside Gạo on Gạo’s left; Mom sits beside Gạo on Gạo’s right.” Không chỉ viết “move left/right” mơ hồ; rõ đích đến, điểm xuất phát, tay cầm đạo cụ và trạng thái kết thúc.

**Ảnh đầu chưa diễn hành động:** Nếu một shot yêu cầu Bố chìa tay, Mẹ gạt tay, thì ảnh ban đầu phải ở **trạng thái trước khi các hành động đó xảy ra**. Với Frames, tạo từng ảnh độc lập; tuyệt đối không ghép storyboard dạng nhiều ô vào một file ảnh.

**An toàn trẻ em:** Prompt phải phản ánh hành động thật sự lành mạnh, phù hợp lứa tuổi, tránh ép hành động nguy hiểm. Phần `FAMILY-LIFE CONTEXT` không phải thủ thuật vượt kiểm duyệt; không có bảo đảm 100% một nhà cung cấp chấp nhận video.

**Chất lượng hình ảnh:** photorealistic, ánh sáng điện ảnh, camera chuyên nghiệp có chuyển động phục vụ cảm xúc; fine micro-lighting, micro-shadows, micro-geometry, micro-highlight contrast, micro-edges, micro-colors, micro-textures, natural micro human skin texture. Giữ tông màu và da tự nhiên, tránh CGI/da nhựa.

**VOICE LOCK:** Đúng người nói, đúng vùng miền, độ tuổi giọng, chất giọng và câu thoại tiếng Việt đã duyệt. Không tự gán lời thoại cho người khác.

## 5. Câu lệnh ngắn dùng hằng ngày

| Mục đích | Bạn có thể nhập |
|---|---|
| Tạo ý tưởng | `Dùng fastaivn-family-studio viết 5 kịch bản 20 giây. Chỉ text.` |
| Chọn ý tưởng | `Tôi chọn kịch bản 2.` |
| Sửa ý tưởng | `Sửa cú chốt kịch bản 2, chưa chia timeline.` |
| Chốt bối cảnh | `Tôi duyệt bối cảnh phòng khách.` |
| Lên đạo diễn | `Chia shot và timeline hợp lý theo Spatial Anchor.` |
| Viết prompt | `Xuất tất cả prompt tiếng Anh để tôi duyệt.` |
| Sửa prompt | `Sửa hành động ở shot 1, giữ Character và Voice Lock.` |
| Duyệt prompt | `Tôi duyệt toàn bộ prompt cuối cùng.` |

## 6. Các lỗi thường gặp và cách xử lý

**AI tự chia timeline khi chưa chọn chuyện:** nhắc `Quay lại giai đoạn kịch bản: chỉ text, không timeline.`

**Ảnh đầu đã có sẵn hành động của video:** nhắc `Vẽ lại ảnh đầu ở trạng thái trước hành động. Mỗi ảnh một file độc lập.`

**Video dài bị thêm cử chỉ vô nghĩa:** nhắc `Tối ưu lại số shot/thời lượng dựa vào lượng chuyển động thực.`

**Nhân vật di chuyển sai hướng:** nhắc `Định vị lại theo Gạo/sofa/bàn làm spatial anchor; chỉ rõ điểm đến.`

**Giọng đổi vùng miền:** nhắc `Giữ nguyên Voice ID từ hồ sơ, không tự tạo thoại.`

**Nhà cung cấp không hỗ trợ ảnh trẻ em hoặc báo chặn:** kiểm tra chính sách và quyền của dịch vụ thực tế, yêu cầu phương án an toàn phù hợp; không tìm cách né bộ lọc.

## 7. Tài liệu kỹ thuật trong gói

- `SKILL.md` — chỉ dẫn chính để agent tự kích hoạt workflow.
- `references/production-rules.md` — quy trình và cổng duyệt.
- `references/prompt-compiler.md` — biên dịch hành động, không gian, camera, voice và safety.
- `references/policy-and-quality.md` — kiểm tra chất lượng và chính sách.
- `templates/family-profile.yaml` — mẫu hồ sơ gia đình và Voice Lock.
- `templates/shot-plan.yaml` — mẫu timeline nội bộ **sau khi chọn kịch bản**.
- `templates/video-prompt-template.md` — khung prompt tiếng Anh.

---

**Tóm tắt:** Bạn chỉ cần **tạo gia đình → yêu cầu kịch bản text → chọn kịch bản → chọn bối cảnh → duyệt prompt tiếng Anh → nhận video khi có renderer hợp lệ**. Các quyết định kỹ thuật được Skill điều phối phía sau, không bắt bạn phải tự chọn Ingredients/Frames ở mỗi shot.


## 9. Nâng cấp mới trong V2.0

### Cú twist gây cười và biểu cảm bé

Năm kịch bản gợi ý phải có **một kỳ vọng rõ ràng bị đảo chiều bất ngờ nhưng hợp lý**, cú chốt thấy rõ bằng hình ảnh và biểu cảm Gạo (hoặc bé gái theo hồ sơ đã khóa): tròn mắt, phụng phịu, nghiêng đầu nghi ngờ, mỉm cười tinh quái, nghiêm mặt như người lớn, cười đắc thắng. Tránh chỉ kết thúc bằng việc Bố/Mẹ cười; không làm trẻ sợ, bị tổn thương hoặc mất an toàn. Giai đoạn này **chỉ xuất nội dung chuyện bằng tiếng Việt, không timeline**.

### Shot 10 giây và timeline giây chẵn

Sau khi đã chốt kịch bản và bối cảnh, với video 20s ưu tiên **2 shot × 10s** nếu chế độ AI video hỗ trợ. Trong mỗi shot có nhiều hành động nhỏ liên kết và biến chuyển biểu cảm, không chèn cử động thừa để lấp thời gian. Mốc timeline là số nguyên, ưu tiên `0–2s, 2–4s, 4–6s, 6–8s, 8–10s`, không dùng mốc kiểu `2.5s`. Phải khớp trạng thái giữa hai shot.

### Chuẩn video prompt

Toàn bộ chỉ dẫn kỹ thuật trong prompt viết bằng **English**; chỉ câu nhân vật thực sự nói/voiceover là **tiếng Việt nguyên văn**. Phải có lệnh không thêm người, chữ, phụ đề, logo, watermark, UI; mô tả theo Spatial Anchor, thứ tự thời gian vật lý và an toàn cho trẻ nhỏ. Google Flow, Gemini, Omni, Veo có giới hạn/cơ chế xét duyệt khác nhau; Skill không thể bảo đảm 100% tránh lỗi hay từ chối.

### Dùng với ChatGPT Work (không bắt buộc cài Codex)

1. Tải bản ZIP, giải nén để thấy `SKILL.md`, `references/`, `templates/`.
2. Tạo Project **FastAIVN Family Studio** trong ChatGPT, tải các file hướng dẫn và tham chiếu vào Project (hoặc cung cấp ZIP cho Work nếu nó đọc được).
3. Trong hướng dẫn Project ghi: “Đọc SKILL.md và các file references của FastAIVN. Nói tiếng Việt. Chỉ viết prompt video bằng tiếng Anh, thoại giữ tiếng Việt. Không bỏ qua bước duyệt kịch bản, bối cảnh, prompt.”
4. Bắt đầu yêu cầu: “Viết 5 kịch bản Gia Đình Nhỏ 20 giây có twist mạnh và biểu cảm bé Gạo. Chỉ xuất chuyện dạng text.”
5. Chọn chuyện → chốt bối cảnh → duyệt timeline → duyệt prompt → chỉ mới render nếu có công cụ và quyền kết nối phù hợp.

**Chú ý:** ChatGPT Work sử dụng tệp như tài liệu quy trình không tự động đồng nghĩa đã cài kỹ năng gốc của Codex/Claude Code hoặc có quyền truy cập Google Flow.


## Bổ sung V2.0 — ảnh gia đình và góc máy đặc tả cảm xúc

- **Nạp ảnh tham chiếu gia đình**: Có thể dùng ảnh nhóm + chân dung riêng + trang phục từng thành viên. Ghi chính xác file ảnh nào ứng với người nào, gán `CHAR_ID`, mô tả và **đợi xác nhận** trước khi khóa diện mạo. Không tự coi ảnh minh họa là ảnh thật của gia đình.
- **Khóa ảnh bối cảnh riêng**: Ảnh phòng ngủ/khách... đã duyệt chỉ khóa không gian và ánh sáng; ảnh gia đình khóa nhân vật.
- **Prompt vẽ storyboard**: Từng ảnh độc lập 9:16 (không ghép), ghi rõ nhân vật và ảnh tham chiếu được duyệt; chọn `medium shot` để biết nhân vật đứng đâu, `close-up` để đọc ánh mắt/môi/biểu cảm, `extreme close-up` có chọn lọc cho thời khắc quyết định. Không vẽ trước tình tiết chưa xảy ra.
- **Prompt tạo video**: Đưa hình tham chiếu nhân vật thực tế vào input nếu công cụ hỗ trợ; prompt tiếng Anh khóa đúng `CHAR_ID`, góc máy có chủ đích từ trung cảnh đến cận và đặc tả, diễn tả Gạo hồn nhiên/phụng phịu tinh nghịch sau đúng tác nhân. Không cần cưỡng ép đủ ba cỡ cảnh vào mọi shot 10s; ưu tiên chuyển mượt và giữ identity.
- Giữ nguyên quy trình duyệt kịch bản → bối cảnh → timeline → storyboard (khi yêu cầu) → prompt → duyệt → render. Không tự động tạo ảnh/video.
- Đọc tài liệu bắt buộc: `references/v2.0-family-reference-and-camera-language.md`.
