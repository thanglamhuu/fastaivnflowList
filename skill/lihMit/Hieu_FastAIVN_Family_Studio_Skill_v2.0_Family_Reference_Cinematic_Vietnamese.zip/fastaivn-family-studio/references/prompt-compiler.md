# English Video Prompt Compiler

## Mandatory composition

1. `OBJECTIVE & LOCKED STORY`: In 1–2 English sentences express the **approved** comedic setup, development and punchline. Do not invent new story beats.
2. `FAMILY-LIFE CONTEXT`: Accurate safe domestic context for the actual scene; age-appropriate interactions. Not a way around provider moderation. Never insert rock-paper-scissors unless it is in the actual script. Do not falsely claim footage is a real documentary.
3. `IDENTITY, OUTFIT, VOICE LOCK`: Identify each appearing person via profile IDs; keep appearance and wardrobe from approved reference, speaker ID with user-set Vietnamese regional accent, pitch, texture, age, tempo. Do not imply exact timbre from text-only if impossible. For minors restrict speech to age-appropriate phrases; infant laughter/babbling, securely supported.
4. `SCENE & SPATIAL ANCHORS`: Name concrete primary visible anchor: one character or furnishing. Define relative positions. Prefer “beside”, “between”, “facing”, “near the sofa”, “within arm's reach of the tabletop”. Anatomical left/right only when essential and named: “on Gạo's left side”. Avoid unanchored “move left/right”, “Dad on the left side of frame”. Establish stable starting positions and prop owners.
5. `ACTION ORDER`: Physically plausible stages of cause→act→react→result, with simple relative or timed beats as needed for chosen runtime. For each action include actor, hand/feet if relevant, prop, target, destination, sequence. Specify no handing over before reaching counterpart, etc. Use one main action and one strong emotion change per short shot. Do not over-stuff 8s and do not repeat initial picture action.
6. `CINEMATOGRAPHY`: ultra-high-quality photorealistic video; professional lens/configuration as appropriate; cinematic natural light, subtle micro lighting, micro shadows, micro geometry, micro highlight contrast, micro edges, micro color details, micro textures and **natural** micro skin detail. Meaningful camera movement only to support acting. Real-world physics, modest depth of field where faces remain readable. No plastic skin/CGI/oversaturation.
7. `START/END STATE & CONTINUITY`: When frames are used, preserve exact referenced visual states. When Ingredients, describe a coherent shot endpoint and asset continuity without pretending to control it perfectly. Dialogue only by approved speaker, never extra lines. Avoid unwarranted music/overlays/watermarks.

## Important specificity principles

- Make nouns explicit rather than repeated ambiguous `he/she/it` when multiple possible referents exist.
- Replace “Dad moves left, Mom turns right” with explicit destination references, e.g. “Dad turns toward Gạo seated directly beside him.”
- Do not confuse mother holding infant with also using both hands for gift transfer. Describe free hand and infant support explicitly.
- Camera movement is not inherently cinematic if it obscures faces or breaks physical continuity. Keep single stable shot where movement is unnecessary.
- Avoid redundant negative instructions; one compact constraints line is enough. Safety is grounded in actual visuals, not an incantation.
- English motion prompt may contain **Vietnamese dialogue in quotation marks**. Speaker attributes stay in English. Ensure voice assigned correctly.
- Prompt is not guaranteed to succeed; model capabilities and filters differ by provider. Do not claim all brands accept the same options.

## Voice Lock English snippet (adapt to actual approved profile)

```text
CHARACTER VOICE LOCK:
Speaker CHAR_01 (Dad): Vietnamese, natural Northern Vietnamese accent, adult male voice around 35 years old, deep warm timbre, medium-low pitch, relaxed natural tempo, clear conversational pronunciation, playful emotional delivery. Preserve the same identity across all shots. Only CHAR_01 speaks his approved Vietnamese lines. Emotional inflection may vary without changing his vocal identity.
```

## Family safety English snippet (adapt to actual scene)

```text
FAMILY-LIFE CONTEXT — IMPORTANT:
A fictionalized, photorealistic depiction of an affectionate and cheerful everyday Vietnamese family moment at home, with naturally relaxed parents and children, gentle age-appropriate play and no threatening, punitive, coercive or dangerous actions. Young children remain comfortable, physically safe and supervised. An infant is securely supported throughout any relevant interaction. Use warm, candid documentary-inspired cinematic realism. Preserve exactly the approved story and do not introduce additional actions.
```

## Cinematic core English snippet (integrate, don't indiscriminately paste in full)

```text
CINEMATIC VISUAL CORE:
Ultra-high-quality photorealistic cinema-camera aesthetics, professional exposure and lens characteristics, authentic cinematic lighting and skin tones, purposeful camera motion emphasizing the characters' facial expressions and emotional exchanges. Refined micro lighting, micro shadows, micro geometry, micro highlight contrast, micro edges, micro color details, micro textures and true-to-life micro human skin texture. Natural optics and realistic motion; avoid CGI-like polish, plastic faces, exaggerated saturation, artificial sharpness, text overlays and watermarks.
```


## V1.9 precedence and updates

Read `references/v1.9-comedy-timeline-safety.md` (relative to skill root). The V1.9 policy supersedes any older statement preferring 6/8-second shots or one isolated action per shot: prioritize 2×10 seconds for 20s videos WHEN supported; allow a coherent sequence of actions per shot; integer preferably even-second boundaries only. Strong surprising logically seeded comedy twist; child expression is key. All video instructions English, Vietnamese only literal spoken words. Exclude extras/text/subtitles/logos/watermarks/app UI. Safety and model capability checks are mandatory.


## V2.0 — Family reference & emotional cinematography (mandatory)

Read `v2.0-family-reference-and-camera-language.md`. Every storyboard image prompt AND video prompt must explicitly bind each visible character to the user-approved source family photos, if provided, and separately bind the approved scene reference. Keep visual identity exactly the same when moving between medium shots, close-ups, and selective extreme close-ups. First show the physical scene/action in a medium composition, then close-up triggered innocent, mock-pouting, adorable or mischievous expression, and extreme close-up only for a critical micro-expression when needed. Resolve the comedic punchline in a readable shot; never use endless zoom, facial distortion or hard-to-follow camera changes. Each storyboard output is one individual image, not a composite. Camera prompts and all technical content are English; only actual dialogue/voiceover is Vietnamese. Do not imply source photos are available if none were supplied.
