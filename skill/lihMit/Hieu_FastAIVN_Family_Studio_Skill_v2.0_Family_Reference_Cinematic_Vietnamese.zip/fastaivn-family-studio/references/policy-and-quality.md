# Safety, provider compatibility, approval and QA

## Priorities

1. Actual safety and applicable provider policy before aesthetics.
2. Preserve approved user narrative; if a policy-compliant adaptation substantially changes story meaning, **ask for approval**.
3. Physically coherent placement, safe child motion, stable prop ownership, sequential time.
4. Character, wardrobe, voice and scene consistency.
5. Cinematic visual quality.

## Safety context

Do not claim safety prose guarantees acceptance. Evaluate the depicted action, not simply the adjectives. Keep minors in non-sexual, nonviolent, age-appropriate contexts. Children should not be frightened, coerced, punished or exposed to unsafe forces or dangerous stunts. An infant must be supported securely; don't give speech/motor skill of an older child to a baby. Avoid fabricating an “authentic real recording” if generated. User-provided face/voice samples may require permission/consent depending on use and provider. Do not imitate another individual's voice without authorization.

## Provider capability gate

Before programmatic render, verify actual endpoint/access and supported models, clip durations, aspect ratios, first/last frame handling, Ingredients/reference restrictions, prompt length, audio/voice options, minors policy and data handling. **Google Flow UI availability does not imply a public external control API**. Gemini/Omni/Veo model family/labels may differ; don't invent endpoints or assert bypasses. If prerequisites fail, provide prepared prompts and explain clearly what can't run. No instructions for evading moderation.

## Pre-prompt review

- User explicitly selected the script? Scene approved?
- Original hook/cause/effect/punchline preserved?
- Dialogue accurately reproduced, correct speaker and voice characteristics?
- Real visible spatial anchor, no ambiguous camera-relative left/right?
- Start state does not pre-act upcoming movement? End state coherent?
- Physically plausible hand usage, walking, prop transfer and baby support?
- Shot duration suits actual number of motions and provider support?
- Cinematic micro details and purposeful camera movement appropriate?
- Child safety clearly present in action and context?
- All prompts exposed in English for approval before rendering?

## Post-render quality checks (only if real media available)

Evaluate: identity drift, clothing changes, missing/extra family members, wrong regional voice, wrong speaker, false lip sync, overly robotic motion, teleportation, contact and hand errors, unrealistic infant pose, inconsistent props, missing punchline, early punchline, too much motion for runtime, camera obscuring action, bad color/texture, bad join, extra graphics/watermark. Mark each as PASS / REWORK / CANNOT_VERIFY. For REWORK, correct the responsible prompt/asset and retry with bound. Report actual observations only; do not claim to have watched a video you cannot access.


## V1.9 precedence and updates

Read `references/v1.9-comedy-timeline-safety.md` (relative to skill root). The V1.9 policy supersedes any older statement preferring 6/8-second shots or one isolated action per shot: prioritize 2×10 seconds for 20s videos WHEN supported; allow a coherent sequence of actions per shot; integer preferably even-second boundaries only. Strong surprising logically seeded comedy twist; child expression is key. All video instructions English, Vietnamese only literal spoken words. Exclude extras/text/subtitles/logos/watermarks/app UI. Safety and model capability checks are mandatory.
