# Production rules — FastAIVN Family Studio

## 1. User-facing flow vs. production engine

User-facing: (A) establish family and references; (B) select script, scene and approve prompt; (C) render/QA/export. Internal phases are gated. Do not confuse this reusable instruction skill with a working automatic video renderer.

## 2. Stage gates

| Stage | Allowed output | Forbidden until next gate |
|---|---|---|
| Script ideation | 5 original **narrative prose** concepts in Vietnamese; title, hook, story, punchline | No timestamps, timeline, shot count, camera technicals, image, background questions, video prompt |
| User selects script | Acknowledge exact script and ask/confirm location and visual source | No image generation without scene selection/user request |
| Scene approved | Shot plan with timing, start/end states, spatial blocking and continuity | No video render |
| Prompts drafted | Full English prompts for **all** shots, Vietnamese scene overview, voice and safety context | No render until user approves all prompts |
| Prompts approved | Execute renderer if integration available and permitted; otherwise usable handoff | No claim of actual automatic generation without tool |

If user requests a narrower intermediate deliverable, answer that and do not auto-advance. If user explicitly requests both planning and prompt draft in one turn, present both but retain final prompt approval gate. If user asks to revise script, return to script approval stage.

## 3. Script prose requirements

Initial concepts target a specified total runtime (e.g., 20s) through controlled number of beats, but avoid timestamps or technical splitting. Engage viewer immediately by a readable premise and a visible physical hook; playful conflict, childlike wit, unexpected resolution. Minimize dialogue, avoid repetitive concepts, avoid high-risk physical behavior and unsafe infant actions. Explain premise through actions, not long exposition. Default 5; offer select/revise/another five. Never force personal names from demonstration family onto actual uploads. Only reference characters authorized from user profiles.

## 4. Motion planning AFTER selection

Define `shot_id`, `duration_s`, `start_state`, `action_order`, `reaction`, `end_state`, `props`, `dialogue`, `voice_id`, `spatial_anchors`, `camera_direction`. Estimate motion density. If shot consists of a single small reaction, prefer shorter durations when backend supports them. Maintain desired output runtime; plan trim/hold in edit only when no altered causality or stretched gestures. Each shot needs a meaningful transition. No need to show all characters in every frame if their role is not relevant, but if visible, identities remain consistent.

Example of a 20s plan (illustration only, NOT default): 8s + 8s + 4s. Avoid assuming all models support those durations. Use provider capability matrix at runtime, especially with references and minors.

## 5. Spatial continuity / objects

Choose a primary anchor present in the scene (e.g., Gạo, sofa, wooden table). Place each character relative to the anchor. Use anatomical left/right only with explicit owner and shared orientation; avoid screen-left/screen-right directions. Account for camera reframing but don't rewrite relative relationships. Track persistent props, e.g., gift holder=Gạo until Mom secures box and Gạo releases it; Dad's hands remain empty. Each reaction follows observed cause. Change positions only via physically possible movement and sufficient time.

## 6. Production mode consistency

Auto UX should not ask users to switch Flow modes mid-video. Select one provider/backend profile for the entire output. Ingredients is the working default for experiments, **not a guaranteed universally best mode**. Enable Frames only when configured as a separate method and supported by actual provider capabilities. For Frame runs, N sequential clips usually require N+1 boundary states: render each as a separate 9:16 image, not collage, triptych or contact sheet. Image 1 must be before first action, image 2 must equal end of clip 1/start of clip 2, etc. If one render fails, remake that image alone. Ingredients workflow may need characters, background, a consistent scene image and continuity bridge, not necessarily start/end frame pairs.

## 7. Video and QA

Prompts must be in English. Visual core strongly prefers true-to-camera textures and nuanced cinematic lighting. Avoid unnecessary camera instructions conflicting with exact frame locks. In QA: check action order, hook, punchline, identity, prop handoffs, child safety, voice regional accent, lip sync, duration and absence of stray text/watermark. Prefer shot-specific redo; enforce finite attempts and cost limits. Do not falsely guarantee perfect results.


## V1.9 precedence and updates

Read `references/v1.9-comedy-timeline-safety.md` (relative to skill root). The V1.9 policy supersedes any older statement preferring 6/8-second shots or one isolated action per shot: prioritize 2×10 seconds for 20s videos WHEN supported; allow a coherent sequence of actions per shot; integer preferably even-second boundaries only. Strong surprising logically seeded comedy twist; child expression is key. All video instructions English, Vietnamese only literal spoken words. Exclude extras/text/subtitles/logos/watermarks/app UI. Safety and model capability checks are mandatory.


## V2.0 — Reference manifest before storyboard/video

Before any storyboard image or video prompt, verify approved per-character family reference image filenames, exact character IDs, appearance/wardrobe locks, and an approved independent scene reference. Do not infer names/relationships from group photos. Storyboard shot list annotates `camera_scale` (MEDIUM/CLOSE-UP/EXTREME CLOSE-UP), `expression_trigger`, and `family_reference_files` for visible actors. Preserve spatial continuity despite cut-ins. Only use an ECU for a decisive, age-appropriate facial micro-expression. Video camera movement must be feasible for its supported 10-second duration. No image generation without user request/approval.
