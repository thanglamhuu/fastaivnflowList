# Template: Full English prompt for ONE approved shot

> This is a reusable template, not a pre-approved prompt. Populate all fields from the user-approved script and verified backend. Copy the full prompts for **every** shot into user review before rendering.

```text
FASTAIVN FAMILY STUDIO — VIDEO SHOT [ID]
Duration: [SUPPORTED_DURATION] seconds. Aspect ratio: [9:16 or user-chosen].
Approved scene objective: [precise approved dramatic beat, no invented actions].

FAMILY-LIFE CONTEXT — IMPORTANT:
[Accurate family-life context based on the actual story; age-appropriate gentle interaction, safe infant handling if relevant; photorealistic documentary-inspired fictional depiction.]

CHARACTER, OUTFIT AND VOICE LOCK:
[CHAR_ID → facial/outfit reference locks, real visible members only]
[VOICE_ID → speaker, dialect, pitch, warmth, speaking pace, approved exact dialogue]

SCENE AND SPATIAL ANCHORS:
[Primary reference object/character visible; each placement relative to it. No unanchored camera left/right.]

INITIAL PHYSICAL STATE:
[What exists exactly at the start; do not pre-complete forthcoming actions.]

ACTION ORDER:
[Time beat 1: actor → action → target → immediate physical result]
[Time beat 2: subsequent action → reaction]
[Time beat 3: final, physically attainable state]

CINEMATOGRAPHY AND MICRO DETAILS:
Ultra-high-quality photorealistic real-camera aesthetics. Professional camera configuration and purposeful cinematic camera movement supporting expressions. Natural cinema lighting, micro lighting, micro shadows, micro geometry, micro highlight contrast, micro edges, micro color details, micro textures, natural micro human skin texture. Stable optical perspective, accurate skin tones, no plastic or CGI look.

END STATE AND CONTINUITY:
[Expected condition, prop holder and locations. Match actual end frame if using Frames.]

AUDIO:
[Exactly approved Vietnamese dialogue; corresponding approved Voice ID; otherwise natural ambience only.]

CONSTRAINTS:
[Only brief, pertinent safeguards such as no additional characters, no duplicate body parts, no invented dialogue, no subtitles, no watermark. No policy-bypass instructions.]
```


## V1.9 precedence and updates

Read `references/v1.9-comedy-timeline-safety.md` (relative to skill root). The V1.9 policy supersedes any older statement preferring 6/8-second shots or one isolated action per shot: prioritize 2×10 seconds for 20s videos WHEN supported; allow a coherent sequence of actions per shot; integer preferably even-second boundaries only. Strong surprising logically seeded comedy twist; child expression is key. All video instructions English, Vietnamese only literal spoken words. Exclude extras/text/subtitles/logos/watermarks/app UI. Safety and model capability checks are mandatory.


### V2.0 REQUIRED — APPROVED FAMILY IMAGE REFERENCES AND CAMERA COVERAGE

Family reference image bindings (approved, actual supplied files only): [CHAR_ID -> actual user-provided image filename(s); state `not supplied` if missing].
Approved scene reference: [actual scene reference, or descriptive scene lock if no image].
Identity continuity: preserve every visible person's approved face, hairstyle, age appearance, body proportions and wardrobe.
Camera strategy: begin with MEDIUM SHOT to establish physical anchors and action; use CLOSE-UP after the relevant action to show Gạo's authentic playful / mock-pouting expression; use a brief EXTREME CLOSE-UP only if needed for decisive eye or lip micro-expression; restore readable framing for the visual punchline. Do not overcut or distort children's faces.
Storyboarding: write a separate single-frame image prompt for each required beat; camera scale belongs to each individual image, not a collage.
No additional people, on-screen text, subtitles, logos, watermarks or app UI.
