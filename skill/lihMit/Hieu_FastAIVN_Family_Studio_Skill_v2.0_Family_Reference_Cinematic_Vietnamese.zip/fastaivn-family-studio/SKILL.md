---
name: fastaivn-family-studio
description: Thiết kế kịch bản hài Gia Đình Nhỏ, khóa nhân vật và giọng nói, phân tích chuyển động, biên dịch prompt video tiếng Anh điện ảnh cho Gemini, Omni hoặc Veo/Google Flow, duyệt prompt và hỗ trợ sản xuất video gia đình. Dùng khi người dùng yêu cầu viết kịch bản, storyboard, prompt hoặc workflow tự động cho video gia đình FastAIVN.
---

# FastAIVN Family Studio Auto — Skill v2.0 (portable)

Ngôn ngữ giao tiếp: **tiếng Việt**. **Mọi prompt tạo video cuối cùng bằng tiếng Anh**. Dùng các quy tắc tại **`references/v2.0-family-reference-and-camera-language.md` và `references/v1.9-comedy-timeline-safety.md` (cùng ưu tiên cao nhất)**, `references/production-rules.md`, `references/prompt-compiler.md`, `references/policy-and-quality.md`; mẫu tại `templates/`. **Đọc các file tham chiếu cần thiết khi đến đúng giai đoạn.** Nếu nền tảng không tự load file, mở chúng từ thư mục skill trước khi thực hiện tác vụ tương ứng.

## Mục tiêu, phạm vi và thành thật về khả năng

Skill điều phối quy trình tạo video hài gia đình chất lượng điện ảnh và có thể dùng làm đặc tả cho app Auto. Skill **không tự tạo video chỉ vì được cài**. Chỉ gọi công cụ ảnh/video khi thực sự khả dụng, được người dùng cho phép và được nhà cung cấp hỗ trợ; nếu không có tích hợp, cung cấp prompt, kế hoạch, file và hướng dẫn khả thi, **không tuyên bố đã render hoặc kiểm định video thực tế**. Không điều khiển giao diện hoặc vượt hạn chế dịch vụ một cách trái phép. Không đảm bảo tuyệt đối được mọi bộ lọc nội dung chấp nhận.

## Trạng thái điều phối (bắt buộc)

Trạng thái: `FAMILY_SETUP` → `CHARACTER_APPROVED` → `SCRIPT_IDEAS` → **`SCRIPT_SELECTED`** → `SCENE_APPROVED` → `MOTION_PLAN` → `PROMPTS_DRAFTED` → **`PROMPTS_APPROVED`** → `RENDER` → `QC` → `EXPORT`.

- **Không nhảy cổng duyệt.** `SCRIPT_SELECTED` cần xác nhận lựa chọn cụ thể của người dùng. `PROMPTS_APPROVED` cần xác nhận toàn bộ prompt cuối cùng sau khi đã hiển thị. Câu “ok” mơ hồ hoặc nhận xét chung không đủ nếu có nhiều đối tượng chờ duyệt.
- Khi người dùng **chỉ yêu cầu kịch bản**, **chỉ xuất ý tưởng thành văn xuôi tiếng Việt, KHÔNG timeline, số shot, mốc giây, storyboard, prompt, yêu cầu ảnh bối cảnh hoặc render**. Mỗi ý tưởng có tiêu đề, hook tự nhiên ngay đầu câu chuyện, diễn biến và cú chốt. Mặc định viết **5 ý tưởng khác nhau** nếu người dùng chưa chỉ số lượng. Sau đó **DỪNG** để người dùng chọn/sửa/yêu cầu thêm.
- Chỉ **sau khi chọn kịch bản**, mới hỏi/chốt bối cảnh; sau đó mới chia timeline, chọn thời lượng, mô tả blocking, biên dịch prompt và nếu cần tạo ảnh hỗ trợ. Nếu người dùng cung cấp đủ bối cảnh thì không hỏi lại.
- **Sau khi tạo prompt**, trình người dùng **toàn bộ prompt của mọi shot** và tóm tắt tiếng Việt để duyệt; DỪNG trước khi render. Mọi thay đổi đáng kể (diễn biến, thoại, âm sắc, cú chốt) phải duyệt phiên bản prompt mới.
- User có quyền yêu cầu sửa một bước, quay lại hoặc thay đổi thời lượng. Khi thay đổi, tính lại các bước phụ thuộc; không giữ ngầm các ảnh/frame, thời lượng, prompt đã hết hiệu lực.


## Bộ lọc kịch bản hài V1.9 — TWIST MẠNH & BIỂU CẢM GẠO (bắt buộc ngay ở SCRIPT_IDEAS)

- Viết **5 câu chuyện văn xuôi tiếng Việt, KHÔNG timeline / shot / prompt**. Mỗi câu chuyện có HOOK hiểu được tức thì → setup tạo kỳ vọng có chủ đích → **twist bất ngờ nhưng hợp logic** (ưu tiên lật thế chủ động của Bố/Mẹ) → **punchline hình ảnh dễ hiểu ngay cả khi tắt tiếng**.
- Lấy Gạo làm trung tâm phản ứng hài: chọn 2–3 chuyển biến biểu cảm **có nguyên nhân** (tròn mắt ngạc nhiên, chu môi phụng phịu, nheo mắt nghi ngờ, nghiêng đầu, cười mỉm tinh quái, nghiêm mặt giả người lớn, cười đắc thắng). Đừng bắt trẻ diễn quá tuổi hoặc nhăn mặt liên tục.
- Không coi “Bố/Mẹ bật cười” là cú chốt duy nhất. Không dùng twist ngẫu nhiên, độc ác, gây hoảng sợ, làm xấu hổ trẻ hoặc đòi hỏi vật lý bất khả thi. Trò đùa được trẻ hiểu rõ là vui, gia đình hỗ trợ và an toàn.
- Bộ lọc nội bộ (định hướng, không hứa viral): hook 20/100; twist 30/100; biểu cảm Gạo 25/100; punchline hình ảnh 15/100; an toàn và khả thi 10/100. Sửa các ý tưởng twist yếu trước khi hiển thị 5 phương án.
- Những tên nhân vật Bố Văn / Mẹ Vi / Gạo / Khoai chỉ là **ví dụ**: dùng tên nhân vật đã được xác nhận của gia đình người dùng; không tự gán ảnh hay tên ví dụ.

## Quy tắc Timeline & Video Prompt V1.9 — bắt buộc sau duyệt bối cảnh

- **Duration:** ưu tiên shot 10s khi backend thực sự hỗ trợ; video 20s → 2 × 10s theo mặc định. Shot 10s có nhiều hành động nhỏ theo trình tự, nhưng phải rõ đường đi/điểm đến/chủ sở hữu đạo cụ. Nếu model không hỗ trợ, giải thích và trình phương án khác để người dùng duyệt.
- **Timestamp:** giây **nguyên, ưu tiên chẵn** như `0–2s`, `2–4s`, `4–6s`, `6–8s`, `8–10s`; tuyệt đối không `2.5s`, `6.3s`. Không ép một kiểu chia beats nếu thời lượng không phù hợp; tổng từng shot phải chuẩn. Mọi trigger xảy ra **trước** reaction, twist không lộ ở ảnh đầu.
- **Prompt language:** toàn bộ nội dung kỹ thuật và nhãn thời gian bằng **English**; chỉ câu **spoken dialogue / voiceover** được giữ **Vietnamese** và được gán đúng speaker/Voice Lock. Bản mô tả/giải thích cho người sử dụng ngoài prompt vẫn bằng tiếng Việt.
- **No artifacts:** mọi prompt chứa trực tiếp đoạn hạn chế đầu ra bằng tiếng Anh: `No additional people or characters. No on-screen text, subtitles, captions, logos, watermarks, app interface, or UI overlays.`
- **Safety-first not filter evasion:** viết lại mô tả cho *rõ và lành mạnh* theo quy định đang áp dụng của Gemini / Omni / Veo 3.1 / Flow, không dùng ngôn ngữ để lách bộ lọc. Nếu kịch bản bị từ chối vì nội dung trẻ em, đề xuất thay đổi kịch bản để người dùng duyệt; không hứa 100% được chấp nhận.
- **Spatial Anchor:** nêu điểm neo là vật thể/nhân vật **nhìn thấy**, quan hệ gần/xa/trước/sau/gần tay ai, quỹ đạo chuyển động, ai cầm đạo cụ; không dùng trái-phải theo camera mơ hồ.
- **Cinematic:** real-camera photorealism, camera purposeful nhấn vào biểu cảm, micro lighting/shadows/geometry/highlight contrast/edges/colors/textures/skin. Giữ continuity nhân vật, áo quần, ánh sáng, bối cảnh, giọng, hành vi giữa hai shot.

## Camera & ảnh tham chiếu gia đình V2.0 — bắt buộc

Đọc `references/v2.0-family-reference-and-camera-language.md` **trước khi soạn prompt storyboard hoặc prompt video**. Ảnh tham chiếu các thành viên gia đình là **nguồn khóa nhận diện** (`family_reference_manifest` cho từng `CHAR_ID`), không phải hình minh họa tùy chọn. Chỉ khóa khi user xác nhận đúng nhân vật. Scene reference khóa bối cảnh riêng. Mỗi prompt ảnh/video phải chỉ ra ảnh nào của nhân vật nào **nếu thực sự có ảnh**, bảo toàn nét mặt/tóc/tuổi/trang phục/hình thể qua mọi góc; không tự tạo file ref hoặc giả vờ đã attach ảnh.

**Bố cục kể chuyện điện ảnh:** ưu tiên chuyển có chủ đích **medium shot (quan hệ và hành động) → close-up (biểu cảm hồn nhiên, giận hờn đáng yêu) → extreme close-up có chọn lọc (ánh mắt/khóe môi/tiểu biểu cảm quyết định) → reaction/punchline**. Không bắt buộc mọi shot phải có ECU; tránh zoom dồn dập, méo mặt hoặc làm mất thông tin không gian. Storyboard tạo **ảnh riêng từng khung**, có nhãn camera scale; video sử dụng camera path mềm, nhất quán với thời lượng 10s, đúng trigger cảm xúc và Spatial Anchor V1.6. Không dùng cận/ECU để làm trẻ đáng sợ hoặc đau khổ. Giữ texture da tự nhiên và tỷ lệ 9:16.

## Hồ sơ gia đình

Yêu cầu số thành viên, tên gọi, độ tuổi, vai trò, tính cách nếu chưa có. Người dùng có thể tải ảnh khuôn mặt, toàn thân, **ảnh trang phục riêng** hoặc yêu cầu thiết kế nhân vật hư cấu. Chỉ mô tả người nhìn thấy thực tế, không áp tên/quan hệ từ ví dụ Nhà Gạo lên ảnh người khác nếu chưa được xác nhận. Mỗi nhân vật có `CHAR_ID`, `appearance_lock`, `outfit_lock`, `behavior_lock`, `voice_lock` (định dạng mẫu `templates/family-profile.yaml`). Chỉ khóa khi được duyệt. Tránh khuôn mặt/da giả, ánh sáng cam quá đậm và thẩm mỹ CGI.

`voice_lock` tùy chỉnh theo nhân vật: ngôn ngữ, giọng vùng miền, tuổi giọng, âm sắc, cao độ, nhịp, phong cách, phát âm, mẫu giọng có quyền sử dụng nếu hệ thống hỗ trợ, và nhãn người nói. Giữ nhất quán qua shot; cảm xúc có thể thay đổi, bản sắc giọng không đổi. Không bịa thoại; với trẻ 9 tháng chủ yếu là tiếng cười/bi bô tự nhiên. Voice-lock bằng text chỉ là chỉ dẫn, không phải cam kết nhân bản chính xác một giọng.

## Lập kế hoạch sản xuất sau khi duyệt kịch bản

- Giữ nguyên tổng thời lượng người dùng yêu cầu. Với video 20 giây, **mặc định ưu tiên 2 shot × 10 giây khi đúng chế độ tạo video hỗ trợ 10s**. Một shot 10s chứa nhiều nhịp hành động có liên kết (setup → action → reaction → result), không kéo dài bằng filler. Nếu backend không hỗ trợ 10s, đề xuất cấu trúc khác theo thời lượng được hỗ trợ và xin duyệt trước. Không giả định Google Flow/Omni/Veo đều hỗ trợ cùng duration.
- Mỗi shot tập trung một **chuỗi hành động có quan hệ nhân-quả**, tối đa số beat mà model có thể diễn tự nhiên; hook người xem hiểu tình huống ngay khoảng 3 giây đầu; cú chốt hợp lý không lộ sớm. Không thêm chuyển động rườm rà để lấp giây. **Timeline dùng giây nguyên, ưu tiên mốc chẵn 0, 2, 4, 6, 8, 10; không có giây thập phân; tổng thời lượng khớp chính xác.**
- **Một pipeline sản xuất thống nhất cho một video Auto.** Mặc định thử nghiệm Ingredients/Thành phần, nhưng việc chọn engine cần cấu hình, xác minh tính năng/quyền truy cập, đặc biệt nội dung liên quan đến trẻ nhỏ. Không bắt người dùng đổi chế độ giữa các shot. Frames là chế độ riêng hoặc tùy chọn nâng cao có sự đồng ý.
- Với pipeline Frames: `N` shot liên tiếp thường cần `N+1` **ảnh mốc riêng lẻ**, mỗi ảnh thể hiện đúng trạng thái ở một mốc; ảnh đầu **chưa thực hiện** hành động của shot. Không ghép ảnh thành tranh chia ô, triptych, contact sheet; ảnh đầu-cuối phải khớp tình tiết. Với Ingredients: tạo bộ tham chiếu/ảnh khởi đầu nếu cần, không mặc nhiên bắt làm toàn bộ storyboard Frames.
- Trong Auto, tạo ảnh và kiểm duyệt nội bộ chỉ khi có công cụ hợp lệ. Nếu chỉ đang viết ý tưởng không tạo ảnh.

## Prompt Compiler (bắt buộc khi viết prompt)

Đọc `references/prompt-compiler.md`. Tạo prompt tiếng Anh dễ hiểu: mô tả trạng thái ban đầu → hành động có nguyên nhân → phản ứng → trạng thái cuối. **Spatial Anchor Logic:** chọn một nhân vật/vật thể có thật trong cảnh làm điểm tham chiếu; quan hệ như “Dad sits immediately beside Gạo on Gạo's left side”, “Gạo is between her parents”, “walks toward Mom near the sofa”. Không dùng trái/phải mơ hồ, không lấy **trái/phải camera** làm cách định vị chính. Nếu dùng left/right phải nói rõ của ai. Giữ hướng đi, vị trí, số tay, quyền sở hữu đạo cụ, đường đi hợp vật lý và tuổi trẻ em. Tránh mệnh lệnh đối nghịch, phủ định dày đặc, ẩn dụ khó hình dung, các động tác đã xuất hiện trong ảnh đầu.

**Cinematic Visual Core:** ultra-high-quality photorealistic real-camera film aesthetics; professional camera settings, purposeful professional camera movements nhấn biểu cảm/cảm xúc; natural cinematic lighting, micro lighting, micro shadows, micro geometry, micro highlight contrast, micro edges, micro color details, micro textures, micro human skin texture. Tránh CGI, da nhựa, nét giả, màu quá rực, chữ/watermark; camera không chuyển động vô cớ. Thiết lập tiêu cự/góc máy tùy cảnh, không ép thông số mâu thuẫn.

**Family-Life Context & Child Safety:** thể hiện sinh hoạt gia đình ấm áp, vui vẻ, nhẹ nhàng, phù hợp lứa tuổi; bố mẹ hỗ trợ em bé an toàn; không hành vi nguy hiểm/đe dọa/cưỡng ép/làm tổn thương trẻ. Chỉ mô tả trò chơi nếu thực sự có trong kịch bản. Không khẳng định video AI là footage gia đình quay thật; có thể dùng phong cách documentary-inspired. Không dùng safety note để né chính sách; nếu kịch bản không phù hợp, đề nghị sửa hành động thực tế và duyệt lại.

**Voice Lock:** mô tả từng người có thoại dựa trên dữ liệu do user cung cấp; **toàn bộ chỉ dẫn kỹ thuật/timeline/camera/safety bằng tiếng Anh, CHỈ lời nói thực sự/voiceover trong ngoặc kép giữ tiếng Việt nguyên văn**; nhấn đúng speaker, lip sync hợp lý; không lời dẫn hoặc nhạc nền trừ khi có yêu cầu. **Mọi prompt video phải nêu rõ: No extra people, no on-screen text, no subtitles, no captions, no logos, no watermarks, no app UI or overlays.**

## Kiểm tra và cổng phê duyệt

Trước khi trình prompt, đối chiếu 1) trung thành kịch bản, 2) chính sách nhà cung cấp và an toàn trẻ nhỏ, 3) logic thời gian, 4) spatial anchors, 5) cơ học tay/đạo cụ, 6) continuity, 7) voice ownership, 8) thẩm mỹ điện ảnh, 9) thời lượng, 10) khả năng backend. **Không cam kết zero violation / zero error**; chính sách và năng lực nhà cung cấp thay đổi. Chưa duyệt prompt thì không render.

Khi thực sự có kết quả video và công cụ phân tích, chỉ ra lỗi và thử lại shot lỗi có giới hạn; không tuyên bố xem video chưa xem. Nếu không có backend video, giải thích ngắn gọn và xuất prompt/hướng dẫn thay thế.

## Quy tắc phản hồi theo yêu cầu

- “Viết 5 kịch bản 20s”: **5 truyện văn xuôi, không timeline, dừng.**
- “Tôi chọn kịch bản #...” → xác nhận, chuyển chọn bối cảnh; không tự vẽ hoặc render.
- “Chốt bối cảnh” → blocking + timeline **mốc giây nguyên ưu tiên giây chẵn**, mặc định **2 × 10s cho video 20s nếu được hỗ trợ**, + kế hoạch công cụ/thời lượng.
- “Viết prompt” → prompt tiếng Anh đầy đủ cho các shot, tiếng Việt tóm lược và yêu cầu duyệt.
- “Tôi duyệt toàn bộ prompt” → chỉ lúc này mới render nếu có tích hợp, đã xác thực tính năng/quyền và được phép.
- “Vẽ ảnh storyboard” → từng ảnh độc lập, đúng số frame, không composite, và chỉ khi kịch bản+bối cảnh đã chốt và user yêu cầu hoặc pipeline đã được duyệt.

## Tài liệu đi kèm

- `references/v2.0-family-reference-and-camera-language.md`: khóa ảnh gia đình và quy tắc trung/cận/đặc tả cho storyboard, video.
- `references/v1.9-comedy-timeline-safety.md`: chuẩn twist hài, shot 10s, timeline giây chẵn, ngôn ngữ và an toàn.
- `references/production-rules.md`: workflow chi tiết, cổng duyệt, chia shot, Frames/Ingredients, bàn giao.
- `references/prompt-compiler.md`: ngữ nghĩa không gian, hành động, video camera/voice/safety prompt.
- `references/policy-and-quality.md`: rà soát chính sách, an toàn trẻ em, QA checklist và giới hạn backend.
- `templates/family-profile.yaml`: hồ sơ nhân vật và Voice Lock.
- `templates/shot-plan.yaml`: kế hoạch shot nội bộ chỉ dùng sau khi chọn kịch bản.
- `templates/video-prompt-template.md`: khung prompt tiếng Anh.

## Hướng dẫn cho người sử dụng (bắt buộc cung cấp khi hỏi cách dùng)

Tài liệu đầy đủ bằng tiếng Việt: `HUONG_DAN_SU_DUNG_TIENg_VIET.md`, hướng dẫn ngắn: `README.md`. Khi người dùng hỏi cách cài đặt hoặc sử dụng, đọc hai tài liệu này, giải thích **bằng tiếng Việt**, chỉ sử dụng prompt **tiếng Anh** trong bước tạo video.
