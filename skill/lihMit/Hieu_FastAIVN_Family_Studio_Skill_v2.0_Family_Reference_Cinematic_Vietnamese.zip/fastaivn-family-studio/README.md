# FASTAIVN FAMILY STUDIO — HƯỚNG DẪN NHANH (TIẾNG VIỆT)

**Skill V2.0 cho Codex và Claude Code.**

👉 **Đọc tài liệu chi tiết:** [`HUONG_DAN_SU_DUNG_TIENg_VIET.md`](HUONG_DAN_SU_DUNG_TIENg_VIET.md).

## Cài đặt trên Windows

Giải nén ZIP, giữ nguyên thư mục `fastaivn-family-studio` và tất cả file bên trong.

- **Codex:** chép vào `$HOME\.agents\skills\fastaivn-family-studio\`
- **Claude Code:** chép vào `$HOME\.claude\skills\fastaivn-family-studio\`

Đường dẫn bên trong phải có file `SKILL.md`. Nếu đã cài bản cũ, thay thế thư mục cũ để tránh trộn hướng dẫn. Mở phiên làm việc mới.

## Cách dùng

Gõ trong Codex hoặc Claude Code:

```text
Dùng skill fastaivn-family-studio, viết 5 kịch bản hài gia đình 20 giây.
Chỉ viết câu chuyện bằng text, chưa có timeline.
```

Sau khi AI trình kịch bản, trả lời `Tôi chọn kịch bản 2.`. Từ đó Skill mới hỏi/chốt bối cảnh, chia timeline, viết prompt tạo video **bằng tiếng Anh** và trình toàn bộ prompt để bạn duyệt trước khi render.

## Những điều cần biết

- **Nội dung giao tiếp và hướng dẫn:** tiếng Việt. **Prompt video cuối:** tiếng Anh.
- Hai cổng duyệt bắt buộc: **chọn kịch bản** và **duyệt prompt**.
- Khóa nhân vật, trang phục, giọng nói vùng miền, đặc điểm giọng, bối cảnh và đạo cụ.
- Không tự chia timeline ở giai đoạn đề xuất kịch bản.
- Lập kế hoạch chuyển động theo **Spatial Anchor** để hạn chế hiểu nhầm không gian.
- Đảm bảo miêu tả sinh hoạt gia đình và trẻ nhỏ an toàn; tuân thủ chính sách dịch vụ thực tế.
- Skill **không tự tích hợp** Google Flow, Omni hoặc Veo API. Không có công cụ dựng phù hợp thì Skill chỉ tạo tài nguyên, prompt và hướng dẫn thực hiện.

**Bộ file:** `SKILL.md`, `README.md`, `HUONG_DAN_SU_DUNG_TIENg_VIET.md`, `references/`, `templates/`.

## Điểm mới V2.0

- **5 kịch bản đầu:** twist bất ngờ nhưng hợp lý, diễn biến đủ gây cười, bé Gạo (hoặc nhân vật bé đã khóa) có chuỗi biểu cảm ngộ nghĩnh; **chỉ văn xuôi**, chưa chia shot/timeline.
- **Video 20s:** mặc định **2 shot × 10s** nếu model hỗ trợ; mỗi shot chứa chuỗi hành động có nguyên nhân–phản ứng–kết quả.
- **Timeline:** mốc giây nguyên, ưu tiên **0/2/4/6/8/10**, không mốc thập phân.
- **Prompt video:** chỉ dẫn **tiếng Anh**, riêng **thoại/voiceover giữ tiếng Việt**. Không thêm người/chữ/phụ đề/logo/watermark/giao diện.
- Kiểm tra an toàn nội dung trẻ nhỏ theo khả năng/chính sách model thực tế; không hứa tránh mọi lần từ chối.

**Sử dụng riêng với ChatGPT Work:** tải `SKILL.md`, toàn bộ `references/` và `templates/` vào cùng Project (hoặc đính kèm ZIP/tệp mà Work có thể đọc), yêu cầu Work đọc quy tắc và đi theo cổng duyệt. Đây là **sử dụng tài liệu workflow**, không đồng nghĩa Work tự cài hoặc đăng ký một native Skill như Codex.


## Bổ sung V2.0 — ảnh gia đình và góc máy đặc tả cảm xúc

- **Nạp ảnh tham chiếu gia đình**: Có thể dùng ảnh nhóm + chân dung riêng + trang phục từng thành viên. Ghi chính xác file ảnh nào ứng với người nào, gán `CHAR_ID`, mô tả và **đợi xác nhận** trước khi khóa diện mạo. Không tự coi ảnh minh họa là ảnh thật của gia đình.
- **Khóa ảnh bối cảnh riêng**: Ảnh phòng ngủ/khách... đã duyệt chỉ khóa không gian và ánh sáng; ảnh gia đình khóa nhân vật.
- **Prompt vẽ storyboard**: Từng ảnh độc lập 9:16 (không ghép), ghi rõ nhân vật và ảnh tham chiếu được duyệt; chọn `medium shot` để biết nhân vật đứng đâu, `close-up` để đọc ánh mắt/môi/biểu cảm, `extreme close-up` có chọn lọc cho thời khắc quyết định. Không vẽ trước tình tiết chưa xảy ra.
- **Prompt tạo video**: Đưa hình tham chiếu nhân vật thực tế vào input nếu công cụ hỗ trợ; prompt tiếng Anh khóa đúng `CHAR_ID`, góc máy có chủ đích từ trung cảnh đến cận và đặc tả, diễn tả Gạo hồn nhiên/phụng phịu tinh nghịch sau đúng tác nhân. Không cần cưỡng ép đủ ba cỡ cảnh vào mọi shot 10s; ưu tiên chuyển mượt và giữ identity.
- Giữ nguyên quy trình duyệt kịch bản → bối cảnh → timeline → storyboard (khi yêu cầu) → prompt → duyệt → render. Không tự động tạo ảnh/video.
- Đọc tài liệu bắt buộc: `references/v2.0-family-reference-and-camera-language.md`.
