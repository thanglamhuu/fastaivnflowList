import { Flow } from 'flow-sdk';
import { MasterScriptData, ProductAnalysis, VoiceMaster } from './types';

/**
 * Utility to extract JSON from AI response.
 */
function parseJson(input: string): any {
  if (!input || !input.trim()) throw new Error('Dữ liệu trả về từ AI trống.');
  let text = input.trim();
  text = text.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();
  try {
    return JSON.parse(text);
  } catch {
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start !== -1 && end !== -1) return JSON.parse(text.slice(start, end + 1));
  }
  throw new Error('Không thể phân tích định dạng kịch bản.');
}

export const ExistingScriptService = {
  /**
   * Adapts an existing Vietnamese script into 4 structured scenes.
   */
  async adaptExistingScript({ existingScript, analysis, duration, voiceMaster, handAction }: { 
    existingScript: string, 
    analysis: ProductAnalysis | null, 
    duration: string, 
    voiceMaster: VoiceMaster,
    handAction: string
  }): Promise<MasterScriptData> {
    const totalSec = parseInt(duration) || 24;
    const secPerScene = totalSec / 4;
    // Estimated words per second for Vietnamese at 1.0x speed is ~3.5
    const wordsPerSec = 3.5 * voiceMaster.speakingSpeed;
    // Reserve 1 second for physical action/sensory focus per scene
    const capacityPerScene = Math.floor((secPerScene - 1) * wordsPerSec);

    const systemInstruction = `
      You are an Expert Script Editor for TikTok POV reviews.
      Task: Adapt a provided Vietnamese script into EXACTLY 4 structured scenes for a ${duration} video.
      
      STRICT CONSTRAINTS:
      - Return coreIdea, heroSellingPoint, voiceOver, suggestedAction, and cta in natural Vietnamese.
      - EXPLICITLY NEVER translate the user's Vietnamese input into English.
      - Preserve ALL original Vietnamese wording, facts, and order.

      - Split the script into EXACTLY 4 scenes.
      - Duration: ${secPerScene}s per scene (Total: ${duration}).
      - Capacity: Approximately ${capacityPerScene} words per scene (based on speaking speed ${voiceMaster.speakingSpeed}x).
      - PRESERVE: All original Vietnamese wording, facts, and order.
      - DO NOT: Invent new claims, repeat information, or repeat the CTA.
      - SILENCE: Allow silence if the original text is short.
      - ACTION: suggestedAction must be a concrete, unique physical action matching the scene dialogue.
      - HAND ACTION: Honor user setting: ${handAction}.
      
      Return VALID JSON ONLY:
      {
        "coreIdea": "Tóm tắt tiếng Việt",
        "heroSellingPoint": "Điểm bán hàng tiếng Việt",
        "scenes": [
          { 
            "sceneNumber": 1, 
            "voiceOver": "Lời thoại gốc tiếng Việt", 
            "timeRange": "0s-${secPerScene}s", 
            "durationSeconds": ${secPerScene}, 
            "suggestedAction": "Hành động tiếng Việt" 
          },
          ... up to scene 4
        ],
        "cta": "Lời kêu gọi gốc tiếng Việt"
      }
    `;

    const identityContext = analysis ? `
      [Product Context]
      Name: ${analysis.foodContentMaster.productType}
      Texture: ${analysis.foodContentMaster.surfaceTexture}
      Packaging: ${analysis.packageMaster.packagingDescription}
    ` : '';

    const prompt = `
      Existing Script: "${existingScript}"
      Video Duration: ${duration}
      Speaking Speed: ${voiceMaster.speakingSpeed}x
      Hand Action Setting: ${handAction}
      ${identityContext}
    `;

    const { text } = await Flow.generate.text(prompt, { systemInstruction });
    const data = parseJson(text);
    
    return {
      ...data,
      isManual: true
    };
  }
};
