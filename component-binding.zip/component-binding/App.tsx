import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Flow } from 'flow-sdk';
import { 
  SectionLabel, 
  PillButton, 
  TextInput, 
  SegmentedToggle,
  FieldDropdown
} from './components/Primitives';
import { PromptService, normalizeAnalysis } from './services/PromptService';
import { ExistingScriptService } from './ExistingScriptService';
import { ResultView } from './components/ResultView';
import { StoryboardCard } from './components/StoryboardCard';
import { ReferenceGrid } from './components/ReferenceGrid';
import { ProductAnalysisCard } from './components/ProductAnalysisCard';
import { MasterScriptCard } from './components/MasterScriptCard';
import { BatchTaskBoard } from './components/BatchTaskBoard';
import { 
  MasterScriptData, StoryboardData, StoryboardStatus, 
  VIETNAMESE_VOICES, ProductAnalysis, VoiceMaster, 
  LicenseSession, BatchTask, TaskStatus 
} from './types';
import { LicenseService } from './services/LicenseService';
import { VoiceSettingsModal } from './components/VoiceSettingsModal';
import { BatchWorkflowService, BatchOptions } from './services/BatchWorkflowService';

export const VIDEO_MODELS = [
  "Omni Flash",
  "Veo 3.1 - Fast",
  "Veo 3.1 - Lite",
  "Veo 3.1 - Quality",
  "Veo 3.1 - Lite [Lower Priority]"
];

export const VIDEO_MODEL_LABELS: Record<string, string> = {
  "Omni Flash": "Omni Flash: Tạo nhanh, phù hợp review có lời thoại",
  "Veo 3.1 - Fast": "Veo 3.1 - Fast: Tốc độ nhanh",
  "Veo 3.1 - Lite": "Veo 3.1 - Lite: Tiết kiệm tài nguyên",
  "Veo 3.1 - Quality": "Veo 3.1 - Quality: Ưu tiên chất lượng",
  "Veo 3.1 - Lite [Lower Priority]": "Veo 3.1 - Lite [LP]: Ưu tiên thấp (Tiết kiệm)"
};

export const HAND_ACTIONS = [
  { value: 'AUTO', label: 'Tự động' },
  { value: 'Pick Up', label: 'Cầm lên' },
  { value: 'Tear', label: 'Xé mở' },
  { value: 'Break', label: 'Bẻ gãy' },
  { value: 'Dip', label: 'Chấm sốt' },
  { value: 'POV Eat', label: 'Thử đồ ăn (POV)' }
];

export type AppStep =
  | 'idle'
  | 'analyzing'
  | 'scripting'
  | 'importing'
  | 'storyboarding'
  | 'planning';

export type AppMode = 'single' | 'batch';

export default function App() {
  const [mode, setMode] = useState<AppMode>('single');
  const [step, setStep] = useState<AppStep>('idle');
  const [productName, setProductName] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [duration, setDuration] = useState('24s');
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '16:9'>('9:16');
  const [globalModel, setGlobalModel] = useState("Veo 3.1 - Lite");
  const [handAction, setHandAction] = useState('AUTO');
  
  const [references, setReferences] = useState<(any | null)[]>([null, null, null, null, null, null, null]);
  const [identityLocked, setIdentityLocked] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [productAnalysis, setProductAnalysis] = useState<ProductAnalysis | null>(null);
  const [masterScript, setMasterScript] = useState<MasterScriptData | null>(null);
  const [scriptStatus, setScriptStatus] = useState<'DRAFT' | 'LOCKED'>('DRAFT');
  const [storyboard, setStoryboard] = useState<StoryboardData | null>(null);
  const [storyboardStatus, setStoryboardStatus] = useState<StoryboardStatus>('DRAFT');
  const [result, setResult] = useState<any>(null);

  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [manualScriptText, setManualScriptText] = useState('');

  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [voiceMaster, setVoiceMaster] = useState<VoiceMaster>({
    voiceName: 'An (Tây)', baseStyle: 'Sweet', language: 'Vietnamese', accent: 'Miền Tây / Nam Bộ', ageImpression: 'Trẻ 18–22',
    tone: 'ngọt, trong, trẻ trung, dễ thương', delivery: 'TikTok tự nhiên', speakingSpeed: 1.2, 
    customStyleInstruction: 'Giọng nữ trẻ tự nhiên, trong trẻo, ngọt nhẹ, không đọc quảng cáo cứng.'
  });

  // --- BATCH STATE ---
  const [batchTasks, setBatchTasks] = useState<BatchTask[]>([
    { id: '1', productName: '', references: [null, null, null, null, null, null, null], status: 'idle', progress: 0, currentScene: 0, error: null, result: null },
    { id: '2', productName: '', references: [null, null, null, null, null, null, null], status: 'idle', progress: 0, currentScene: 0, error: null, result: null },
    { id: '3', productName: '', references: [null, null, null, null, null, null, null], status: 'idle', progress: 0, currentScene: 0, error: null, result: null }
  ]);
  const [isBatchRunning, setIsBatchRunning] = useState(false);
  const isStoppingRef = useRef(false);

  // --- LICENSE STATE ---
  const [machineId, setMachineId] = useState<string>("");
  const [session, setSession] = useState<LicenseSession | null>(null);
  const [licenseKeyInput, setLicenseKeyInput] = useState("");
  const [licenseError, setLicenseError] = useState<string | null>(null);
  const [isActivating, setIsActivating] = useState(false);
  const [licenseReady, setLicenseReady] = useState(false);
  const [timeLeft, setTimeLeft] = useState<string>("");
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied' | 'fallback'>('idle');
  
  const sessionRef = useRef<LicenseSession | null>(null);
  const machineIdTextRef = useRef<HTMLElement>(null);

  useEffect(() => { sessionRef.current = session; }, [session]);

  useEffect(() => {
    let cancelled = false;
    const initLicense = async () => {
      try {
        const id = await LicenseService.getMachineId();
        if (cancelled) return;
        setMachineId(id);
        
        let online: LicenseSession | null = null;
        try {
          online = await LicenseService.resumeOnline(id);
        } catch (serverErr: any) {
          LicenseService.clearSavedSession();
          throw serverErr; 
        }

        if (cancelled) return;
        if (online) {
          setSession(online);
          LicenseService.saveSession(online);
        } else {
          const cachedOnline = LicenseService.getOnlineCache(id);
          if (cancelled) return;
          if (cachedOnline) {
            setSession(cachedOnline);
          } else {
            const offline = await LicenseService.restoreSession(id);
            if (cancelled) return;
            if (offline) setSession(offline);
          }
        }
      } catch (err: any) {
        if (!cancelled) setLicenseError(err.message);
      } finally {
        if (!cancelled) setLicenseReady(true);
      }
    };
    initLicense().catch(e => console.error("License Init Failed:", e));
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!session?.isOnline || !session?.token) return;
    const interval = setInterval(() => {
      const runHeartbeat = async () => {
        const current = sessionRef.current;
        if (!current?.isOnline || !current?.token) return;
        try {
          const { token, expiresAt } = await LicenseService.heartbeat(current.token);
          setSession(prev => prev ? { ...prev, token, expiresAt } : null);
        } catch (err: any) {
          if (err.status === 401 || err.status === 403) {
            try {
              const resumed = await LicenseService.resumeOnline(current.machineId);
              if (resumed) {
                setSession(resumed);
                LicenseService.saveSession(resumed);
              } else { setSession(null); }
            } catch { setSession(null); }
          }
        }
      };
      runHeartbeat().catch(e => console.error("Heartbeat Loop Error:", e));
    }, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [session?.isOnline, session?.token]);

  useEffect(() => {
    if (!session) return;
    const timer = setInterval(() => {
      const now = Math.floor(Date.now() / 1000);
      const diff = session.expiresAt - now;
      if (diff <= 0) {
        LicenseService.clearSavedSession();
        setSession(null);
        setLicenseError("Mã kích hoạt đã hết hạn.");
      } else {
        const d = Math.floor(diff / 86400), h = Math.floor((diff % 86400) / 3600), m = Math.floor((diff % 3600) / 60), s = diff % 60;
        setTimeLeft(diff >= 86400 ? `${d} ngày ${h} giờ ${m} phút` : `${h} giờ ${m} phút ${s} giây`);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [session]);

  const validateAccess = useCallback(() => {
    if (!session) return false;
    const now = Math.floor(Date.now() / 1000);
    if (session.expiresAt <= now) {
      setSession(null);
      return false;
    }
    return true;
  }, [session]);

  const handleCopyMachineId = async () => {
    let success = false;
    if (window.isSecureContext && navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(machineId);
        success = true;
      } catch (err) {
        console.warn("Clipboard API copy failed", err);
      }
    }
    if (!success) {
      const textArea = document.createElement("textarea");
      textArea.value = machineId;
      textArea.style.position = "fixed";
      textArea.style.left = "-9999px";
      textArea.style.top = "0";
      textArea.style.opacity = "0";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        success = document.execCommand('copy');
      } catch (err) {
        console.warn("execCommand fallback failed", err);
      } finally {
        document.body.removeChild(textArea);
      }
    }
    if (success) {
      setCopyStatus('copied');
      setTimeout(() => setCopyStatus('idle'), 2000);
    } else {
      if (machineIdTextRef.current) {
        const range = document.createRange();
        range.selectNodeContents(machineIdTextRef.current);
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
          selection.addRange(range);
        }
      }
      setCopyStatus('fallback');
      setTimeout(() => setCopyStatus('idle'), 6000);
    }
  };

  const referenceSlotLimit = (globalModel.includes("Omni")) ? 7 : 3;
  const activeReferences = references.slice(0, referenceSlotLimit);

  useEffect(() => {
    const id = 'flow-design-system-css';
    if (document.getElementById(id)) return;
    const style = document.createElement('style');
    style.id = id;
    style.textContent = `
      :root { --bbq-bg: #FFFFFF; --bbq-sidebar: #F9FAFB; --bbq-card: #FFFFFF; --bbq-border: #E5E7EB; --bbq-primary: #FF7A1A; --bbq-text: #111827; }
      .custom-scrollbar { scrollbar-width: thin; scrollbar-color: var(--bbq-border) transparent; }
      .custom-scrollbar::-webkit-scrollbar { width: 5px; }
      .custom-scrollbar::-webkit-scrollbar-thumb { background: var(--bbq-border); border-radius: 10px; }
      html, body, #root { background: var(--bbq-bg); font-family: 'Google Sans Text', sans-serif; height: 100%; width: 100%; margin: 0; padding: 0; color: var(--bbq-text); font-size: 14px; }
      .bbq-pattern { background-image: radial-gradient(var(--bbq-border) 1px, transparent 1px); background-size: 24px 24px; opacity: 0.4; position: fixed; inset: 0; pointer-events: none; z-index: 0; }
      .bbq-glow-tr { background: radial-gradient(circle at top right, rgba(255, 122, 26, 0.05), transparent 50%); position: fixed; inset: 0; pointer-events: none; }
      .bbq-glow-bl { background: radial-gradient(circle at bottom left, rgba(255, 122, 26, 0.05), transparent 50%); position: fixed; inset: 0; pointer-events: none; }
      @keyframes slide-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      .animate-slide-up { animation: slide-up 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      @keyframes shake { 0%, 100% { transform: translateX(0); } 20%, 60% { transform: translateX(-2px); } 40%, 80% { transform: translateX(2px); } }
      .animate-shake { animation: shake 0.4s ease-in-out; }
      @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
      .animate-fade-in { animation: fade-in 0.5s ease-out forwards; }
      @keyframes dropdown-enter { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
      .animate-dropdown { animation: dropdown-enter 0.2s ease-out forwards; }
    `;
    document.head.appendChild(style);
  }, []);

  const handleAnalyze = async () => {
    if (!validateAccess()) return;
    if (!activeReferences.some(r => r !== null)) {
      setError('Vui lòng thêm ít nhất một ảnh sản phẩm.'); return;
    }
    setError(null); setStep('analyzing');
    try {
      const rawAnalysis = await PromptService.analyzeProduct({ productName, productDesc, references: activeReferences });
      setProductAnalysis(normalizeAnalysis(rawAnalysis)); setIdentityLocked(true);
    } catch (err: any) { setError(err.message || 'Hệ thống đang bận. Thử lại sau.'); } finally { setStep('idle'); }
  };

  const handleGenerateScript = async () => {
    if (!validateAccess()) return;
    setError(null); setStep('scripting');
    try {
      const data = await PromptService.generateMasterScript({ analysis: productAnalysis, productName, productDesc, duration, voiceMaster, handAction });
      setMasterScript(data); setScriptStatus('DRAFT'); setStoryboard(null); setResult(null);
    } catch (err: any) { setError(err.message || 'Lỗi tạo kịch bản.'); } finally { setStep('idle'); }
  };

  const handleImportManualScript = async () => {
    if (!validateAccess() || !manualScriptText.trim()) return;
    setError(null); setStep('importing');
    try {
      const data = await ExistingScriptService.adaptExistingScript({ existingScript: manualScriptText, analysis: productAnalysis, duration, voiceMaster, handAction });
      setMasterScript(data); setScriptStatus('DRAFT'); setStoryboard(null); setResult(null);
      setIsImportModalOpen(false); setManualScriptText('');
    } catch (err: any) { setError(err.message || 'Lỗi xử lý kịch bản nhập.'); } finally { setStep('idle'); }
  };

  const handleGenerateStoryboard = async () => {
    if (!validateAccess()) {
      setError('Phiên bản quyền đã hết hạn.');
      return;
    }
    if (!masterScript || scriptStatus !== 'LOCKED') return;

    setStep('storyboarding');
    setError(null);

    const isNonRetryableStoryboardError = (msg: string) => {
      const m = msg.toLowerCase();
      return m.includes('safety') || m.includes('policy') || m.includes('credit') || 
             m.includes('quota') || m.includes('license') || m.includes('expired');
    };

    try {
      const plan = await PromptService.createStoryboardPlan({ 
        analysis: productAnalysis, 
        scriptData: masterScript, 
        productName, 
        references: activeReferences 
      });

      if (!Array.isArray(plan?.scenes) || plan.scenes.length === 0) {
        throw new Error('Không nhận được danh sách cảnh storyboard hợp lệ. Vui lòng thử lại.');
      }

      setStoryboard(plan);
      setStoryboardStatus('DRAFT');

      let failedCount = 0;
      let firstError = '';

      for (const scene of plan.scenes) {
        if (!validateAccess()) {
          throw new Error('Phiên bản quyền đã hết hạn.');
        }

        setStoryboard(prev => prev ? {
          ...prev,
          scenes: prev.scenes.map(s => s.sceneNumber === scene.sceneNumber ? { ...s, generationStatus: 'generating', generationError: undefined } : s)
        } : null);

        const attemptGeneration = async (attemptNum: number): Promise<any> => {
          try {
            return await PromptService.generateStoryboardFrame({
              scene,
              analysis: productAnalysis,
              references: activeReferences,
              aspectRatio
            });
          } catch (err: any) {
            const msg = err.message || '';
            if (attemptNum === 1 && !isNonRetryableStoryboardError(msg)) {
              return await attemptGeneration(2);
            }
            throw err;
          }
        };

        try {
          const image = await attemptGeneration(1);
          setStoryboard(prev => prev ? {
            ...prev,
            scenes: prev.scenes.map(s => s.sceneNumber === scene.sceneNumber ? { ...s, storyboardImage: image, generationStatus: 'done' } : s)
          } : null);
        } catch (sceneErr: any) {
          failedCount++;
          const friendlyMsg = PromptService.getFriendlyErrorMessage(sceneErr);
          if (!firstError) firstError = friendlyMsg;
          setStoryboard(prev => prev ? {
            ...prev,
            scenes: prev.scenes.map(s => s.sceneNumber === scene.sceneNumber ? { ...s, generationStatus: 'error', generationError: friendlyMsg } : s)
          } : null);
        }
      }

      if (failedCount === plan.scenes.length) {
        setError('Không thể tạo ảnh storyboard. ' + firstError);
      } else if (failedCount > 0) {
        setError('Một số ảnh storyboard chưa tạo được. Bấm Tạo lại ở cảnh lỗi.');
      }

    } catch (err: any) {
      setError(err.message || 'Không thể tạo storyboard. Vui lòng thử lại.');
    } finally {
      setStep('idle');
    }
  };

  const updateTask = (id: string, updates: Partial<BatchTask>) => {
    setBatchTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const runBatchTasks = async () => {
    if (!validateAccess()) return;
    const readyTasks = batchTasks.filter(t => t.productName.trim() !== '' && t.references.some(r => r !== null) && t.status !== 'completed');
    if (readyTasks.length === 0) return;

    setIsBatchRunning(true);
    isStoppingRef.current = false;
    
    setBatchTasks(prev => prev.map(t => readyTasks.find(rt => rt.id === t.id) ? { ...t, status: 'queued', progress: 0, error: null } : t));
    
    const batchOptions: BatchOptions = {
      globalModel,
      voiceMaster,
      handAction,
      duration,
      aspectRatio
    };

    await Promise.allSettled(readyTasks.map(async (task) => {
      if (isStoppingRef.current) return;
      try {
        await BatchWorkflowService.executeTask(
          task, 
          batchOptions, 
          (updates) => updateTask(task.id, updates),
          validateAccess
        );
      } catch (e) {
        console.error(`Batch Task ${task.id} Error:`, e);
      }
    }));

    setIsBatchRunning(false);
  };

  const stopBatch = () => {
    isStoppingRef.current = true;
    setBatchTasks(prev => prev.map(t => t.status === 'queued' ? { ...t, status: 'idle' } : t));
    setIsBatchRunning(false);
  };

  const resetTask = (id: string) => {
    updateTask(id, { productName: '', references: [null, null, null, null, null, null, null], status: 'idle', progress: 0, currentScene: 0, error: null, result: null });
  };

  const handleLoadTaskToSingle = (task: BatchTask) => {
    if (!task.result) return;
    setProductName(task.productName);
    setReferences(task.references);
    setProductAnalysis(task.result.analysis);
    setMasterScript(task.result.script);
    setStoryboard(task.result.storyboard);
    setScriptStatus('LOCKED');
    setStoryboardStatus('LOCKED');
    setIdentityLocked(true);
    setMode('single');
  };

  const handleActivate = async () => {
    const key = licenseKeyInput.trim();
    if (!key || !machineId) return;
    setIsActivating(true);
    setLicenseError(null);
    try {
      let s: LicenseSession;
      if (key.startsWith('STTV-')) {
        s = await LicenseService.activateOnline(key, machineId);
        LicenseService.saveSession(s);
      } else if (key.startsWith('STTV1.')) {
        s = await LicenseService.verifyKey(key, machineId);
        LicenseService.saveSession(s);
      } else { throw new Error("Định dạng mã không hợp lệ."); }
      setSession(s);
      setLicenseKeyInput("");
    } catch (err: any) { setLicenseError(err.message || "Lỗi kích hoạt."); } finally { setIsActivating(false); }
  };

  if (!licenseReady) {
    return (
      <div className="flex h-screen w-screen bg-white items-center justify-center font-sans">
        <div className="flex flex-col items-center gap-4 animate-fade-in">
          <div className="w-12 h-12 border-4 border-orange-100 border-t-[#FF7A1A] rounded-full animate-spin" />
          <p className="text-[12px] font-bold text-[#FF7A1A] uppercase tracking-widest">Kiểm tra giấy phép...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="flex h-screen w-screen bg-white items-center justify-center p-6 font-sans relative">
        <div className="bbq-glow-tr" /><div className="bbq-glow-bl" /><div className="bbq-pattern" />
        <div className="relative w-full max-w-md bg-white border border-gray-200 rounded-[32px] p-8 flex flex-col gap-6 shadow-2xl animate-fade-in">
          <div className="flex flex-col items-center text-center gap-2">
            <div className="w-16 h-16 bg-[#FF7A1A]/10 rounded-2xl flex items-center justify-center mb-2">
               <span className="material-symbols-outlined text-4xl text-[#FF7A1A]">lock</span>
            </div>
            <h1 className="text-2xl font-black tracking-tighter uppercase text-[#111827]">POV ĐỒ ĂN VẶT</h1>
            <p className="text-[10px] text-[#6B7280] uppercase tracking-widest font-bold">YÊU CẦU MÃ KÍCH HOẠT (STTV1. HOẶC STTV-)</p>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-start px-1 min-h-[16px]">
              <label className="text-[11px] font-black text-[#6B7280] uppercase tracking-widest">Mã máy (Machine ID)</label>
              {copyStatus === 'copied' && <span className="text-[10px] text-[#10B981] font-bold animate-fade-in">Đã sao chép</span>}
              {copyStatus === 'fallback' && (
                <span className="text-[9px] text-[#FF7A1A] font-bold animate-fade-in text-right max-w-[220px] leading-tight">
                  Trình duyệt đang chặn sao chép tự động. Mã đã được bôi đen — nhấn Ctrl+C để sao chép.
                </span>
              )}
            </div>
            <div className="flex gap-2 bg-gray-50 border border-gray-200 p-3 rounded-2xl items-center justify-between">
              <code ref={machineIdTextRef} className="text-[14px] font-mono font-bold text-[#111827]/80">{machineId}</code>
              <button 
                onClick={handleCopyMachineId} 
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Sao chép mã máy"
              >
                <span className="material-symbols-outlined text-[18px]">content_copy</span>
              </button>
            </div>
          </div>
          <textarea value={licenseKeyInput} onChange={(e) => setLicenseKeyInput(e.target.value)} placeholder="Dán mã kích hoạt vào đây..."
              className="w-full h-32 bg-gray-50 border border-gray-200 rounded-2xl p-4 text-[13px] font-mono text-[#111827]/80 outline-none focus:border-[#FF7A1A]/40 transition-all resize-none custom-scrollbar" />
          {licenseError && <div className="p-3 bg-red-50 border border-red-100 rounded-xl animate-shake"><p className="text-[12px] text-red-800">{licenseError}</p></div>}
          <PillButton variant="solid" onClick={handleActivate} disabled={isActivating || !licenseKeyInput.trim() || !machineId}>
            {isActivating ? 'ĐANG XÁC THỰC...' : 'KÍCH HOẠT NGAY'}
          </PillButton>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen bg-white text-[#111827] overflow-hidden flex-col lg:flex-row relative">
      <div className="bbq-glow-tr" /><div className="bbq-glow-bl" /><div className="bbq-pattern" />
      <div className="relative border-b lg:border-b-0 lg:border-r border-gray-200 flex flex-col items-start justify-between px-[10px] py-[12px] w-full lg:w-[360px] h-auto lg:h-full bg-[#F9FAFB] shrink-0 z-10">
        <div className="flex flex-col gap-[24px] items-start w-full overflow-y-auto pr-1 custom-scrollbar pb-4 h-full">
          <div className="px-2 flex flex-col">
            <h1 className="text-xl font-black tracking-tighter text-[#111827]">POV ĐỒ ĂN VẶT</h1>
            <div className="flex items-center gap-2 mt-0.5">
               <p className="text-[10px] text-[#10B981] uppercase font-bold tracking-widest">Review Sản phẩm POV</p>
               <span className="w-1 h-1 bg-gray-300 rounded-full" />
               <p className="text-[10px] text-[#6B7280] font-black">{session.licenseName}</p>
            </div>
          </div>

          <div className="w-full px-2">
            <SegmentedToggle 
              value={mode} 
              onChange={(v) => setMode(v as AppMode)}
              items={[
                { value: 'single', label: 'Từng SP', icon: <span className="material-symbols-outlined text-[18px]">person</span> },
                { value: 'batch', label: 'Batch (3 SP)', icon: <span className="material-symbols-outlined text-[18px]">view_module</span> }
              ]} 
            />
          </div>

          <div className="w-full px-2">
            <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3 flex flex-col gap-1.5">
               <div className="flex justify-between items-center">
                 <span className="text-[9px] font-black text-emerald-600/40 uppercase tracking-widest">Mã kích hoạt {session.isOnline ? '(Online)' : '(Offline)'}</span>
               </div>
               <div className="flex justify-between items-end">
                 <code className="text-[10px] font-mono text-emerald-800/60">{session.key.substring(0, 12)}...</code>
                 <div className="flex flex-col items-end">
                    <span className="text-[8px] text-gray-400 font-black uppercase">Còn lại</span>
                    <span className="text-[10px] font-black text-[#F59E0B] tracking-tighter">{timeLeft}</span>
                 </div>
               </div>
            </div>
          </div>

          {mode === 'single' && (
            <div className="flex flex-col gap-2 w-full">
              <div className="flex flex-col gap-0.5 px-2">
                <SectionLabel>Ảnh tham chiếu {identityLocked && '🔒'}</SectionLabel>
                <p className="text-[9px] font-bold text-[#FF7A1A] uppercase tracking-tight">{(globalModel.includes("Omni")) ? "Omni: tối đa 7 ảnh" : "Tối đa 3 ảnh"}</p>
              </div>
              <ReferenceGrid images={activeReferences} onAdd={async (i) => { const s = await Flow.media.select({ filter: 'image' }); if(s) { const n = [...references]; n[i] = s; setReferences(n); } }} onClear={() => setReferences([null, null, null, null, null, null, null])} isLocked={identityLocked} detectedReferences={productAnalysis?.references} />
            </div>
          )}

          <div className="flex flex-col gap-4 w-full px-2">
            {mode === 'single' && <TextInput productName={productName} onChange={setProductName} placeholder="Tên sản phẩm..." />}
            <FieldDropdown label="Mô hình video" value={globalModel} options={VIDEO_MODELS} onChange={setGlobalModel} />
            <FieldDropdown label="Hành động tay" value={handAction} options={HAND_ACTIONS.map(h => h.label)} onChange={(l) => setHandAction(HAND_ACTIONS.find(h => h.label === l)?.value || 'AUTO')} />
            <div className="flex flex-col gap-2">
              <FieldDropdown label="Giọng đọc" value={voiceMaster.voiceName} options={VIETNAMESE_VOICES.map(v => v.label)} onChange={(l) => setVoiceMaster(prev => ({ ...prev, voiceName: l }))} />
              <PillButton variant="outline" onClick={() => setIsVoiceModalOpen(true)} icon={<span className="material-symbols-outlined text-[18px]">settings_voice</span>}>Cài đặt giọng</PillButton>
            </div>
            <div className="flex flex-col gap-1.5">
               <SectionLabel>Thời lượng</SectionLabel>
               <SegmentedToggle value={duration} onChange={setDuration} items={['16s', '24s', '32s', '40s'].map(v => ({ value: v, label: v }))} />
            </div>
          </div>
        </div>
        <div className="w-full pt-4 border-t border-gray-200 flex flex-col gap-2 shrink-0">
          {mode === 'single' ? (
            <>
              {!productAnalysis && <PillButton variant="solid" onClick={handleAnalyze} disabled={step === 'analyzing'}>{step === 'analyzing' ? 'Đang phân tích...' : 'PHÂN TÍCH SẢN PHẨM'}</PillButton>}
              {productAnalysis && <PillButton variant="outline" onClick={() => { setProductAnalysis(null); setMasterScript(null); setStoryboard(null); setResult(null); setIdentityLocked(false); }}>LÀM LẠI</PillButton>}
            </>
          ) : (
            <div className="flex gap-2">
              {isBatchRunning ? (
                <PillButton variant="outline" onClick={stopBatch} icon={<span className="material-symbols-outlined text-[18px]">stop_circle</span>}>DỪNG BATCH</PillButton>
              ) : (
                <PillButton 
                  variant="solid" 
                  onClick={runBatchTasks} 
                  disabled={!batchTasks.some(t => t.productName && t.references.some(r => r !== null))}
                >
                  CHẠY CÁC TASK
                </PillButton>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 h-full bg-gray-50/50 overflow-y-auto custom-scrollbar p-6 z-10">
        <div className="max-w-5xl mx-auto flex flex-col gap-8 pb-20">
          {error && (
            <div className="bg-red-50 border border-red-100 p-4 rounded-[24px] flex items-center gap-3 animate-shake">
              <span className="material-symbols-outlined text-red-500">error</span>
              <p className="text-[13px] font-bold text-red-800">{error}</p>
              <button onClick={() => setError(null)} className="ml-auto text-red-400 hover:text-red-600">
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>
          )}

          {mode === 'single' ? (
            <>
              {productAnalysis && <ProductAnalysisCard data={productAnalysis} references={activeReferences} onNext={handleGenerateScript} isNextLoading={step === 'scripting'} showNext={!masterScript} onUnlock={() => setIdentityLocked(false)} />}
              {masterScript && <MasterScriptCard data={masterScript} status={scriptStatus} onUpdate={setMasterScript} onLock={() => setScriptStatus('LOCKED')} onUnlock={() => setScriptStatus('DRAFT')} onRegenerate={handleGenerateScript} onNext={handleGenerateStoryboard} isNextLoading={step === 'storyboarding'} showNext={scriptStatus === 'LOCKED' && !storyboard} voiceMaster={voiceMaster} onReImport={() => setIsImportModalOpen(true)} />}
              {storyboard && <StoryboardCard data={storyboard} status={storyboardStatus} onRegenerateAll={handleGenerateStoryboard} onRegenerateScene={async (num) => {
                setStoryboard(p => p ? { ...p, scenes: p.scenes.map(s => s.sceneNumber === num ? { ...s, generationStatus: 'generating', generationError: undefined } : s) } : null);
                try { 
                  const img = await PromptService.generateStoryboardFrame({ 
                    scene: storyboard.scenes.find(s => s.sceneNumber === num), 
                    analysis: productAnalysis, 
                    references: activeReferences, 
                    aspectRatio 
                  }); 
                  setStoryboard(p => p ? { ...p, scenes: p.scenes.map(s => s.sceneNumber === num ? { ...s, storyboardImage: img, generationStatus: 'done' } : s) } : null); 
                } catch (err: any) { 
                  setStoryboard(p => p ? { ...p, scenes: p.scenes.map(s => s.sceneNumber === num ? { ...s, generationStatus: 'error', generationError: PromptService.getFriendlyErrorMessage(err) } : s) } : null); 
                }
              }} onLock={() => setStoryboardStatus('LOCKED')} onUnlock={() => setStoryboardStatus('DRAFT')} onNext={async () => { setStep('planning'); try { const f = await PromptService.generateFinalPlan({ analysis: productAnalysis, scriptData: masterScript, storyboard, productName, duration, references: activeReferences, model: globalModel, voiceMaster, handAction }); setResult(f); } finally { setStep('idle'); } }} isNextLoading={step === 'planning'} references={activeReferences} aspectRatio={aspectRatio} />}
              {result && <ResultView storyboard={result} references={activeReferences} defaultModel={globalModel} voiceMaster={voiceMaster} analysis={productAnalysis} productName={productName} handAction={handAction} aspectRatio={aspectRatio} />}
              {!productAnalysis && <div className="flex flex-col items-center justify-center py-32 opacity-60 border-2 border-dashed border-gray-200 rounded-[40px]"><span className="material-symbols-outlined text-7xl text-gray-300">add_photo_alternate</span><p className="text-xl font-bold">Chưa có dữ liệu sản phẩm</p></div>}
            </>
          ) : (
            <BatchTaskBoard 
              tasks={batchTasks} 
              onUpdateTask={updateTask} 
              onResetTask={resetTask} 
              onLoadToSingle={handleLoadTaskToSingle}
            />
          )}
        </div>
      </div>
      {isImportModalOpen && <div className="fixed inset-0 z-[110] flex items-center justify-center p-4"><div className="absolute inset-0 bg-gray-900/40 backdrop-blur-md" onClick={() => setIsImportModalOpen(false)} /><div className="relative w-full max-w-xl bg-white rounded-[32px] p-6 shadow-2xl animate-fade-in"><h2 className="text-lg font-black uppercase mb-4">Nhập kịch bản sẵn</h2><textarea value={manualScriptText} onChange={(e) => setManualScriptText(e.target.value)} placeholder="Dán lời thoại..." className="w-full h-64 bg-gray-50 border rounded-2xl p-4 outline-none" /><div className="flex justify-end gap-3 mt-4"><PillButton variant="outline" onClick={() => setIsImportModalOpen(false)}>HỦY</PillButton><PillButton variant="solid" onClick={handleImportManualScript} disabled={step === 'importing'}>{step === 'importing' ? 'XỬ LÝ...' : 'XÁC NHẬN'}</PillButton></div></div></div>}
      <VoiceSettingsModal isOpen={isVoiceModalOpen} onClose={() => setIsVoiceModalOpen(false)} settings={voiceMaster} onSave={setVoiceMaster} />
    </div>
  );
}
