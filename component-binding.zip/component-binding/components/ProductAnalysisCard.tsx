import React from 'react';
import { PillButton } from './Primitives';
import { ProductAnalysis } from '../types';

interface ProductAnalysisCardProps {
  data: ProductAnalysis;
  references: (any | null)[];
  onNext: () => void;
  isNextLoading: boolean;
  showNext: boolean;
  onUnlock?: () => void;
}

export const ProductAnalysisCard: React.FC<ProductAnalysisCardProps> = ({ 
  data, references, onNext, isNextLoading, showNext, onUnlock
}) => {
  const pkg = data?.packageMaster;
  const food = data?.foodContentMaster;
  const env = data?.environmentMaster;

  if (!pkg || !food || !env) return null;

  const getStatusColor = (status: string) => {
    if (status === 'LOCKED') return 'text-emerald-600';
    if (status === 'PARTIAL') return 'text-amber-600';
    return 'text-gray-400';
  };

  const getSourceLabel = (src: number | null) => {
    if (src === null) return 'N/A';
    return `ẢNH ${src}`;
  };

  return (
    <div className="bg-white rounded-[32px] border border-emerald-100 overflow-hidden animate-fade-in-up shadow-sm">
      <div className="p-5 border-b border-emerald-50 bg-emerald-50/20 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-emerald-500 text-[22px]">verified_user</span>
          <span className="text-[12px] font-bold text-gray-600 uppercase tracking-widest">ĐÃ KHÓA NHẬN DẠNG SẢN PHẨM 🔒</span>
        </div>
        <button onClick={onUnlock} className="text-[11px] font-black text-gray-400 hover:text-gray-600 uppercase tracking-widest transition-colors px-3 py-1">
          MỞ KHÓA ĐỂ SỬA
        </button>
      </div>
      
      <div className="p-8 flex flex-col gap-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* PACKAGE MASTER */}
          <div className="flex flex-col gap-3">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px] text-gray-400">shopping_bag</span>
                  <span className="text-[11px] font-black text-gray-400 uppercase">BAO BÌ CHUẨN</span>
                </div>
                <div className="flex flex-col items-end">
                   <span className={`text-[9px] font-black uppercase tracking-widest ${getStatusColor(pkg.status)}`}>
                    {pkg.status === 'LOCKED' ? 'ĐÃ KHÓA' : pkg.status}
                  </span>
                  <span className="text-[8px] text-gray-300 font-bold">Nguồn: {getSourceLabel(pkg.sourceReference)}</span>
                </div>
             </div>
             <div className="bg-gray-50 rounded-2xl p-5 border border-gray-100 flex flex-col gap-4 min-h-[140px] shadow-inner">
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Mô tả bao bì</span>
                  <p className="text-[13px] text-gray-900 font-bold leading-tight mt-1">{pkg.packagingDescription || 'Chưa có dữ liệu'}</p>
                  <p className="text-[11px] text-gray-500 mt-1">{pkg.material} · {pkg.shape}</p>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Màu sắc & Nhãn hiệu</span>
                  <p className="text-[11px] text-gray-500 mt-1">{pkg.colors} · {pkg.labelAndBranding}</p>
                </div>
             </div>
          </div>

          {/* FOOD CONTENT MASTER */}
          <div className="flex flex-col gap-3">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px] text-gray-400">nutrition</span>
                  <span className="text-[11px] font-black text-gray-400 uppercase">SẢN PHẨM CHUẨN</span>
                </div>
                <div className="flex flex-col items-end">
                   <span className={`text-[9px] font-black uppercase tracking-widest ${getStatusColor(food.status)}`}>
                    {food.status === 'LOCKED' ? 'ĐÃ KHÓA' : food.status}
                  </span>
                  <span className="text-[8px] text-gray-300 font-bold">Nguồn: {getSourceLabel(food.sourceReference)}</span>
                </div>
             </div>
             <div className="bg-gray-50 rounded-2xl p-5 border border-gray-100 flex flex-col gap-4 min-h-[140px] shadow-inner">
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Loại & Hình dạng</span>
                  <p className="text-[13px] text-emerald-700 font-bold leading-tight mt-1">{food.productType} • {food.shapeAndSize}</p>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Kết cấu & Gia vị</span>
                  <p className="text-[11px] text-gray-500 mt-1">{food.surfaceTexture} • {food.colorAndSeasoning}</p>
                </div>
             </div>
          </div>

          {/* ENVIRONMENT MASTER */}
          <div className="flex flex-col gap-3">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px] text-gray-400">deck</span>
                  <span className="text-[11px] font-black text-gray-400 uppercase">BỐI CẢNH CHUẨN</span>
                </div>
                <div className="flex flex-col items-end">
                   <span className={`text-[9px] font-black uppercase tracking-widest ${getStatusColor(env.status)}`}>
                    {env.status === 'LOCKED' ? 'ĐÃ KHÓA' : env.status}
                  </span>
                  <span className="text-[8px] text-gray-300 font-bold">Nguồn: {getSourceLabel(env.sourceReference)}</span>
                </div>
             </div>
             <div className="bg-gray-50 rounded-2xl p-5 border border-gray-100 flex flex-col gap-4 min-h-[140px] shadow-inner">
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Không gian</span>
                  <p className="text-[13px] text-gray-900 font-bold leading-tight mt-1">{env.tabletopAndSpace || 'Chưa có dữ liệu'}</p>
                  <p className="text-[11px] text-gray-500 mt-1">{env.background} • {env.visualStyle}</p>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Ánh sáng</span>
                  <p className="text-[11px] text-gray-500 mt-1">{env.lighting}</p>
                </div>
             </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-3 pt-6 border-t border-gray-100">
          <span className="px-3 py-1 bg-emerald-50 border border-emerald-100 rounded-lg text-[9px] font-black text-emerald-600/60 uppercase tracking-wider">🔒 ĐÃ CHỐT NHẬN DIỆN VAI TRÒ</span>
          <span className="px-3 py-1 bg-emerald-50 border border-emerald-100 rounded-lg text-[9px] font-black text-emerald-600/60 uppercase tracking-wider">🔒 ĐÃ KHÓA BỐI CẢNH QUAY</span>
        </div>
      </div>

      {showNext && (
        <div className="p-5 bg-gray-50 border-t border-gray-100 flex justify-end">
          <div className="w-72">
            <PillButton variant="solid" onClick={onNext} disabled={isNextLoading} icon={<span className="material-symbols-outlined text-[20px]">edit_note</span>}>
              {isNextLoading ? 'ĐANG XỬ LÝ...' : 'TIẾP THEO: TẠO KỊCH BẢN'}
            </PillButton>
          </div>
        </div>
      )}
    </div>
  );
};
