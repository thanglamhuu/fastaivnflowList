import React from 'react';
import { Flow } from 'flow-sdk';
import { BatchTask } from '../types';
import { PillButton } from './Primitives';

interface BatchTaskCardProps {
  task: BatchTask;
  onUpdate: (updates: Partial<BatchTask>) => void;
  onReset: () => void;
  onLoadToSingle: (task: BatchTask) => void;
}

export const BatchTaskCard: React.FC<BatchTaskCardProps> = ({ task, onUpdate, onReset, onLoadToSingle }) => {
  const handleSelectImage = async (index: number) => {
    const res = await Flow.media.select({ filter: 'image' });
    if (res) {
      const newRefs = [...task.references];
      newRefs[index] = res;
      onUpdate({ references: newRefs });
    }
  };

  const getStatusLabel = () => {
    switch (task.status) {
      case 'queued': return 'Đang chờ...';
      case 'running': return 'Đang chạy...';
      case 'completed': return 'Hoàn thành ✓';
      case 'failed': return 'Thất bại ✗';
      default: return 'Chờ dữ liệu';
    }
  };

  const statusColors: Record<string, string> = {
    idle: 'bg-gray-100 text-gray-400',
    queued: 'bg-amber-100 text-amber-600 animate-pulse',
    running: 'bg-blue-100 text-blue-600',
    completed: 'bg-emerald-100 text-emerald-600',
    failed: 'bg-red-100 text-red-600'
  };

  const isWorking = task.status === 'running' || task.status === 'queued';

  return (
    <div className={`bg-white border rounded-[32px] p-6 flex flex-col gap-5 shadow-sm transition-all h-full ${
      task.status === 'running' ? 'border-[#FF7A1A]/40 ring-1 ring-[#FF7A1A]/10' : 'border-gray-100'
    }`}>
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-[#111827] text-white flex items-center justify-center text-[13px] font-black shadow-lg">
            {task.id}
          </div>
          <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${statusColors[task.status]}`}>
            {getStatusLabel()}
          </span>
        </div>
        {!isWorking && (
          <button 
            onClick={onReset} 
            className="text-[10px] font-black text-gray-400 hover:text-red-500 uppercase tracking-widest transition-colors px-2 py-1"
          >
            Reset
          </button>
        )}
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Tên sản phẩm</span>
          <input 
            type="text" 
            value={task.productName}
            onChange={(e) => onUpdate({ productName: e.target.value })}
            disabled={task.status !== 'idle'}
            placeholder="Nhập tên sản phẩm..."
            className="w-full bg-gray-50 border border-gray-100 rounded-2xl px-4 py-3 text-[14px] font-bold outline-none focus:border-[#FF7A1A]/40 transition-all placeholder:font-medium placeholder:text-gray-300"
          />
        </div>

        <div className="flex flex-col gap-2">
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Ảnh tham chiếu (Max 7)</span>
          <div className="grid grid-cols-4 gap-2">
            {task.references.map((ref, idx) => (
              <div 
                key={idx}
                onClick={task.status === 'idle' ? () => handleSelectImage(idx) : undefined}
                className={`aspect-[4/5] rounded-xl border-2 border-dashed flex items-center justify-center overflow-hidden transition-all relative group ${
                  ref ? 'border-emerald-200 border-solid' : 'border-gray-200 hover:border-[#FF7A1A]/40 cursor-pointer'
                }`}
              >
                {ref ? (
                  <img src={`data:${ref.mimeType};base64,${ref.base64}`} className="w-full h-full object-cover" alt={`Ref ${idx+1}`} />
                ) : (
                  <span className="material-symbols-outlined text-[18px] text-gray-300 group-hover:text-[#FF7A1A]">add</span>
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-black/40 py-0.5 text-center">
                  <span className="text-[8px] font-black text-white uppercase">{idx + 1}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {(task.status === 'running' || task.status === 'completed' || task.status === 'failed' || task.status === 'queued') && (
        <div className="flex flex-col gap-2 mt-auto pt-4 border-t border-gray-50">
          <div className="flex justify-between items-end">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest truncate max-w-[160px]">
              {task.status === 'failed' ? (task.error || 'Lỗi xử lý') : 
               task.status === 'queued' ? 'Đang xếp hàng...' :
               (task.currentScene > 0 ? `Xử lý cảnh ${task.currentScene}/4` : 'Đang lập kế hoạch...')}
            </span>
            <span className="text-[12px] font-black text-[#FF7A1A]">{task.progress}%</span>
          </div>
          <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-700 ease-out ${task.status === 'failed' ? 'bg-red-500' : 'bg-[#FF7A1A]'}`} 
              style={{ width: `${task.progress}%` }} 
            />
          </div>
        </div>
      )}

      {task.status === 'completed' && task.result && (
        <div className="mt-2 flex flex-col gap-3">
          <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center justify-between shadow-inner">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Dữ liệu sẵn sàng</span>
              <span className="text-[12px] text-emerald-800 font-bold">4/4 cảnh đã phác thảo</span>
            </div>
            <span className="material-symbols-outlined text-emerald-500 text-2xl">check_circle</span>
          </div>
          <PillButton variant="solid" onClick={() => onLoadToSingle(task)} icon={<span className="material-symbols-outlined text-[20px]">send</span>}>
            SỬA TRONG "TỪNG SP"
          </PillButton>
        </div>
      )}
    </div>
  );
};
