import React from 'react';
import { DetectedReference } from '../types';

interface ReferenceGridProps {
  images: (any | null)[];
  onAdd: (index: number) => void;
  onClear: () => void;
  isLocked?: boolean;
  detectedReferences?: DetectedReference[];
}

export const ReferenceGrid: React.FC<ReferenceGridProps> = ({ images, onAdd, onClear, isLocked, detectedReferences }) => {
  const labels = [
    "ẢNH 1",
    "ẢNH 2",
    "ẢNH 3",
    "ẢNH 4",
    "ẢNH 5",
    "ẢNH 6",
    "ẢNH 7"
  ];

  const roleMap: Record<string, string> = {
    'package': 'BAO BÌ',
    'food_content': 'SẢN PHẨM',
    'environment': 'BỐI CẢNH',
    'hand_style': 'TAY',
    'serving_setup': 'SETUP'
  };

  const getBadges = (idx: number) => {
    const det = detectedReferences?.find(r => r.referenceIndex === idx + 1);
    if (!det) return null;
    return (
      <div className="flex flex-wrap gap-0.5 justify-center">
        {det.detectedRoles.map(role => (
          <span key={role} className="bg-emerald-500 text-white text-[7px] font-black px-1.5 rounded-[2px] leading-tight">
            {roleMap[role] || role.toUpperCase()}
          </span>
        ))}
      </div>
    );
  };

  return (
    <div className="w-full flex flex-col gap-2">
      <div className="grid grid-cols-3 gap-2 w-full px-1">
        {images.map((img, idx) => (
          <div 
            key={idx} 
            className={`aspect-[4/5] bg-white border rounded-xl overflow-hidden flex flex-col items-center justify-center relative group transition-all ${
              img ? 'border-emerald-200' : 'border-gray-200 hover:border-[#FF7A1A]/30'
            }`}
          >
            {img ? (
              <>
                <img 
                  src={`data:${img.mimeType};base64,${img.base64}`} 
                  className="w-full h-full object-cover" 
                  alt={labels[idx]}
                />
                {!isLocked && (
                  <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button 
                      onClick={() => onAdd(idx)} 
                      className="text-white bg-[#FF7A1A]/80 p-2 rounded-full backdrop-blur-sm hover:bg-[#FF7A1A] transition-colors shadow-lg"
                    >
                      <span className="material-symbols-outlined text-[18px]">edit</span>
                    </button>
                  </div>
                )}
                {isLocked && (
                  <div className="absolute top-1 right-1">
                    <span className="material-symbols-outlined text-[16px] text-white bg-emerald-500/80 rounded-full p-0.5 shadow-lg">lock</span>
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 py-2 px-1 flex flex-col gap-1 items-center pointer-events-none">
                   <span className="text-[9px] font-black text-white uppercase tracking-tighter leading-none">{labels[idx]}</span>
                   {getBadges(idx)}
                </div>
              </>
            ) : (
              <button 
                onClick={() => onAdd(idx)}
                disabled={isLocked}
                className="w-full h-full flex flex-col items-center justify-center gap-2 text-gray-300 hover:text-gray-900 hover:bg-gray-50 transition-all disabled:opacity-20"
              >
                <span className="material-symbols-outlined text-[24px]">add_photo_alternate</span>
                <span className="text-[9px] font-bold uppercase tracking-tighter text-center px-2 leading-tight">{labels[idx]}</span>
              </button>
            )}
          </div>
        ))}
      </div>
      <p className="text-[11px] text-gray-400 italic px-2 leading-tight">AI tự nhận diện nội dung từng ảnh (Bao bì, Sản phẩm, Bối cảnh) sau khi bấm PHÂN TÍCH.</p>
      {images.some(img => img !== null) && !isLocked && (
        <button 
          onClick={onClear}
          className="text-[11px] font-bold uppercase tracking-widest text-red-400 hover:text-red-600 self-end px-3 py-1.5 transition-colors"
        >
          Xóa tất cả ảnh
        </button>
      )}
    </div>
  );
};
