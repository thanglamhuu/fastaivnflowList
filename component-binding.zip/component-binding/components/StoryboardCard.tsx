import React from 'react';
import { PillButton } from './Primitives';
import { StoryboardData, StoryboardStatus, StoryboardScene } from '../types';

const CAMERA_LABELS: Record<string, string> = {
  "POV Close-up": "POV – Cận cảnh",
  "POV Extreme Close-up": "POV – Siêu cận cảnh",
  "POV Medium Shot": "POV – Trung cảnh",
  "POV Wide-angle": "POV – Góc rộng",
  "POV Pan": "POV – Lia máy"
};

const SceneCard: React.FC<{
  scene: StoryboardScene;
  onRegenerate: () => void;
  isDraft: boolean;
  aspectRatio: '9:16' | '16:9';
}> = ({ scene, onRegenerate, isDraft, aspectRatio }) => {
  const isGenerating = scene.generationStatus === 'generating';
  const isDone = scene.generationStatus === 'done' && scene.storyboardImage;
  const isError = scene.generationStatus === 'error';

  return (
    <div className="flex flex-col gap-5 p-6 bg-white border border-gray-100 rounded-[24px] transition-all hover:bg-gray-50 shadow-sm">
      <div className="flex justify-between items-start">
        <div className="flex flex-col gap-1">
          <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest">CẢNH {scene.sceneNumber.toString().padStart(2, '0')}</span>
          <span className="text-[12px] font-bold text-emerald-600 uppercase tracking-tighter">{scene.timeRange}</span>
        </div>
        {isDraft && (isDone || isError) && (
          <button 
            onClick={onRegenerate}
            disabled={isGenerating}
            className="text-[10px] font-black text-gray-400 hover:text-gray-900 uppercase tracking-widest flex items-center gap-1.5 transition-colors px-3 py-1 rounded-lg hover:bg-white disabled:opacity-30"
          >
            <span className="material-symbols-outlined text-[16px]">refresh</span>
            {isError ? 'THỬ LẠI' : 'TẠO LẠI'}
          </button>
        )}
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <span className="text-[9px] font-black text-gray-300 uppercase tracking-tighter">LỜI THOẠI (ĐÃ KHÓA)</span>
          <p className="text-[13px] font-medium text-emerald-700 leading-relaxed italic">"{scene.voiceOver}"</p>
        </div>
        <div className="flex flex-col gap-1.5">
          <span className="text-[9px] font-black text-gray-300 uppercase tracking-tighter">NỘI DUNG CẦN THỂ HIỆN</span>
          <p className="text-[12px] font-bold text-gray-900 uppercase tracking-tighter leading-tight">{scene.visualProofGoal}</p>
        </div>
      </div>

      <div className={`w-full rounded-2xl overflow-hidden bg-gray-50 border border-gray-100 relative flex items-center justify-center shadow-inner group ${aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'}`}>
        {isGenerating && (
          <div className="absolute inset-0 z-10 bg-white/60 backdrop-blur-md flex flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="w-10 h-10 border-[3px] border-emerald-100 border-t-emerald-500 rounded-full animate-spin shadow-sm" />
            <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest">Đang vẽ phác thảo...</p>
          </div>
        )}

        {isDone ? (
          <img 
            src={`data:${scene.storyboardImage!.mimeType};base64,${scene.storyboardImage!.base64}`} 
            className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-1000" 
            alt={`Cảnh ${scene.sceneNumber}`}
          />
        ) : isError ? (
          <div className="flex flex-col items-center gap-3 p-8 text-center">
            <span className="material-symbols-outlined text-red-400 text-5xl">error_outline</span>
            <span className="text-[11px] font-black uppercase text-red-400 tracking-widest leading-tight">Lỗi khởi tạo ảnh</span>
          </div>
        ) : !isGenerating ? (
          <div className="flex flex-col items-center gap-3 opacity-20 group-hover:opacity-30 transition-opacity">
            <span className="material-symbols-outlined text-5xl text-gray-400">brush</span>
            <span className="text-[12px] font-bold uppercase text-gray-400 tracking-widest">Đang chờ xử lý</span>
          </div>
        ) : null}
      </div>

      {isError && scene.generationError && (
        <div className="p-3 bg-red-50 border border-red-100 rounded-xl animate-fade-in">
           <p className="text-[11px] text-red-800 font-bold text-center leading-tight">
             {scene.generationError}
           </p>
        </div>
      )}

      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <span className="text-[9px] font-black text-gray-300 uppercase tracking-tighter">HÀNH ĐỘNG</span>
          <p className="text-[13px] font-bold text-gray-900 leading-tight">{scene.heroAction}</p>
        </div>
        <div className="flex items-center justify-between text-gray-400 border-t border-gray-100 pt-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">videocam</span>
            <span className="text-[11px] font-black uppercase tracking-widest">{CAMERA_LABELS[scene.camera] || scene.camera}</span>
          </div>
          {isDone && <span className="material-symbols-outlined text-emerald-500 text-[18px]">check_circle</span>}
        </div>
      </div>
    </div>
  );
};

export const StoryboardCard: React.FC<{
  data: StoryboardData;
  status: StoryboardStatus;
  onRegenerateAll: () => void;
  onRegenerateScene: (sceneNumber: number) => void;
  onLock: () => void;
  onUnlock: () => void;
  onNext: () => void;
  isNextLoading: boolean;
  references: (any | null)[];
  aspectRatio?: '9:16' | '16:9';
}> = ({
  data, status, onRegenerateAll, onRegenerateScene, onLock, onUnlock, onNext, isNextLoading, references, aspectRatio = '9:16'
}) => {
  const isDraft = status === 'DRAFT';
  const anyGenerating = data.scenes.some(s => s.generationStatus === 'generating');
  const anyError = data.scenes.some(s => s.generationStatus === 'error');
  const allDone = data.scenes.every(s => s.generationStatus === 'done' && s.storyboardImage);
  const env = data?.environmentMaster || {};
  
  const envSrcIdx = env.sourceReference ? env.sourceReference - 1 : null;
  const envRef = envSrcIdx !== null ? references[envSrcIdx] : null;

  return (
    <div className="bg-white rounded-[40px] border border-gray-100 overflow-hidden animate-slide-up shadow-sm">
      <div className="px-8 py-7 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-4">
            <span className="material-symbols-outlined text-[#FF7A1A] text-[24px]">movie_edit</span>
            <h2 className="text-xl font-black uppercase tracking-tighter text-gray-900">HÌNH PHÂN CẢNH (STORYBOARD)</h2>
          </div>
          <p className="text-[11px] text-gray-400 uppercase font-black tracking-widest ml-10">Mô phỏng hình ảnh dựa trên lời thoại đã chốt</p>
        </div>
        <div className="flex items-center gap-4">
           <div className={`px-5 py-2 rounded-full text-[11px] font-black tracking-widest uppercase border ${isDraft ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-emerald-500 text-white border-emerald-400 shadow-md'}`}>
            {isDraft ? 'ĐANG PHÁC THẢO' : 'ĐÃ KHÓA PHÂN CẢNH 🔒'}
          </div>
        </div>
      </div>

      <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-10 bg-gray-50/30">
        {data.scenes.map((scene) => (
          <SceneCard 
            key={scene.sceneNumber} 
            scene={scene} 
            onRegenerate={() => onRegenerateScene(scene.sceneNumber)} 
            isDraft={isDraft}
            aspectRatio={aspectRatio}
          />
        ))}
      </div>

      <div className="p-8 bg-white border-t border-gray-100 flex flex-col gap-8">
        <div className="flex flex-wrap items-center justify-between gap-8">
          <div className="flex items-center gap-5">
            {envRef && (
              <div className="w-20 h-24 rounded-2xl border border-gray-100 overflow-hidden bg-gray-50 shrink-0 shadow-sm">
                <img src={`data:${envRef.mimeType};base64,${envRef.base64}`} className="w-full h-full object-cover" alt="Bối cảnh" />
              </div>
            )}
            <div className="flex flex-col">
               <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest mb-1.5">BỐI CẢNH CHUẨN ({env.sourceReference ? `ẢNH ${env.sourceReference}` : 'TỰ ĐỘNG'}) 🔒</span>
               <p className="text-[14px] font-bold text-gray-900">
                 {env.tabletopAndSpace || 'Chưa xác định'}
               </p>
               <p className="text-[11px] text-gray-400 mt-1.5 uppercase tracking-tighter font-medium">Phong cách: {env.visualStyle || 'Tự nhiên'} · Ánh sáng: {env.lighting || 'Tự nhiên'}</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {isDraft ? (
              <>
                <button 
                  onClick={onRegenerateAll} 
                  disabled={anyGenerating}
                  className="text-[11px] font-black text-gray-400 hover:text-gray-900 uppercase tracking-widest flex items-center gap-2 transition-colors px-5 py-2 hover:bg-gray-50 rounded-xl disabled:opacity-30"
                >
                  <span className="material-symbols-outlined text-[18px]">restart_alt</span>
                  TẠO LẠI TẤT CẢ
                </button>
                <div className="w-64">
                  <PillButton variant="solid" onClick={onLock} disabled={!allDone || anyGenerating}>
                    {anyGenerating ? 'ĐANG VẼ PHÁC THẢO...' : allDone ? 'CHỐT HÌNH PHÂN CẢNH' : anyError ? 'VUI LÒNG THỬ LẠI CÁC CẢNH LỖI' : 'CHỐT HÌNH PHÂN CẢNH'}
                  </PillButton>
                </div>
              </>
            ) : (
              <div className="w-56">
                <PillButton variant="outline" onClick={onUnlock}>MỞ KHÓA ĐỂ SỬA</PillButton>
              </div>
            )}
          </div>
        </div>
      </div>

      {!isDraft && (
        <div className="p-6 bg-emerald-50/50 border-t border-emerald-100 flex justify-end">
          <div className="w-72">
            <PillButton 
              variant="solid" 
              onClick={onNext} 
              disabled={isNextLoading} 
              icon={<span className="material-symbols-outlined text-[22px]">videocam</span>}
            >
              {isNextLoading ? 'ĐANG XỬ LÝ...' : 'TIẾP THEO: TẠO VIDEO'}
            </PillButton>
          </div>
        </div>
      )}
    </div>
  );
};
