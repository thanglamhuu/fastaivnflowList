import React, { useState, useMemo, useEffect } from 'react';
import { PillButton, TextInput, SectionLabel, FieldDropdown } from './Primitives';
import { DragNumberField } from './DragNumberField';
import { GEMINI_VOICES, VIETNAMESE_VOICES, VoiceMaster } from '../types';
import { VoiceService } from '../services/VoiceService';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VoiceMaster;
  onSave: (val: VoiceMaster) => void;
}

const LANGUAGES = ["Vietnamese", "English"];
const ACCENTS = ["Tự nhiên", "Miền Bắc", "Miền Trung", "Miền Nam", "Miền Tây / Nam Bộ"];
const AGES = ["Trẻ 18–22", "Trẻ 23–30", "Trưởng thành 30–40", "Tự nhiên theo voice"];
const DELIVERIES = ["TikTok tự nhiên", "Review đồ ăn", "Dịu dàng", "Năng lượng", "ASMR nhẹ", "Kể chuyện", "Quảng cáo mềm", "Tự do tùy chỉnh"];

const SPEED_PRESETS = [
  { value: 0.8, label: '0.8x Chậm' },
  { value: 0.9, label: '0.9x Hơi chậm' },
  { value: 1.0, label: '1.0x Bình thường' },
  { value: 1.1, label: '1.1x Hơi nhanh' },
  { value: 1.2, label: '1.2x Nhanh' },
  { value: 1.3, label: '1.3x Rất nhanh' },
];

const SNACK_POV_PRESETS: Record<string, Partial<VoiceMaster>> = {
  "Nữ trẻ trong trẻo": {
    accent: "Tự nhiên",
    ageImpression: "Trẻ 18–22",
    tone: "trong trẻo, nhẹ nhàng",
    delivery: "Dịu dàng",
    speakingSpeed: 1.0,
    customStyleInstruction: "Giọng nữ trẻ tự nhiên, trong trẻo, không quá nhanh."
  },
  "Nữ ngọt ngào": {
    accent: "Miền Nam",
    ageImpression: "Trẻ 23–30",
    tone: "ngọt ngào, ấm áp",
    delivery: "TikTok tự nhiên",
    speakingSpeed: 1.1,
    customStyleInstruction: "Giọng nữ miền Nam ngọt ngào, gần gũi, tạo cảm giác thân thiện."
  },
  "Nữ miền Tây dễ thương": {
    accent: "Miền Tây / Nam Bộ",
    ageImpression: "Trẻ 18–22",
    tone: "dễ thương, chân chất",
    delivery: "TikTok tự nhiên",
    speakingSpeed: 1.1,
    customStyleInstruction: "Giọng nữ miền Tây dễ thương, dùng từ ngữ mộc mạc, gần gũi."
  },
  "Nữ review TikTok năng lượng": {
    accent: "Miền Nam",
    ageImpression: "Trẻ 23–30",
    tone: "năng lượng, hào hứng",
    delivery: "Review đồ ăn",
    speakingSpeed: 1.2,
    customStyleInstruction: "Giọng nữ review TikTok năng lượng, nhấn nhá vào các từ mô tả độ ngon, nhịp điệu nhanh."
  },
  "Nam ấm áp": {
    accent: "Miền Bắc",
    ageImpression: "Trưởng thành 30–40",
    tone: "trầm ấm, tin cậy",
    delivery: "Kể chuyện",
    speakingSpeed: 1.0,
    customStyleInstruction: "Giọng nam miền Bắc trầm ấm, tốc độ vừa phải, tạo cảm giác chuyên nghiệp."
  }
};

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({ isOpen, onClose, settings, onSave }) => {
  const [localSettings, setLocalSettings] = useState<VoiceMaster>(settings);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [activePreset, setActivePreset] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setLocalSettings(settings);
    }
  }, [isOpen, settings]);

  const currentVoices = useMemo(() => {
    if (localSettings.language === "Vietnamese") {
      return VIETNAMESE_VOICES
        .filter(v => v.supportsVietnamese)
        .map(v => v.label);
    }
    return GEMINI_VOICES.map(v => v.name);
  }, [localSettings.language]);

  const handleApplyPreset = (name: string) => {
    const preset = SNACK_POV_PRESETS[name];
    if (preset) {
      setLocalSettings(prev => ({
        ...prev,
        ...preset
      }));
      setActivePreset(name);
    }
  };

  const setSpeed = (val: number) => {
    setLocalSettings(prev => ({ ...prev, speakingSpeed: val }));
    setActivePreset(null);
  };

  const handleApply = () => {
    onSave(localSettings);
    onClose();
  };

  const handlePreviewTest = async () => {
    setIsPreviewing(true);
    const testSentence = "Trời ơi mấy bà ơi, món đậu phộng này thơm béo dữ lắm, ăn một miếng là muốn ăn hoài luôn á!";
    await VoiceService.synthesizeSpeech(testSentence, localSettings);
    setTimeout(() => setIsPreviewing(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-xl" onClick={onClose} />
      
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-white border border-gray-200 rounded-[32px] overflow-hidden flex flex-col shadow-2xl animate-fade-in">
        <div className="px-8 py-7 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <div className="flex items-center gap-4">
            <span className="material-symbols-outlined text-[#FF7A1A] text-2xl">settings_voice</span>
            <h2 className="text-xl font-black uppercase tracking-tighter text-gray-900">Cài đặt giọng đọc nâng cao</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <span className="material-symbols-outlined text-gray-400 text-2xl">close</span>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-10 bg-white">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="flex flex-col gap-5">
              <SectionLabel>Mẫu giọng review TikTok</SectionLabel>
              <div className="flex flex-col gap-2.5">
                {Object.keys(SNACK_POV_PRESETS).map(name => (
                  <button 
                    key={name}
                    onClick={() => handleApplyPreset(name)}
                    className={`text-left p-4 rounded-xl border text-[13px] font-bold transition-all shadow-sm ${
                      activePreset === name ? 'bg-orange-50 border-[#FF7A1A]/60 text-[#FF7A1A]' : 'bg-gray-50 border-gray-200 hover:border-gray-400 text-gray-500'
                    }`}
                  >
                    {name}
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2 flex flex-col gap-10">
              <div className="grid grid-cols-2 gap-5">
                <FieldDropdown 
                  label="Ngôn ngữ" 
                  value={localSettings.language} 
                  options={LANGUAGES} 
                  onChange={(val) => setLocalSettings(prev => ({ ...prev, language: val }))} 
                />
                <FieldDropdown 
                  label="Chọn giọng" 
                  value={localSettings.voiceName} 
                  options={currentVoices} 
                  onChange={(val) => {
                    setLocalSettings(prev => ({ ...prev, voiceName: val }));
                    setActivePreset(null);
                  }} 
                />
                <FieldDropdown 
                  label="Vùng miền (Accent)" 
                  value={localSettings.accent || "Tự nhiên"} 
                  options={ACCENTS} 
                  onChange={(val) => setLocalSettings(prev => ({ ...prev, accent: val }))} 
                />
                <FieldDropdown 
                  label="Độ tuổi giọng đọc" 
                  value={localSettings.ageImpression || "Tự nhiên theo voice"} 
                  options={AGES} 
                  onChange={(val) => setLocalSettings(prev => ({ ...prev, ageImpression: val }))} 
                />
                <FieldDropdown 
                  label="Cách thể hiện (Delivery)" 
                  value={localSettings.delivery || "TikTok tự nhiên"} 
                  options={DELIVERIES} 
                  onChange={(val) => setLocalSettings(prev => ({ ...prev, delivery: val }))} 
                />
                <DragNumberField 
                  label="Tốc độ nói"
                  value={localSettings.speakingSpeed}
                  min={0.8} max={1.3} step={0.1}
                  onChange={setSpeed}
                />
              </div>

              <div className="flex flex-col gap-4">
                <SectionLabel>Tốc độ nói nhanh</SectionLabel>
                <div className="grid grid-cols-3 gap-3">
                  {SPEED_PRESETS.map(preset => (
                    <button
                      key={preset.value}
                      onClick={() => setSpeed(preset.value)}
                      className={`py-3 px-4 rounded-xl border text-[11px] font-black uppercase tracking-tighter transition-all ${
                        Math.abs(localSettings.speakingSpeed - preset.value) < 0.01
                          ? 'bg-[#FF7A1A] text-white border-[#FF7A1A] shadow-md'
                          : 'bg-gray-50 border-gray-200 text-gray-400 hover:bg-gray-100 hover:text-gray-900'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <SectionLabel>Tông giọng & Chỉ dẫn bổ sung</SectionLabel>
                <TextInput 
                  value={localSettings.tone} 
                  onChange={(val) => setLocalSettings(prev => ({ ...prev, tone: val }))}
                  placeholder="Ví dụ: ngọt ngào, ấm áp, hào hứng..."
                />
                <textarea 
                  value={localSettings.customStyleInstruction}
                  onChange={(e) => setLocalSettings(prev => ({ ...prev, customStyleInstruction: e.target.value }))}
                  placeholder="Mô tả cụ thể cảm xúc hoặc nhịp điệu bạn muốn (Ví dụ: Nói chậm ở đầu, nhanh dần về cuối)..."
                  className="w-full h-28 bg-gray-50 border border-gray-200 rounded-xl p-5 text-[14px] font-medium text-gray-900 outline-none focus:border-[#FF7A1A]/50 transition-all resize-none custom-scrollbar shadow-inner"
                />
              </div>

              <div className="bg-emerald-50/30 rounded-[24px] p-8 border border-emerald-100 flex flex-col gap-5 shadow-inner">
                <div className="flex justify-between items-center">
                  <div className="flex flex-col gap-1">
                    <span className="text-[11px] font-bold text-emerald-600/60 uppercase tracking-widest">Nghe thử giọng đọc mẫu</span>
                    <span className="text-[10px] text-gray-400 italic">Áp dụng các cài đặt trên để nghe thử</span>
                  </div>
                  <div className="w-56">
                    <PillButton 
                      variant="outline" 
                      onClick={handlePreviewTest} 
                      disabled={isPreviewing}
                      icon={isPreviewing ? <div className="w-5 h-5 border-[3px] border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" /> : <span className="material-symbols-outlined text-[20px]">campaign</span>}
                    >
                      {isPreviewing ? 'ĐANG XỬ LÝ...' : 'NGHE THỬ NGAY'}
                    </PillButton>
                  </div>
                </div>
                <p className="text-[15px] text-emerald-800 font-medium bg-white p-5 rounded-xl leading-relaxed border border-emerald-50 shadow-inner italic">
                  "Trời ơi mấy bà ơi, món đậu phộng này thơm béo dữ lắm, ăn một miếng là muốn ăn hoài luôn á!"
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-8 py-7 border-t border-gray-100 bg-gray-50/50 flex justify-end gap-4 shrink-0">
          <div className="w-40">
            <PillButton variant="outline" onClick={onClose}>HỦY BỎ</PillButton>
          </div>
          <div className="w-56">
            <PillButton variant="solid" onClick={handleApply} icon={<span className="material-symbols-outlined text-[22px]">done_all</span>}>LƯU CÀI ĐẶT</PillButton>
          </div>
        </div>
      </div>
    </div>
  );
};
