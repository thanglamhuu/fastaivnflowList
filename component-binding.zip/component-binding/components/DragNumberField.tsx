import React, { useState, useRef } from 'react';

export const DragNumberField: React.FC<{
  label: string; 
  value: number; 
  min?: number; 
  max?: number;
  step?: number; 
  suffix?: string; 
  onChange: (val: number) => void; 
  className?: string;
  variant?: 'panel' | 'inline';
}> = ({ label, value, min = 0, max = 999, step = 0.1, suffix = 'x', onChange, className = '', variant = 'panel' }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(String(value));
  const inputRef = useRef<HTMLInputElement>(null);
  const dragRef = useRef<{ startY: number; startVal: number; moved: boolean } | null>(null);

  const commitEdit = (raw: string) => {
    const parsed = parseFloat(raw);
    if (!isNaN(parsed)) {
      const clamped = Math.min(max, Math.max(min, parsed));
      onChange(Number(clamped.toFixed(2)));
    }
    setIsEditing(false);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isEditing) return;
    e.preventDefault();
    dragRef.current = { startY: e.clientY, startVal: value, moved: false };
    
    const handleMouseMove = (ev: MouseEvent) => {
      if (!dragRef.current) return;
      const deltaY = dragRef.current.startY - ev.clientY;
      if (Math.abs(deltaY) > 3) dragRef.current.moved = true;
      
      if (dragRef.current.moved) {
        const sensitivity = 0.01; 
        const newVal = dragRef.current.startVal + deltaY * sensitivity;
        const clamped = Math.min(max, Math.max(min, newVal));
        onChange(Number(clamped.toFixed(2)));
        document.body.style.cursor = 'ns-resize';
      }
    };

    const handleMouseUp = () => {
      const wasDrag = dragRef.current?.moved;
      dragRef.current = null;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = '';
      
      if (!wasDrag) {
        setEditValue(String(value));
        setIsEditing(true);
        setTimeout(() => inputRef.current?.select(), 0);
      }
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const containerStyles = variant === 'panel' 
    ? "bg-white border border-gray-200 hover:border-[#FF7A1A]/40 p-[6px] pl-3 pr-2 shadow-sm"
    : "bg-gray-50 border border-gray-200 p-2";

  return (
    <div 
      className={`${containerStyles} rounded-xl flex flex-col gap-0.5 justify-center select-none transition-colors ${isEditing ? '' : 'cursor-ns-resize'} ${className}`}
      onMouseDown={handleMouseDown}
    >
      <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter leading-none">{label}</p>
      <div className="flex items-center justify-between mt-0.5">
        {isEditing ? (
          <input 
            ref={inputRef} 
            type="text" 
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={(e) => { 
              if (e.key === 'Enter') commitEdit(editValue); 
              if (e.key === 'Escape') setIsEditing(false); 
            }}
            onBlur={() => commitEdit(editValue)}
            className="bg-transparent text-[11px] font-bold text-gray-900 tracking-[0.1px] outline-none w-full border-none p-0 m-0" 
            autoFocus 
          />
        ) : (
          <>
            <span className="text-[11px] font-bold text-gray-900/90 cursor-text">{value.toFixed(1)}{suffix}</span>
            <div className="flex flex-col items-center mr-1 text-gray-300">
              <span className="material-symbols-outlined text-[14px] leading-[6px]">arrow_drop_up</span>
              <span className="material-symbols-outlined text-[14px] leading-[6px]">arrow_drop_down</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
