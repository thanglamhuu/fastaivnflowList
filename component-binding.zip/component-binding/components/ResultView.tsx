import React, { useState, useEffect, useRef } from 'react';
import { PillButton } from './Primitives';
import { Flow } from 'flow-sdk';
import { VIDEO_MODELS } from '../App';
import { VideoGenerationService, GenerationOptions } from '../services/VideoGenerationService';
import { VoiceMaster, ProductAnalysis } from '../types';

interface ResultViewProps {
  storyboard: any[];
  references: any[];
  defaultModel: string;
  voiceMaster: VoiceMaster;
  analysis?: ProductAnalysis;
  productName?: string;
  handAction?: string;
  aspectRatio?: '9:16' | '16:9';
}

export const ResultView: React.FC<ResultViewProps> = ({ 
  storyboard, references, defaultModel, voiceMaster, analysis, productName, handAction, aspectRatio = '9:16'
}) => {
  const [videoUrls, setVideoUrls] = useState<Record<number, string>>({});
  const [loading, setLoading] = useState<Record<number, boolean>>({});
  const [errors, setErrors] = useState<Record<number, string>>({});
  const [sceneModels, setSceneModels] = useState<Record<number, string>>({});
  const [draftMode, setDraftMode] = useState<Record<number, boolean>>({});
  const [isFallback, setIsFallback] = useState<Record<number, boolean>>({});

  // Merging State
  const [mergedVideoUrl, setMergedVideoUrl] = useState<string | null>(null);
  const [isMerging, setIsMerging] = useState(false);
  const [mergeProgress, setMergeProgress] = useState(0);
  const [mergeError, setMergeError] = useState<string | null>(null);
  
  const mergeVideoRef = useRef<HTMLVideoElement | null>(null);
  const mergeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const mergedUrlRef = useRef<string | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);

  useEffect(() => {
    return () => {
      Object.values(videoUrls).forEach(url => URL.revokeObjectURL(url));
      if (mergedUrlRef.current) URL.revokeObjectURL(mergedUrlRef.current);
      if (audioCtxRef.current) audioCtxRef.current.close().catch(() => {});
    };
  }, []);

  const clearMerged = () => {
    if (mergedUrlRef.current) {
      URL.revokeObjectURL(mergedUrlRef.current);
      mergedUrlRef.current = null;
    }
    setMergedVideoUrl(null);
  };

  const allScenesHaveVideo = storyboard.length > 0 && storyboard.every((_, i) => !!videoUrls[i]);

  const generateVideo = async (idx: number) => {
    const scene = storyboard[idx];
    const rawModel = sceneModels[idx] || defaultModel;
    const isDraft = draftMode[idx] || false;
    
    setLoading(p => ({ ...p, [idx]: true }));
    setErrors(p => ({ ...p, [idx]: '' }));
    setIsFallback(p => ({ ...p, [idx]: false }));

    try {
      const options: GenerationOptions = {
        modelLabel: rawModel,
        voiceMaster,
        handAction,
        aspectRatio,
        isDraft
      };

      const res = await VideoGenerationService.generateSceneVideo(
        scene,
        analysis || null,
        references,
        options
      );
      
      const bytes = Uint8Array.from(atob(res.base64), c => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: res.mimeType });
      const url = URL.createObjectURL(blob);
      
      if (videoUrls[idx]) URL.revokeObjectURL(videoUrls[idx]);
      setVideoUrls(p => ({ ...p, [idx]: url }));
      if (res.compatibilityFallback) {
        setIsFallback(p => ({ ...p, [idx]: true }));
      }
    } catch (error: any) {
      setErrors(p => ({ ...p, [idx]: error.message }));
    } finally {
      setLoading(p => ({ ...p, [idx]: false }));
    }
  };

  const mergeVideos = async () => {
    if (!allScenesHaveVideo || isMerging) return;

    setIsMerging(true);
    setMergeProgress(0);
    setMergeError(null);

    const canvas = mergeCanvasRef.current;
    const video = mergeVideoRef.current;
    if (!canvas || !video) {
      setMergeError("Lỗi khởi tạo tài nguyên.");
      setIsMerging(false);
      return;
    }

    const is169 = aspectRatio === '16:9';
    canvas.width = is169 ? 1280 : 720;
    canvas.height = is169 ? 720 : 1280;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      setMergeError("Lỗi đồ họa.");
      setIsMerging(false);
      return;
    }

    let combinedStream: MediaStream | null = null;

    try {
      if (!audioCtxRef.current) audioCtxRef.current = new AudioContext();
      const audioCtx = audioCtxRef.current;
      if (audioCtx.state === 'suspended') await audioCtx.resume();
      if (!audioSourceRef.current) audioSourceRef.current = audioCtx.createMediaElementSource(video);
      
      const source = audioSourceRef.current;
      const destination = audioCtx.createMediaStreamDestination();
      source.connect(destination);
      source.connect(audioCtx.destination);
      
      const canvasStream = canvas.captureStream(30);
      combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...destination.stream.getAudioTracks()
      ]);

      const mimeType = MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm';
      const recorder = new MediaRecorder(combinedStream, { mimeType });
      recorderRef.current = recorder;
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };

      const mergePromise = new Promise<string>((resolve, reject) => {
        recorder.onstop = () => resolve(URL.createObjectURL(new Blob(chunks, { type: mimeType })));
        recorder.onerror = () => reject(new Error("Lỗi khi lưu video."));
      });

      recorder.start();

      for (let i = 0; i < storyboard.length; i++) {
        const url = videoUrls[i];
        video.src = url;
        video.load();
        await new Promise((resolve, reject) => { video.onloadedmetadata = resolve; video.onerror = reject; });
        await video.play();

        const renderFrame = () => {
          if (video.paused || video.ended) return;
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const currentTotal = i + (video.currentTime / video.duration);
          setMergeProgress(Math.floor((currentTotal / storyboard.length) * 100));
          requestAnimationFrame(renderFrame);
        };
        renderFrame();
        await new Promise((resolve) => { video.onended = resolve; });
      }

      recorder.stop();
      const finalUrl = await mergePromise;
      source.disconnect();
      clearMerged();
      mergedUrlRef.current = finalUrl;
      setMergedVideoUrl(finalUrl);
      setMergeProgress(100);
    } catch (err: any) {
      setMergeError("Quá trình ghép gặp sự cố. Vui lòng thử lại.");
      if (recorderRef.current && recorderRef.current.state !== 'inactive') recorderRef.current.stop();
    } finally {
      setIsMerging(false);
      if (combinedStream) combinedStream.getTracks().forEach(track => track.stop());
    }
  };

  const downloadMerged = async () => {
    if (!mergedVideoUrl) return;
    try {
      const response = await fetch(mergedVideoUrl);
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const base64 = (reader.result as string).split(',')[1];
          await Flow.download({
            base64,
            mimeType: blob.type,
            filename: `POV_REVIEW_${productName?.replace(/\s+/g, '_') || 'SNACK'}_${Date.now()}.mp4`
          });
        } catch (downloadErr) {
          console.error("Download failed inside reader", downloadErr);
        }
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.error("Tải xuống thất bại", err);
    }
  };

  return (
    <div className="flex flex-col gap-10 animate-slide-up pb-20">
      <video ref={mergeVideoRef} className="hidden" crossOrigin="anonymous" muted={false} />
      <canvas ref={mergeCanvasRef} className="hidden" />

      <div className="bg-white border border-emerald-100 p-6 rounded-[32px] flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <span className="material-symbols-outlined text-emerald-500 text-3xl">movie</span>
          <div>
            <h2 className="text-xl font-black uppercase tracking-tighter text-gray-900">Sẵn sàng tạo video</h2>
            <p className="text-[11px] text-gray-400 uppercase tracking-widest font-bold">CÀI ĐẶT ĐÃ KHÓA • SẴN SÀNG XUẤT BẢN 🔒</p>
          </div>
        </div>

        {allScenesHaveVideo && (
          <div className="flex items-center gap-3">
             {isMerging ? (
                <div className="flex flex-col items-end gap-1">
                  <div className="h-2 w-40 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 transition-all duration-300" style={{ width: `${mergeProgress}%` }} />
                  </div>
                  <span className="text-[11px] font-black text-emerald-600 uppercase tracking-widest">Đang ghép: {mergeProgress}%</span>
                </div>
             ) : (
                <div className="w-56">
                  <PillButton 
                    variant="solid" 
                    onClick={mergeVideos} 
                    icon={<span className="material-symbols-outlined text-[20px]">merge</span>}
                  >
                    GHÉP TẤT CẢ VIDEO
                  </PillButton>
                </div>
             )}
          </div>
        )}
      </div>

      {mergeError && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-[13px] font-medium animate-shake mx-2">
           <span className="font-bold uppercase mr-2">Thông báo:</span> {mergeError}
        </div>
      )}

      {mergedVideoUrl && (
        <div className="flex flex-col gap-6 bg-gray-50 p-8 rounded-[40px] border border-emerald-100 animate-slide-up mx-2 shadow-sm">
           <div className="flex justify-between items-center px-2">
              <div className="flex flex-col">
                <h3 className="text-xl font-black uppercase tracking-tighter text-gray-900">VIDEO HOÀN CHỈNH (MASTER)</h3>
                <span className="text-[11px] text-gray-400 uppercase tracking-widest font-bold">KẾT QUẢ CUỐI CÙNG • ĐỊNH DẠNG {aspectRatio} POV</span>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={clearMerged} 
                  className="text-[11px] font-black text-gray-400 hover:text-gray-600 uppercase tracking-widest px-4 transition-colors"
                >
                  Xóa kết quả
                </button>
                <div className="w-56">
                  <PillButton 
                    variant="solid" 
                    onClick={downloadMerged} 
                    icon={<span className="material-symbols-outlined text-[20px]">download</span>}
                  >
                    TẢI VIDEO XUỐNG
                  </PillButton>
                </div>
              </div>
           </div>
           <div className={`mx-auto w-full bg-black rounded-[32px] overflow-hidden border border-gray-100 shadow-xl ${aspectRatio === '16:9' ? 'aspect-video max-w-[900px]' : 'aspect-[9/16]'}`}>
              <video src={mergedVideoUrl} controls className="w-full h-full object-contain" playsInline />
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-16">
        {storyboard.map((scene, idx) => (
          <div key={idx} className="flex flex-col md:flex-row gap-8 items-start group">
            <div className={`shrink-0 flex flex-col gap-3 ${aspectRatio === '16:9' ? 'w-full md:w-[320px]' : 'w-[240px]'}`}>
              <div className="flex justify-between items-center px-1">
                <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest">Hình phân cảnh</span>
                <span className="text-[11px] font-black text-emerald-600 uppercase">{scene.timeRange}</span>
              </div>
              <div className={`rounded-[24px] overflow-hidden border border-gray-100 bg-gray-50 shadow-inner ${aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'}`}>
                {scene.storyboardImage ? (
                  <img src={`data:${scene.storyboardImage.mimeType};base64,${scene.storyboardImage.base64}`} className="w-full h-full object-cover" alt={`Cảnh ${idx + 1}`} />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <span className="material-symbols-outlined text-gray-200 text-4xl">image_not_supported</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex-1 flex flex-col gap-6 w-full">
              <div className="flex flex-col gap-5 bg-white p-8 rounded-[32px] border border-gray-100 transition-all hover:border-[#FF7A1A]/20 shadow-sm relative">
                
                {isFallback[idx] && (
                  <div className="absolute top-4 right-8 flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-100 rounded-full animate-fade-in">
                    <span className="material-symbols-outlined text-amber-500 text-[14px]">info</span>
                    <span className="text-[9px] font-black text-amber-600 uppercase tracking-widest">Đã dùng chế độ tương thích (3 ảnh)</span>
                  </div>
                )}

                <div className="flex flex-col gap-2">
                  <h3 className="text-xl font-black uppercase tracking-tighter text-gray-900">{scene.action || `Phân cảnh ${idx + 1}`}</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 uppercase tracking-widest">Đã khóa lời thoại 🔒</span>
                  </div>
                  <p className="text-[16px] font-medium italic text-emerald-700 leading-relaxed bg-gray-50 p-4 rounded-2xl border border-gray-100 mt-1 shadow-inner">
                    "{scene.voiceOver}"
                  </p>
                </div>
                
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest">Mô hình và cài đặt</span>
                    {(sceneModels[idx] || defaultModel).includes("Flash") && (
                      <button 
                        onClick={() => setDraftMode(p => ({ ...p, [idx]: !p[idx] }))}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${draftMode[idx] ? 'text-amber-600 bg-amber-50' : 'text-gray-400 hover:text-gray-600'}`}
                      >
                        <span className="material-symbols-outlined text-[18px]">{draftMode[idx] ? 'bolt' : 'shutter_speed'}</span>
                        <span className="text-[11px] font-black uppercase tracking-widest">{draftMode[idx] ? 'Chế độ tạo nhanh (360p)' : 'Chế độ tạo nhanh'}</span>
                      </button>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {VIDEO_MODELS.map(m => {
                      const isActive = (sceneModels[idx] || defaultModel) === m;
                      return (
                        <button 
                          key={m}
                          onClick={() => setSceneModels(p => ({ ...p, [idx]: m }))}
                          className={`px-4 py-2.5 rounded-xl text-[12px] font-black uppercase tracking-tighter transition-all border ${
                            isActive 
                              ? 'bg-orange-50 text-[#FF7A1A] border-[#FF7A1A] shadow-sm' 
                              : 'bg-gray-50 text-gray-400 border-gray-200 hover:border-gray-400 hover:text-gray-900'
                          }`}
                        >
                          {m}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="w-full mt-2">
                  <PillButton variant={videoUrls[idx] ? "outline" : "solid"} onClick={() => generateVideo(idx)} disabled={loading[idx]}>
                    {loading[idx] ? 'ĐANG TẠO...' : videoUrls[idx] ? 'TẠO LẠI VIDEO CẢNH NÀY' : 'TẠO VIDEO CẢNH NÀY'}
                  </PillButton>
                </div>

                {errors[idx] && (
                  <div className="p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-[13px] font-medium animate-shake">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="material-symbols-outlined text-[18px]">error</span>
                      <span className="font-bold uppercase text-[11px] tracking-widest">Thông báo:</span>
                    </div>
                    {errors[idx]}
                  </div>
                )}
              </div>

              <div className={`bg-black rounded-[40px] overflow-hidden border border-gray-100 relative shadow-xl group-hover:border-[#FF7A1A]/20 transition-all duration-500 ${aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'}`}>
                {videoUrls[idx] ? (
                  <video src={videoUrls[idx]} controls className="w-full h-full object-contain" playsInline />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-12 text-center bg-gray-50">
                    {loading[idx] ? (
                      <div className="flex flex-col items-center gap-5">
                        <div className="w-16 h-16 border-[5px] border-orange-100 border-t-[#FF7A1A] rounded-full animate-spin shadow-[0_0_20px_rgba(255,122,26,0.1)]" />
                        <div className="flex flex-col gap-1">
                          <p className="text-[14px] font-black uppercase tracking-[0.2em] text-gray-900">Đang tạo video</p>
                          <p className="text-[11px] text-gray-400 uppercase tracking-tighter">Vui lòng chờ trong giây lát...</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <span className="material-symbols-outlined text-8xl text-gray-900">videocam</span>
                        <p className="text-[14px] font-black uppercase tracking-widest text-gray-900">Khu vực xem trước</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
