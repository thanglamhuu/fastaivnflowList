import React, { useState, useEffect, useRef } from 'react';

export function useOnClickOutside(ref: React.RefObject<HTMLElement | null>, handler: (e: MouseEvent | TouchEvent) => void) {
  useEffect(() => {
    const listener = (event: MouseEvent | TouchEvent) => {
      if (!ref.current || ref.current.contains(event.target as Node)) return;
      handler(event);
    };
    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [ref, handler]);
}

export const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="flex items-center px-2">
    <span className="text-[12px] font-bold text-[#6B7280] tracking-[0.12em] uppercase">
      {children}
    </span>
  </div>
);

export const PillButton: React.FC<{
  icon?: React.ReactNode; 
  children: React.ReactNode;
  variant?: 'filled' | 'outline' | 'solid'; 
  onClick?: () => void;
  disabled?: boolean;
}> = ({ icon, children, variant = 'filled', onClick, disabled }) => {
  const base = 'flex items-center gap-[10px] justify-center w-full h-[46px] rounded-xl font-bold tracking-tight transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed';
  const variants: Record<string, string> = {
    filled: 'bg-white border border-gray-200 hover:bg-gray-50 active:bg-gray-100 text-[#111827] text-[15px] px-5 shadow-sm',
    outline: 'border border-gray-200 hover:bg-gray-50 active:bg-gray-100 text-[15px] px-5 text-[#111827]',
    solid: 'bg-[#FF7A1A] hover:bg-[#FF963D] active:bg-[#E06616] text-white text-[15px] px-5 shadow-lg shadow-[#FF7A1A]/15',
  };
  return (
    <button className={`${base} ${variants[variant]}`} onClick={onClick} disabled={disabled}>
      {icon && <span className="flex items-center justify-center">{icon}</span>}
      <span className="truncate">{children}</span>
    </button>
  );
};

export const TextInput: React.FC<{
  value: string; 
  onChange: (val: string) => void; 
  placeholder?: string;
}> = ({ value, onChange, placeholder }) => (
  <textarea 
    value={value} 
    onChange={(e) => onChange(e.target.value)} 
    placeholder={placeholder}
    rows={2}
    className="border border-gray-200 hover:border-[#FF7A1A]/40 focus:border-[#FF7A1A] rounded-xl w-full px-4 py-3 resize-none bg-white text-[14px] font-medium text-[#111827] placeholder-gray-400 tracking-[0.1px] focus:outline-none transition-colors" 
  />
);

export const SegmentedToggle: React.FC<{
  value: string; 
  items: { value: string; label: string; icon?: React.ReactNode }[];
  onChange: (val: string) => void;
}> = ({ value, items, onChange }) => (
  <div className="flex w-full items-center border border-gray-200 rounded-xl overflow-hidden bg-white p-1 shadow-sm">
    {items.map((item) => (
      <button 
        key={item.value} 
        type="button" 
        onClick={() => onChange(item.value)}
        className={`flex-1 flex items-center justify-center gap-1.5 h-[38px] rounded-[10px] text-[13px] font-bold tracking-tight transition-all cursor-pointer ${
          value === item.value ? 'bg-[#FF7A1A] text-white' : 'text-gray-500 hover:text-gray-900'
        }`}
      >
        {item.icon}<span>{item.label}</span>
      </button>
    ))}
  </div>
);

export const FieldDropdown: React.FC<{
  label: string; 
  value: string; 
  options: string[];
  onChange: (val: string) => void; 
  className?: string;
}> = ({ label, value, options, onChange, className = '' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useOnClickOutside(ref, () => setIsOpen(false));

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button type="button" onClick={() => setIsOpen(!isOpen)}
        className="w-full text-left border border-gray-200 hover:border-[#FF7A1A]/40 transition-colors rounded-xl flex flex-col gap-0.5 justify-center pb-2.5 pl-4 pr-3 pt-[8px] select-none focus:outline-none bg-white shadow-sm">
        <p className="text-[11px] font-bold text-gray-400 uppercase tracking-tighter">{label}</p>
        <div className="flex items-center justify-between">
          <span className="text-[13px] font-bold text-gray-900/90 truncate">{value}</span>
          <span className={`material-symbols-outlined text-[20px] text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`}>keyboard_arrow_down</span>
        </div>
      </button>
      {isOpen && (
        <div className="absolute z-50 bottom-[calc(100%+4px)] left-0 w-full bg-white border border-gray-200 rounded-xl overflow-hidden shadow-2xl animate-dropdown origin-bottom">
          <div className="max-h-56 overflow-y-auto custom-scrollbar">
            {options.map((opt) => (
              <button key={opt} type="button"
                className={`w-full text-left px-4 py-3 text-[13px] font-bold tracking-tight hover:bg-gray-50 transition-colors ${value === opt ? 'bg-orange-50 text-[#FF7A1A]' : 'text-gray-600'}`}
                onClick={() => { onChange(opt); setIsOpen(false); }}>
                {opt}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
