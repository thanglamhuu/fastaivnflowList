import React from 'react';
import { PillButton } from './Primitives';
import { MasterScriptData } from '../types';

interface MasterScriptCardProps {
  data: MasterScriptData;
  status: 'DRAFT' | 'LOCKED';
  onUpdate: (val: MasterScriptData) => void;
  onLock: () => void;
  onUnlock: () => void;
  onRegenerate: () => void;
  onNext: () => void;
  isNextLoading: boolean;
  showNext: boolean;
  voiceMaster: any;
  onReImport?: () => void;
}

export const MasterScriptCard: React.FC<MasterScriptCardProps> = ({
  data, status, onUpdate, onLock, onUnlock, onRegenerate, onNext, isNextLoading, showNext, voiceMaster, onReImport
}) => {
  const isLocked = status === 'LOCKED';

  const updateSceneField = (idx: number, field: string, value: any) => {
    const newScenes = [...data.scenes];
    newScenes[idx] = { ...newScenes[idx], [field]: value };
    onUpdate({ ...data, scenes: newScenes });
  };

  return (
    <div className={`bg-white rounded-[32px] border transition-all animate-fade-in-up ${isLocked ? 'border-emerald-200 shadow-sm' : 'border-gray-100'}`}>
      <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <span className="material-symbols-outlined text-[#FF7A1A] text-[24px]">{data.isManual ? 'history_edu' : 'mic'}</span>
          <div className="flex flex-col">
            <span className="text-[12px] font-bold text-gray-600 uppercase tracking-widest">KỊCH BẢN REVIEW (VOICE LOCK)</span>
            {data.isManual && <span className="text-[10px] text-amber-600 font-black uppercase tracking-tighter">Tối ưu từ kịch bản bạn cung cấp</span>}
          </div>
          {isLocked && (
            <span className="text-[10px] bg-emerald-100 text-emerald-700 px-3 py-1 rounded-lg font-black tracking-widest uppercase animate-pulse ml-2 border border-emerald-200">
              ĐÃ KHÓA LỜI THOẠI 🔒
            </span>
          )}
        </div>
        <div className="flex gap-3">
          {!isLocked ? (
            <>
              {data.isManual ? (
                <div className="w-40">
                  <PillButton variant="outline" onClick={onReImport} icon={<span className="material-symbols-outlined text-[20px]">edit_square</span>}>NHẬP LẠI</PillButton>
                </div>
              ) : (
                <div className="w-48">
                  <PillButton variant="outline" onClick={onRegenerate} icon={<span className="material-symbols-outlined text-[20px]">refresh</span>}>TẠO LẠI (AI)</PillButton>
                </div>
              )}
              <div className="w-48">
                <PillButton variant="solid" onClick={onLock} icon={<span className="material-symbols-outlined text-[20px]">lock</span>}>CHỐT KỊCH BẢN</PillButton>
              </div>
            </>
          ) : (
            <div className="w-56">
              <PillButton variant="outline" onClick={onUnlock} icon={<span className="material-symbols-outlined text-[20px]">lock_open</span>}>MỞ KHÓA ĐỂ SỬA</PillButton>
            </div>
          )}
        </div>
      </div>

      <div className="p-8 flex flex-col gap-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 border border-gray-100 p-5 rounded-2xl flex flex-col gap-2 shadow-inner">
             <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Ý TƯỞNG CHÍNH</span>
             <p className="text-[14px] font-bold text-gray-900 leading-tight">{data.coreIdea}</p>
          </div>
          <div className="bg-gray-50 border border-gray-100 p-5 rounded-2xl flex flex-col gap-2 shadow-inner">
             <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">ĐIỂM NỔI BẬT SẢN PHẨM</span>
             <p className="text-[14px] font-bold text-emerald-700 leading-tight">{data.heroSellingPoint}</p>
          </div>
        </div>

        <div className="flex flex-col gap-5">
          <div className="flex justify-between items-center px-1">
            <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest">LỜI THOẠI CHI TIẾT THEO CẢNH</span>
            <span className="text-[10px] font-bold text-gray-300 uppercase">TỰ ĐỘNG KHỚP THỜI GIAN</span>
          </div>
          <div className="grid grid-cols-1 gap-5">
            {data.scenes.map((scene, idx) => (
              <div key={idx} className="flex flex-col gap-4 bg-gray-50/50 p-6 rounded-[24px] border border-gray-100 group relative transition-all hover:bg-gray-50">
                <div className="flex justify-between items-center border-b border-gray-100 pb-3">
                  <div className="flex items-center gap-4">
                    <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest">PHÂN CẢNH {scene.sceneNumber}</span>
                    <div className="flex items-center gap-1.5 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-100">
                       <span className="text-[12px] font-bold text-emerald-600 uppercase tracking-tighter">{scene.timeRange}</span>
                       {scene.durationSeconds && <span className="text-[10px] text-emerald-600/50 font-black">({scene.durationSeconds} giây)</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[16px] text-gray-400">touch_app</span>
                    <span className="text-[11px] font-bold text-gray-500 uppercase tracking-tighter">Hành động: {scene.suggestedAction || 'Tự động'}</span>
                  </div>
                </div>
                
                <textarea 
                  value={scene.voiceOver} 
                  onChange={(e) => updateSceneField(idx, 'voiceOver', e.target.value)}
                  disabled={isLocked}
                  placeholder={`Nhập lời thoại review cho cảnh ${scene.sceneNumber}...`}
                  className="w-full bg-transparent border-none outline-none text-[16px] font-medium leading-relaxed italic text-emerald-800 resize-none min-h-[50px] custom-scrollbar focus:ring-0 placeholder-gray-300"
                />
              </div>
            ))}
          </div>

          <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest px-1 mt-4">LỜI KÊU GỌI (CTA) CUỐI VIDEO</span>
          <div className="bg-emerald-50/30 p-5 rounded-2xl border border-emerald-100 shadow-inner">
             <textarea 
               value={data.cta} 
               onChange={(e) => onUpdate({ ...data, cta: e.target.value })}
               disabled={isLocked}
               placeholder="Lời kêu gọi hành động (Ví dụ: Bấm vào giỏ hàng bên dưới nhé)..."
               rows={2}
               className="w-full bg-transparent border-none outline-none text-[15px] font-bold text-emerald-600 resize-none focus:ring-0 placeholder-emerald-600/20"
             />
          </div>
          
          <div className="flex items-center justify-between px-2 mt-3">
            <div className="flex items-center gap-4">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Giọng đọc đang sử dụng</span>
                <span className="text-[13px] font-bold text-emerald-600">{voiceMaster.voiceName} (Tốc độ {voiceMaster.speakingSpeed}x)</span>
              </div>
            </div>
            {!isLocked && <p className="text-[12px] text-gray-400 italic text-right max-w-[280px]">AI tự động điều chỉnh độ dài lời thoại để khớp với tốc độ {voiceMaster.speakingSpeed}x.</p>}
          </div>
        </div>
      </div>

      {showNext && (
        <div className="p-5 bg-gray-50/50 border-t border-gray-100 flex justify-end">
          <div className="w-72">
            <PillButton 
              variant="solid" 
              onClick={onNext} 
              disabled={isNextLoading} 
              icon={<span className="material-symbols-outlined text-[20px]">brush</span>}
            >
              {isNextLoading ? 'ĐANG VẼ...' : 'TIẾP THEO: TẠO HÌNH PHÂN CẢNH'}
            </PillButton>
          </div>
        </div>
      )}
    </div>
  );
};
