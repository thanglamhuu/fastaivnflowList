import React from 'react';
import { BatchTask } from '../types';
import { BatchTaskCard } from './BatchTaskCard';

interface BatchTaskBoardProps {
  tasks: BatchTask[];
  onUpdateTask: (id: string, updates: Partial<BatchTask>) => void;
  onResetTask: (id: string) => void;
  onLoadToSingle: (task: BatchTask) => void;
}

export const BatchTaskBoard: React.FC<BatchTaskBoardProps> = ({ 
  tasks, onUpdateTask, onResetTask, onLoadToSingle 
}) => {
  return (
    <div className="flex flex-col gap-8 w-full animate-slide-up">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-4">
        <div className="flex flex-col">
          <h2 className="text-2xl font-black uppercase tracking-tighter text-[#111827]">Hệ thống Batch Review</h2>
          <div className="flex items-center gap-2 mt-1">
             <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
             <p className="text-[11px] text-[#6B7280] uppercase font-bold tracking-widest">Đang chạy song song tối đa 3 sản phẩm</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 bg-amber-50 border border-amber-100 px-4 py-2 rounded-2xl">
          <span className="material-symbols-outlined text-amber-600 text-[20px]">info</span>
          <p className="text-[11px] font-bold text-amber-700 leading-tight">
            Luồng Batch tự động: Phân tích → Kịch bản → Vẽ phân cảnh → Tạo video demo.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 px-2">
        {tasks.map(task => (
          <BatchTaskCard 
            key={task.id} 
            task={task} 
            onUpdate={(u) => onUpdateTask(task.id, u)} 
            onReset={() => onResetTask(task.id)}
            onLoadToSingle={onLoadToSingle}
          />
        ))}
      </div>

      {tasks.some(t => t.status === 'completed') && (
        <div className="mt-4 p-8 bg-white border border-emerald-100 rounded-[40px] flex flex-col items-center text-center gap-4 animate-fade-in shadow-sm mx-2">
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center">
            <span className="material-symbols-outlined text-4xl text-emerald-500">task_alt</span>
          </div>
          <div>
            <h3 className="text-xl font-black uppercase text-[#111827]">Dữ liệu Batch đã sẵn sàng</h3>
            <p className="text-gray-500 max-w-lg mx-auto mt-2 text-[14px]">
              Bạn có thể xem lại kết quả phác thảo của từng sản phẩm. Bấm <strong>"SỬA TRONG TỪNG SP"</strong> để tiến hành tinh chỉnh lời thoại và tạo video chất lượng cao nhất.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
