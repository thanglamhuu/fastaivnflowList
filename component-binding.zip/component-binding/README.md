# POV Đồ Ăn Vặt — Component Binding

Bản sao mã nguồn trích xuất từ công cụ Google Flow vào ngày 2026-09-11.

- Công cụ gốc: https://flow.google.com/project/70f904f3-eede-4374-8b49-888eba5fbde3/tool/e1d14a7f-9a2e-46ad-bf8c-8b0e40597b9e?mode=EDIT
- Phạm vi: mã nguồn của công cụ POV Đồ Ăn Vặt hiện tại, gồm 18 tệp TypeScript/React.
- Không bao gồm ảnh/video tham chiếu, dữ liệu phiên, khóa đã kích hoạt, hay mã nguồn của các công cụ Flow khác.

Lưu ý: đây là bản sao nguồn. Để chạy độc lập ngoài Google Flow, cần bổ sung cấu hình build/dependency và các tích hợp Flow SDK theo môi trường triển khai.
