import { Flow } from 'flow-sdk';
import { 
  BatchTask, 
  VoiceMaster, 
  ProductAnalysis, 
  MasterScriptData, 
  StoryboardData 
} from '../types';
import { PromptService, normalizeAnalysis } from './PromptService';
import { VideoGenerationService, GenerationOptions } from './VideoGenerationService';

export interface BatchOptions {
  globalModel: string;
  voiceMaster: VoiceMaster;
  handAction: string;
  duration: string;
  aspectRatio: '9:16' | '16:9';
}

/**
 * Điều phối luồng xử lý cho một Batch Task duy nhất.
 */
export const BatchWorkflowService = {
  async executeTask(
    task: BatchTask, 
    options: BatchOptions,
    onUpdate: (updates: Partial<BatchTask>) => void,
    validateAccess: () => boolean
  ): Promise<void> {
    try {
      if (!validateAccess()) {
        throw new Error("Mã kích hoạt đã hết hạn hoặc không khả dụng.");
      }

      const { globalModel, voiceMaster, handAction, duration, aspectRatio } = options;
      const activeRefs = task.references.filter(r => r !== null);

      // Bước 1: Phân tích sản phẩm (15%)
      onUpdate({ status: 'running', progress: 5 });
      const rawAnalysis = await PromptService.analyzeProduct({ 
        productName: task.productName, 
        productDesc: '', 
        references: activeRefs 
      });
      const analysis = normalizeAnalysis(rawAnalysis);
      onUpdate({ progress: 15 });

      // Bước 2: Tạo kịch bản Master (10%)
      const script = await PromptService.generateMasterScript({ 
        analysis, 
        productName: task.productName, 
        productDesc: '', 
        duration, 
        voiceMaster, 
        handAction 
      });
      onUpdate({ progress: 25 });

      // Bước 3: Lập kế hoạch Storyboard (5%)
      onUpdate({ progress: 30 });
      let storyboard = await PromptService.createStoryboardPlan({ 
        analysis, 
        scriptData: script, 
        productName: task.productName, 
        references: activeRefs 
      });

      // Bước 4: Vẽ khung hình Storyboard (20%)
      const updatedScenes = [...storyboard.scenes];
      for (let i = 0; i < updatedScenes.length; i++) {
        const scene = updatedScenes[i];
        onUpdate({ currentScene: i + 1, progress: 30 + (i * 5) });
        
        try {
          const image = await PromptService.generateStoryboardFrame({ 
            scene, 
            analysis, 
            references: activeRefs, 
            aspectRatio 
          });
          updatedScenes[i] = { ...scene, storyboardImage: image, generationStatus: 'done' };
        } catch (err) {
          updatedScenes[i] = { ...scene, generationStatus: 'error' };
        }
      }
      storyboard = { ...storyboard, scenes: updatedScenes };
      onUpdate({ progress: 50 });

      // Bước 5: Lập kế hoạch Video (5%)
      const finalPlan = await PromptService.generateFinalPlan({ 
        analysis, 
        scriptData: script, 
        storyboard, 
        productName: task.productName, 
        duration, 
        references: activeRefs, 
        model: globalModel, 
        voiceMaster, 
        handAction 
      });
      onUpdate({ progress: 55 });

      // Bước 6: Tạo từng cảnh Video (45%)
      const finalScenesWithVideo = [];
      const generationOptions: GenerationOptions = {
        modelLabel: globalModel,
        voiceMaster,
        handAction,
        aspectRatio
      };

      for (let i = 0; i < finalPlan.length; i++) {
        const sceneData = finalPlan[i];
        onUpdate({ currentScene: i + 1, progress: 55 + (i * 11) });

        try {
          const res = await VideoGenerationService.generateSceneVideo(
            sceneData,
            analysis,
            activeRefs,
            generationOptions
          );

          const bytes = Uint8Array.from(atob(res.base64), c => c.charCodeAt(0));
          const blob = new Blob([bytes], { type: res.mimeType });
          const url = URL.createObjectURL(blob);

          finalScenesWithVideo.push({ 
            ...sceneData, 
            videoUrl: url, 
            videoBase64: res.base64, 
            videoMimeType: res.mimeType,
            isFallback: res.compatibilityFallback
          });
        } catch (err: any) {
          finalScenesWithVideo.push({ ...sceneData, videoUrl: null, error: err.message });
        }
      }

      onUpdate({ 
        status: 'completed', 
        progress: 100,
        result: {
          analysis,
          script,
          storyboard,
          finalScenes: finalScenesWithVideo
        }
      });

    } catch (err: any) {
      onUpdate({ 
        status: 'failed', 
        error: err.message || 'Lỗi quy trình hệ thống' 
      });
    }
  }
};
