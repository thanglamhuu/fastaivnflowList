import { VoiceMaster } from '../types';

export const VoiceService = {
  /**
   * Builds the explicit instruction string for the TTS engine.
   * Priority: Language -> Accent -> Style -> Tone -> Custom Instructions.
   */
  buildVoiceInstruction(voiceMaster: VoiceMaster): string {
    const parts: string[] = [];

    // Tốc độ nói: Chuyển đổi, kiểm tra tính hợp lệ, clamp 0.8-1.3 và làm tròn 1 chữ số thập phân
    const rawSpeed = Number(voiceMaster.speakingSpeed);
    const validSpeed = Number.isFinite(rawSpeed) ? rawSpeed : 1.0;
    const clampedSpeed = Math.min(Math.max(validSpeed, 0.8), 1.3).toFixed(1);

    if (voiceMaster.language === 'Vietnamese') {
      parts.push(
        'Speak entirely in Vietnamese.',
        'Use natural Vietnamese pronunciation.',
        'Do not translate the text.',
        'Do not switch to English.',
        'Read all Vietnamese diacritics correctly.'
      );

      // Map accents to specific Vietnamese linguistic instructions
      const accentMapping: Record<string, string> = {
        'Tự nhiên': 'Giọng tiếng Việt tự nhiên',
        'Miền Bắc': 'Giọng tiếng Việt miền Bắc tự nhiên',
        'Miền Trung': 'Giọng tiếng Việt miền Trung tự nhiên',
        'Miền Nam': 'Giọng tiếng Việt miền Nam tự nhiên',
        'Miền Tây / Nam Bộ': 'Giọng nữ tiếng Việt Nam Bộ/Miền Tây tự nhiên, mềm, gần gũi, không cường điệu phương ngữ'
      };

      if (accentMapping[voiceMaster.accent]) {
        parts.push(accentMapping[voiceMaster.accent]);
      } else if (voiceMaster.accent) {
        parts.push(`Accent style: ${voiceMaster.accent}.`);
      }

      // Default Snack POV context if it's a review
      parts.push(
        'Natural Southern/Mekong conversational delivery.',
        'Sweet, clear, youthful and friendly.',
        'TikTok snack review style.',
        'Sound spontaneous and conversational, not like a formal commercial.'
      );
    } else {
      if (voiceMaster.accent) {
        parts.push(`Accent/style: ${voiceMaster.accent}.`);
      }
    }

    // Precise speed and stability instructions
    parts.push(
      `Maintain a consistent speaking speed of exactly ${clampedSpeed}x throughout the entire audio.`,
      'STRICT BEHAVIOR: No speed fluctuations.',
      'STRICT BEHAVIOR: No restarts, no stutters, and no word or phrase repetitions.',
      'STRICT BEHAVIOR: After completing the provided text, stop immediately with no trailing noise or echoes.'
    );

    if (voiceMaster.ageImpression) {
      parts.push(`Age impression: ${voiceMaster.ageImpression}.`);
    }

    if (voiceMaster.tone) {
      parts.push(`Tone: ${voiceMaster.tone}.`);
    }

    if (voiceMaster.delivery) {
      parts.push(`Delivery style: ${voiceMaster.delivery}.`);
    }

    if (voiceMaster.customStyleInstruction) {
      parts.push(voiceMaster.customStyleInstruction);
    }

    return parts.join(' ');
  },

  /**
   * Validates and prepares text for TTS synthesis.
   * Ensures diacritics are preserved and text is not romanized.
   */
  async synthesizeSpeech(text: string, voiceMaster: VoiceMaster): Promise<{ voiceInstruction: string }> {
    const voiceInstruction = this.buildVoiceInstruction(voiceMaster);

    // DEBUG LOGGING
    console.log('[TTS] voice:', voiceMaster.voiceName);
    console.log('[TTS] language:', voiceMaster.language);
    console.log('[TTS] accent:', voiceMaster.accent);
    console.log('[TTS] speed:', voiceMaster.speakingSpeed);
    console.log('[TTS] text:', text);
    console.log('[TTS] instruction:', voiceInstruction);

    return { voiceInstruction };
  }
};
