import { importSPKI, jwtVerify } from 'jose';

const PRODUCT_ID = "snack-master-pov-pro";
const SERVER_URL = "https://st-tvc-license-server.st-flow-studio.workers.dev";
const OFFLINE_KEY_PREFIX = 'STTV1.';
const STORAGE_KEY = `${PRODUCT_ID}.license.v1`;
const ONLINE_CACHE_KEY = `${PRODUCT_ID}.online.cache.v1`;

const PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAWudnHnlcEyMhZlQshLKxz/jBt+fw+ADegr9O62Z8cEU=
-----END PUBLIC KEY-----`;

export interface LicenseSession {
  key: string;
  machineId: string;
  licenseName: string;
  expiresAt: number;
  issuedAt: number;
  isOnline?: boolean;
  token?: string;
}

export const LicenseService = {
  async fetchWithTimeout(url: string, options: RequestInit, timeoutMs = 12000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timeoutId);
      return response;
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') throw new Error("Yêu cầu quá hạn (Timeout). Vui lòng kiểm tra kết nối mạng.");
      throw err;
    }
  },

  async safeParseJson(response: Response) {
    try {
      const text = await response.text();
      try {
        return JSON.parse(text);
      } catch (e) {
        return { message: text || "Lỗi phản hồi từ máy chủ." };
      }
    } catch (err) {
      return { message: "Không thể đọc dữ liệu phản hồi." };
    }
  },

  async activateOnline(licenseKey: string, machineId: string): Promise<LicenseSession> {
    const fingerprint = `flow-machine:${machineId}`;
    const res = await this.fetchWithTimeout(`${SERVER_URL}/v1/licenses/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        productId: PRODUCT_ID,
        licenseKey: licenseKey.trim(),
        deviceFingerprint: fingerprint,
        deviceLabel: "Google Flow / Chrome"
      })
    });

    const data = await this.safeParseJson(res);
    if (!res.ok) throw new Error(data.message || "Không thể kích hoạt mã online.");

    const license = data.license;
    const session = data.session;

    return {
      key: licenseKey.trim(),
      machineId: machineId,
      licenseName: license.customerName || "Bản quyền Online",
      expiresAt: license.expiresAt || session.licenseExpiresAt,
      issuedAt: Math.floor(Date.now() / 1000),
      isOnline: true,
      token: session.token
    };
  },

  async resumeOnline(machineId: string): Promise<LicenseSession | null> {
    const fingerprint = `flow-machine:${machineId}`;
    try {
      const res = await this.fetchWithTimeout(`${SERVER_URL}/v1/licenses/resume-device`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: PRODUCT_ID,
          deviceFingerprint: fingerprint,
          deviceLabel: "Google Flow / Chrome"
        })
      });

      if (res.status === 404) return null; 
      
      const data = await this.safeParseJson(res);
      if (!res.ok) {
        if (data.code === 'LICENSE_EXPIRED' || data.code === 'LICENSE_REVOKED') {
          throw new Error(data.message || "Bản quyền online đã hết hạn hoặc bị thu hồi.");
        }
        return null;
      }

      return {
        key: data.license?.licenseKey || "ONLINE_SESSION",
        machineId: machineId,
        licenseName: data.license?.customerName || "Bản quyền Online",
        expiresAt: data.license?.expiresAt || data.session?.licenseExpiresAt,
        issuedAt: Math.floor(Date.now() / 1000),
        isOnline: true,
        token: data.session?.token
      };
    } catch (err: any) {
      if (err.message?.includes("hết hạn") || err.message?.includes("thu hồi")) throw err;
      return null;
    }
  },

  async heartbeat(token: string): Promise<{ token: string; expiresAt: number }> {
    const res = await this.fetchWithTimeout(`${SERVER_URL}/v1/licenses/heartbeat`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });

    const data = await this.safeParseJson(res);
    if (!res.ok) {
      const err = new Error(data.message || "Phiên làm việc hết hiệu lực.");
      (err as any).status = res.status;
      throw err;
    }

    return {
      token: data.session.token,
      expiresAt: data.session.licenseExpiresAt
    };
  },

  saveSession(session: LicenseSession): void {
    try {
      if (session.isOnline) {
        localStorage.setItem(ONLINE_CACHE_KEY, JSON.stringify({
          machineId: session.machineId,
          expiresAt: session.expiresAt,
          licenseName: session.licenseName,
          issuedAt: session.issuedAt,
          isOnline: true,
          token: session.token
        }));
      } else {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ key: session.key }));
      }
    } catch (e) {}
  },

  getOnlineCache(machineId: string): LicenseSession | null {
    try {
      const stored = localStorage.getItem(ONLINE_CACHE_KEY);
      if (!stored) return null;
      const cached = JSON.parse(stored);
      
      const now = Math.floor(Date.now() / 1000);
      if (cached.machineId === machineId && cached.expiresAt > now) {
        return {
          ...cached,
          key: "ONLINE_SESSION" 
        };
      }
      this.clearSavedSession();
      return null;
    } catch (e) {
      return null;
    }
  },

  clearSavedSession(): void {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(ONLINE_CACHE_KEY);
    } catch (e) {}
  },

  async restoreSession(machineId: string): Promise<LicenseSession | null> {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) return null;

      const parsed = JSON.parse(stored);
      const key = parsed?.key;

      if (typeof key !== 'string' || !key.trim()) {
        this.clearSavedSession();
        return null;
      }

      return await this.verifyKey(key, machineId);
    } catch (e) {
      this.clearSavedSession();
      return null;
    }
  },

  async getMachineId(): Promise<string> {
    const features = [
      navigator.platform,
      navigator.language,
      Intl.DateTimeFormat().resolvedOptions().timeZone,
      screen.width,
      screen.height,
      screen.colorDepth,
      navigator.hardwareConcurrency,
      (navigator as any).deviceMemory || 0
    ].join('|');

    const fnv1a32 = (str: string, seed: number): number => {
      let hash = seed;
      for (let i = 0; i < str.length; i++) {
        hash ^= str.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
      return hash >>> 0;
    };

    const h1 = fnv1a32(features, 0x811C9DC5);
    const h2 = fnv1a32(features, 0x01234567);

    const hex1 = h1.toString(16).padStart(8, '0').toUpperCase();
    const hex2 = h2.toString(16).padStart(8, '0').toUpperCase();

    return `ST-${hex1}${hex2}`;
  },

  async verifyKey(key: string, machineId: string): Promise<LicenseSession> {
    const normalizedKey = (key || "").trim().replace(/\s+/g, '');
    if (!normalizedKey.startsWith(OFFLINE_KEY_PREFIX)) throw new Error("Mã không hợp lệ.");

    const token = normalizedKey.slice(OFFLINE_KEY_PREFIX.length);
    if (!token || token.split('.').length !== 3) throw new Error("Cấu trúc mã không hợp lệ.");

    try {
      let publicKey;
      try {
        publicKey = await importSPKI(PUBLIC_KEY_PEM, 'EdDSA');
      } catch (err) {
        throw new Error("Không thể khởi tạo bộ giải mã bảo mật.");
      }

      const { payload } = await jwtVerify(token, publicKey, {
        issuer: 'st-tvc-license-server',
        audience: 'st-tvc-flow-offline',
        algorithms: ['EdDSA'],
        clockTolerance: 60
      });

      const mid = machineId.trim().toUpperCase();
      if (payload.p !== PRODUCT_ID) throw new Error("Mã không dành cho app này.");
      if (payload.m !== mid) throw new Error("Mã này thuộc về máy tính khác.");
      if (typeof payload.exp !== 'number' || payload.exp <= Math.floor(Date.now() / 1000)) throw new Error("Mã đã hết hạn.");

      return {
        key: normalizedKey,
        machineId: mid,
        licenseName: String(payload.l),
        expiresAt: Number(payload.exp),
        issuedAt: Number(payload.iat)
      };
    } catch (jwtErr: any) {
      if (jwtErr.code === 'ERR_JWT_EXPIRED') throw new Error("Mã bản quyền đã hết hạn.");
      throw new Error(jwtErr.message || "Mã bản quyền không hợp lệ hoặc bị lỗi định dạng.");
    }
  }
};
