import { Flow } from 'flow-sdk';
import { 
  VoiceMaster, 
  ProductAnalysis 
} from '../types';
import { 
  IDENTITY_PROMPT_BLOCK, 
  NEGATIVE_CONSTRAINTS, 
  TWO_HAND_LOCK_BLOCK,
  POV_HAND_BLOCK,
  buildIdentityContext 
} from './PromptService';
import { VoiceService } from './VoiceService';

export const resolveMediaId = (media: any): string | null => {
  if (!media) return null;
  if (typeof media === 'string') return media;
  return media.mediaId || media.media_id || media.id || null;
};

export const getCanonicalModelName = (uiLabel: string): string => {
  const map: Record<string, string> = {
    "Omni Flash": "Omni 1.1 Flash",
    "Veo 3.1 - Fast": "Veo 3.1 - Fast",
    "Veo 3.1 - Lite": "Veo 3.1 - Lite",
    "Veo 3.1 - Quality": "Veo 3.1 - Quality",
    "Veo 3.1 - Lite [Lower Priority]": "Veo 3.1 - Lite [Lower Priority]"
  };
  return map[uiLabel] || uiLabel;
};

/**
 * Chuẩn hóa thời lượng video về các mốc Flow SDK hỗ trợ
 */
const snapDuration = (requestedSeconds: number, model: string, hasRefs: boolean): number => {
  if (model.includes("Omni")) {
    if (requestedSeconds <= 5) return 4;
    if (requestedSeconds <= 7) return 6;
    if (requestedSeconds <= 9) return 8;
    return 10;
  }
  
  if ((model.includes("Lite") || model.includes("Fast")) && hasRefs) {
    return 8;
  }

  if (requestedSeconds <= 5) return 4;
  if (requestedSeconds <= 7) return 6;
  return 8;
};

export interface GenerationOptions {
  modelLabel: string;
  voiceMaster: VoiceMaster;
  handAction: string;
  aspectRatio: '9:16' | '16:9';
  isDraft?: boolean;
}

export interface GenerationResult {
  base64: string;
  mimeType: string;
  mediaId: string;
  compatibilityFallback: boolean;
}

export const VideoGenerationService = {
  async generateSceneVideo(
    scene: any, 
    analysis: ProductAnalysis | null, 
    references: any[], 
    options: GenerationOptions
  ): Promise<GenerationResult> {
    const { modelLabel, voiceMaster, handAction, aspectRatio, isDraft } = options;
    const selectedModel = getCanonicalModelName(modelLabel);
    
    const dialogue = scene.voiceOver || scene.lockedVoiceOver || '';
    const cleanDialogue = dialogue.trim().replace(/\s+/g, ' ');
    const { voiceInstruction } = await VoiceService.synthesizeSpeech(cleanDialogue, voiceMaster);
    const identityContext = buildIdentityContext(analysis);

    // Xử lý Component Binding cụ thể cho video prompt
    const bindings = (scene.assetBindings || []).map((b: any) => {
      const comp = analysis?.componentCatalog.find(c => c.id === b.componentId);
      return `Visual Rule: Use feminine adult woman's hands to ${b.visualAction} on the ${comp?.name} (${comp?.packagingForm}).`;
    }).join(' ');

    const basePrompt = scene.videoPrompt || scene.prompt || scene.framePrompt || scene.heroAction || '';
    const corePrompt = `
      TikTok POV snack review video. 
      CORE ACTION: ${basePrompt}. 
      ${bindings}
      HAND SETTING: ${handAction === 'AUTO' ? 'Appetizing review movements' : handAction}.
      DIALOGUE LOCK: "${cleanDialogue}".
      VOICE INSTR: ${voiceInstruction}
      ${identityContext}
      ${IDENTITY_PROMPT_BLOCK}
      STRICT: Hand must be adult woman's, natural feminine nails. Finger-based pick/dip only. No utensils.
      Negative Prompt: ${NEGATIVE_CONSTRAINTS}
    `.trim();

    const storyboardId = resolveMediaId(scene.storyboardImage);
    const productMediaIds = references.map(r => resolveMediaId(r)).filter(Boolean) as string[];
    const foodIdx = Number(analysis?.foodContentMaster?.sourceReference) - 1;
    const foodId = resolveMediaId(references[foodIdx]);
    
    let requestedDuration = 6;
    const timeMatch = (scene.timeRange || '').match(/(\d+)s-(\d+)s/);
    if (timeMatch) requestedDuration = parseInt(timeMatch[2]) - parseInt(timeMatch[1]);

    const isQuality = selectedModel.includes("Quality");
    const isOmni = selectedModel.includes("Omni");

    const executeWithRetry = async (attempt: number = 1): Promise<GenerationResult> => {
      let firstFrameId: string | undefined = undefined;
      let referenceIds: string[] | undefined = undefined;

      if (isQuality) {
        firstFrameId = storyboardId || undefined;
      } else if (isOmni) {
        const pkgIdx = Number(analysis?.packageMaster?.sourceReference) - 1;
        const pkgId = resolveMediaId(references[pkgIdx]);
        const allRefs = [storyboardId, foodId, pkgId, ...productMediaIds].filter(Boolean) as string[];
        const uniqueRefs = Array.from(new Set(allRefs));

        if (attempt === 1) {
          referenceIds = uniqueRefs.slice(0, 7);
        } else if (attempt === 2) {
          referenceIds = uniqueRefs.slice(0, 3);
        } else {
          const fallback = [storyboardId, foodId].filter(Boolean).slice(0, 1) as string[];
          if (fallback.length === 0) {
            throw new Error("Không có ảnh tham chiếu hợp lệ để thử lại chế độ tương thích.");
          }
          referenceIds = fallback;
        }
      } else {
        const allRefs = [storyboardId, ...productMediaIds].filter(Boolean) as string[];
        referenceIds = Array.from(new Set(allRefs)).slice(0, 3);
      }

      if (firstFrameId && referenceIds) {
        referenceIds = undefined;
      }

      const finalDuration = snapDuration(requestedDuration, selectedModel, !!referenceIds);
      const payload: any = {
        prompt: corePrompt,
        modelDisplayName: selectedModel,
        aspectRatio: aspectRatio,
        durationSeconds: finalDuration,
      };

      if (firstFrameId) payload.firstFrameImageMediaId = firstFrameId;
      if (referenceIds && referenceIds.length > 0) payload.referenceImageMediaIds = referenceIds;
      if (isDraft && isOmni) payload.resolution = '360p';

      try {
        const res = await Flow.generate.video(payload);
        return {
          ...res,
          compatibilityFallback: attempt > 1
        };
      } catch (err: any) {
        const errMsg = (err.message || "").toLowerCase();
        const isNonRetryable = /safety|policy|credit|quota|license|expired/.test(errMsg);

        if (!isNonRetryable && isOmni) {
          const currentRefCount = referenceIds?.length || 0;
          if (attempt === 1 && currentRefCount > 3) return executeWithRetry(2);
          else if (attempt < 3 && currentRefCount > 1) return executeWithRetry(3);
        }

        let friendlyError = "Lỗi hệ thống khi tạo video.";
        if (isNonRetryable) {
          if (errMsg.includes("safety") || errMsg.includes("policy")) {
            friendlyError = "Nội dung bị chặn do chính sách an toàn. Hãy thử chỉnh sửa kịch bản hoặc ảnh.";
          } else if (errMsg.includes("credit") || errMsg.includes("quota")) {
            friendlyError = "Tài khoản không đủ credit hoặc đã hết hạn mức.";
          } else if (errMsg.includes("license") || errMsg.includes("expired")) {
            friendlyError = "Phiên bản quyền đã hết hạn hoặc không khả dụng.";
          }
        } else {
          const finalRefCount = referenceIds?.length || 0;
          friendlyError = `Omni không thể tạo video sau khi đã thử chế độ tương thích (${finalRefCount} ảnh). Vui lòng kiểm tra lại ảnh phác thảo hoặc đổi mô hình khác.`;
        }
        
        throw new Error(friendlyError);
      }
    };

    return await executeWithRetry(1);
  }
};
