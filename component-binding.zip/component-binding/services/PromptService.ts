import { Flow } from 'flow-sdk';
import { MasterScriptData, StoryboardData, StoryboardScene, ProductAnalysis, VoiceMaster } from '../types';

/**
 * Utility to safely extract and parse JSON from AI text responses.
 */
export function safeExtractJson(input: any) {
  if (!input) throw new Error('AI returned an empty response.');
  if (typeof input === 'object') return input;

  let text = String(input).trim();
  text = text.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();

  try {
    return JSON.parse(text);
  } catch (error) {
    const firstBrace = text.indexOf('{');
    const lastBrace = text.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      try {
        return JSON.parse(text.slice(firstBrace, lastBrace + 1));
      } catch (e) {}
    }
  }
  throw new Error('Không thể parse JSON từ AI response.');
}

const cleanText = (value: any) => {
  if (
    typeof value !== 'string' ||
    !value.trim() ||
    value.trim() === '.' ||
    value.trim() === '()'
  ) {
    return 'Chưa xác định';
  }
  return value.trim();
}

/**
 * Normalizes raw product analysis into a structured ProductAnalysis object.
 */
export const normalizeAnalysis = (raw: any): ProductAnalysis => ({
  references: Array.isArray(raw?.references) ? raw.references : [],
  componentCatalog: Array.isArray(raw?.componentCatalog) ? raw.componentCatalog : [],
  packageMaster: {
    status: raw?.packageMaster?.status || 'NOT_AVAILABLE',
    sourceReference: raw?.packageMaster?.sourceReference ?? null,
    packagingDescription: cleanText(raw?.packageMaster?.packagingDescription),
    material: cleanText(raw?.packageMaster?.material),
    shape: cleanText(raw?.packageMaster?.shape),
    colors: cleanText(raw?.packageMaster?.colors),
    labelAndBranding: cleanText(raw?.packageMaster?.labelAndBranding)
  },
  foodContentMaster: {
    status: raw?.foodContentMaster?.status || 'NOT_AVAILABLE',
    sourceReference: raw?.foodContentMaster?.sourceReference ?? null,
    productType: cleanText(raw?.foodContentMaster?.productType),
    shapeAndSize: cleanText(raw?.foodContentMaster?.shapeAndSize),
    surfaceTexture: cleanText(raw?.foodContentMaster?.surfaceTexture),
    colorAndSeasoning: cleanText(raw?.foodContentMaster?.colorAndSeasoning),
    internalStructure: cleanText(raw?.foodContentMaster?.internalStructure),
    physicalBehavior: cleanText(raw?.foodContentMaster?.physicalBehavior || 'Ổn định')
  },
  environmentMaster: {
    status: raw?.environmentMaster?.status || 'NOT_AVAILABLE',
    sourceReference: raw?.environmentMaster?.sourceReference ?? null,
    tabletopAndSpace: cleanText(raw?.environmentMaster?.tabletopAndSpace),
    background: cleanText(raw?.environmentMaster?.background),
    lighting: cleanText(raw?.environmentMaster?.lighting),
    backgroundObjects: Array.isArray(raw?.environmentMaster?.backgroundObjects) ? raw.environmentMaster.backgroundObjects : [],
    visualStyle: cleanText(raw?.environmentMaster?.visualStyle)
  }
});

export const SNACK_SPECIFIC_BLOCK = `
[STRICT SNACK CONTEXT]
Primary Food Content source image wins over product name or descriptive text.
Match visual truth exactly: do not infer different formats.
STRICT: Keep no live/raw/underwater elements. No ocean backgrounds.
`;

export const TWO_HAND_LOCK_BLOCK = `
[STRICT ANATOMY & POV HAND LOCK]
- ONE consistent pair of adult woman's hands only.
- Feminine hands, clean natural nails, soft skin.
- Max TWO human hands total. No third hand.
- No face, no body, no second person, no crowd.
- Natural Vietnamese food-review gestures.
`;

export const APPETIZING_ACTION_BLOCK = `
[STRICT APPETIZING GESTURES]
- Prioritize finger-based interaction: picking a small piece, lifting a strand/piece, gentle pull to show texture, dipping in sauce, or holding close to camera.
- No utensils (forks, spoons, chopsticks) unless the reference image explicitly shows them.
- Interaction must look delicious, natural, and sensory-focused.
`;

export const COMPONENT_BINDING_LOCK = `
[STRICT COMPONENT BINDING]
- If asset is "food" or "loose": use feminine fingers to pick/lift the actual food content.
- If asset is "jar": hand holds or opens the specific jar from reference.
- If asset is "packet": hand holds or lifts the specific packet from reference.
- If asset is "box": hand opens or holds the specific box from reference.
- NEVER mix actions: do not pick a packet as if it were food. 
`;

export const POV_HAND_BLOCK = `
[POV HAND CONSTRAINTS]
First-person POV reviewer. Hands enter naturally from bottom or side frame edges.
${TWO_HAND_LOCK_BLOCK}
${APPETIZING_ACTION_BLOCK}
`;

export const IDENTITY_PROMPT_BLOCK = `
[VISUAL PURITY LOCK]
Clean commercial frame only. No TikTok logos/watermarks.
${POV_HAND_BLOCK}
[STRICT IDENTITY MASTERS]
The reference images provide the supreme visual truth for product, package, and logo. 
STRICT: Never redesign or invent labels. Match packaging material (jar/packet/box) exactly.
${COMPONENT_BINDING_LOCK}
`;

export const NEGATIVE_CONSTRAINTS = "male hands, masculine hands, extra hands, third hand, helper hand, gloves, utensils, silverware, fork, spoon, TikTok watermark, TikTok logo, face, selfie, person, crowd, ocean, underwater.";

export const buildIdentityContext = (analysis: ProductAnalysis | null): string => {
  if (!analysis) return "";
  const food = analysis.foodContentMaster;
  const pkg = analysis.packageMaster;
  const env = analysis.environmentMaster;
  
  return `
    [STRICT IDENTITY DATA]
    - Product: ${food.productType}. Texture: ${food.surfaceTexture}. Shape: ${food.shapeAndSize}.
    - Packaging: ${pkg.packagingDescription}. Form: ${pkg.shape}. branding: ${pkg.labelAndBranding}.
    - Environment: ${env.tabletopAndSpace}. Visual Style: ${env.visualStyle}.
  `;
};

const resolveMediaIdInternal = (media: any): string | null => {
  if (!media) return null;
  if (typeof media === 'string') return media;
  return media.mediaId || media.media_id || media.id || null;
};

export const PromptService = {
  getFriendlyErrorMessage(err: any): string {
    const msg = String(err?.message || err || "").toLowerCase();
    if (msg.includes("safety") || msg.includes("policy")) return "Nội dung hoặc ảnh bị chặn do chính sách an toàn.";
    if (msg.includes("credit") || msg.includes("quota")) return "Hết credit hoặc vượt hạn mức sử dụng.";
    if (msg.includes("license") || msg.includes("expired")) return "Bản quyền hết hạn hoặc không hợp lệ.";
    return "Không thể hoàn thành yêu cầu. Vui lòng thử lại.";
  },

  async analyzeProduct({ productName, productDesc, references }: any): Promise<ProductAnalysis> {
    const systemInstruction = `
      You are a Product Analysis Expert for commercial media production.
      Analyze the provided reference images to extract a high-fidelity "Identity Master".
      
      STRICT: Identify every unique object (product components, different packages, sauce cups, etc.) to create a "componentCatalog".
      - packagingForm: Must be "jar", "packet", "box", "bottle", "loose", or "bowl".
      - aliases: List common terms in Vietnamese like "hũ bơ", "gói hành", "miếng bánh" that refer to that object.
      
      Return VALID JSON ONLY (Vietnamese strings):
      {
        "references": [ { "referenceIndex": 1, "detectedRoles": ["package"], "summary": "..." } ],
        "componentCatalog": [
          { "id": "obj1", "name": "Tên vật thể", "sourceReference": 1, "packagingForm": "packet", "aliases": ["gói nhỏ", "bịch gia vị"] }
        ],
        "packageMaster": { "status": "LOCKED", "sourceReference": 1, "packagingDescription": "...", "material": "...", "shape": "...", "colors": "...", "labelAndBranding": "..." },
        "foodContentMaster": { "status": "LOCKED", "sourceReference": 2, "productType": "...", "shapeAndSize": "...", "surfaceTexture": "...", "colorAndSeasoning": "...", "internalStructure": "...", "physicalBehavior": "..." },
        "environmentMaster": { "status": "LOCKED", "sourceReference": 3, "tabletopAndSpace": "...", "background": "...", "lighting": "...", "backgroundObjects": [], "visualStyle": "..." }
      }
    `;
    
    const validReferences = references.map((r: any, idx: number) => r ? { base64: r.base64, mimeType: r.mimeType, index: idx + 1 } : null).filter(Boolean);
    const images = validReferences.map((r: any) => ({ base64: r.base64, mimeType: r.mimeType }));

    const prompt = `Product: ${productName || 'Unspecified'}. Description: ${productDesc || 'Unspecified'}. Analyze these images and catalog all components.`;

    const { text } = await Flow.generate.text(prompt, { systemInstruction, images });
    return safeExtractJson(text);
  },

  async generateMasterScript({ analysis, productName, productDesc, duration, voiceMaster, handAction }: any): Promise<MasterScriptData> {
    const totalSec = parseInt(duration) || 24;
    const secPerScene = totalSec / 4;
    const wordsPerSec = 3.5 * voiceMaster.speakingSpeed;
    const maxWords = Math.floor((secPerScene - 1) * wordsPerSec);

    const catalog = analysis?.componentCatalog || [];

    const systemInstruction = `
      You are a Viral TikTok Scriptwriter. Create a 4-scene POV script for ${duration}.
      Fit about ${maxWords} words per scene.

      STRICT COMPONENT RULES:
      - Use ONLY names or aliases from the "componentCatalog" provided below.
      - VoiceOver and suggestedAction MUST refer to these catalog objects by their specific names/aliases.
      
      STRICT PACKAGING ACTIONS:
      - Actions MUST match the "packagingForm" of the object:
        - if "packet": use "nhấc/cầm gói" (picks up/holds packet).
        - if "jar": use "cầm/mở hũ" (holds/opens jar).
        - if "box": use "mở/giơ hộp" (opens/holds box).
        - if "loose" or "food": use finger-based "bốc/nhấc miếng đồ ăn" (pick up piece with fingers).
      - Do not use utensils.

      Return VALID JSON ONLY (Vietnamese):
      {
        "coreIdea": "...", "heroSellingPoint": "...",
        "scenes": [ { "sceneNumber": 1, "voiceOver": "...", "timeRange": "0s-${secPerScene}s", "suggestedAction": "..." } ],
        "cta": "..."
      }
    `;

    const prompt = `
      Product: ${productName}. ${productDesc}. Hand Action: ${handAction}.
      ${buildIdentityContext(analysis)}
      
      COMPONENT CATALOG:
      ${JSON.stringify(catalog)}
    `;

    const { text } = await Flow.generate.text(prompt, { systemInstruction });
    return safeExtractJson(text);
  },

  async createStoryboardPlan({ analysis, scriptData, productName, references }: any): Promise<StoryboardData> {
    const systemInstruction = `
      You are a Storyboard Planner. 
      ${IDENTITY_PROMPT_BLOCK}
      
      CRITICAL: Link words in the "voiceOver" to components in the "componentCatalog".
      Create "assetBindings" for each scene:
      - visualAction: Specific appetizing action using female fingers (no utensils). 
        - if packagingForm is "packet": "female hand picks up packet".
        - if packagingForm is "food": "female fingers pick up one piece appetizingly".
      
      Return VALID JSON ONLY:
      {
        "scenes": [
          {
            "sceneNumber": 1,
            "visualProofGoal": "...",
            "heroAction": "...",
            "camera": "...",
            "assetBindings": [
              { "spokenTerm": "hũ bơ", "componentId": "obj1", "sourceReference": 1, "visualAction": "female hand opens lid of the jar" }
            ],
            "mustShow": ["..."],
            "mustNotShow": ["..."]
          }
        ]
      }
    `;

    const orderedImages = references.filter(Boolean).map((r: any) => ({ base64: r.base64, mimeType: r.mimeType }));
    const prompt = `Plan 4 scenes for ${productName}. Catalog: ${JSON.stringify(analysis.componentCatalog)}. Script: ${JSON.stringify(scriptData.scenes)}.`;

    const { text } = await Flow.generate.text(prompt, { systemInstruction, images: orderedImages });
    const rawData = safeExtractJson(text);

    return {
      environmentMaster: analysis.environmentMaster,
      scenes: (rawData.scenes || []).map((s: any, idx: number) => {
        const master = scriptData.scenes[idx];
        
        const filteredBindings = (s.assetBindings || [])
          .map((b: any) => {
            const component = analysis.componentCatalog.find((c: any) => c.id === b.componentId);
            if (!component) return null;
            if (b.sourceReference !== component.sourceReference) return null;
            return { ...b, sourceReference: component.sourceReference };
          })
          .filter(Boolean);

        return { 
          ...s, 
          assetBindings: filteredBindings,
          inputReferenceIds: filteredBindings.map((b: any) => resolveMediaIdInternal(references[b.sourceReference - 1])).filter(Boolean),
          timeRange: master?.timeRange || "",
          heroAction: master?.suggestedAction || s.heroAction || "",
          voiceOver: master?.lockedVoiceOver || master?.voiceOver || "", 
          lockedVoiceOver: master?.lockedVoiceOver || master?.voiceOver || "", 
          storyboardImage: null, 
          generationStatus: 'pending' 
        };
      })
    };
  },

  async generateStoryboardFrame({ scene, analysis, references, aspectRatio = '9:16' }: any) {
    const assetBindings = scene.assetBindings || [];
    let referenceImageMediaIds = scene.inputReferenceIds || [];
    
    if (assetBindings.length > 0 && referenceImageMediaIds.length === 0) {
      const terms = assetBindings.map((b: any) => b.spokenTerm).join(', ');
      throw new Error(`Không thể tìm thấy hình ảnh phù hợp cho các vật thể được nhắc tới ("${terms}"). Vui lòng kiểm tra lại ảnh tham chiếu.`);
    }

    const currentIds = references.map((r: any) => resolveMediaIdInternal(r)).filter(Boolean);
    referenceImageMediaIds = Array.from(new Set(referenceImageMediaIds.filter((id: string) => currentIds.includes(id)))).slice(0, 3);

    const bindingContext = (scene.assetBindings || []).map((b: any) => {
      const comp = analysis.componentCatalog.find((c: any) => c.id === b.componentId);
      return `When voice says "${b.spokenTerm}", show ${comp?.name} (${comp?.packagingForm}). Action: ${b.visualAction}. MATCH REFERENCE ${b.sourceReference} EXACTLY.`;
    }).join(' ');

    const prompt = `
      [STRICT ASSET BINDING]
      ${bindingContext}
      Goal: ${scene.visualProofGoal}. Action: ${scene.heroAction}. Camera: ${scene.camera}. 
      ${IDENTITY_PROMPT_BLOCK}
      Negative Prompt: ${NEGATIVE_CONSTRAINTS}
    `.trim();

    try {
      return await Flow.generate.image({
        prompt,
        modelDisplayName: '🍌 Nano Banana Pro',
        aspectRatio,
        referenceImageMediaIds: referenceImageMediaIds as string[]
      });
    } catch (err: any) {
      throw new Error(this.getFriendlyErrorMessage(err));
    }
  },

  async generateFinalPlan(input: any) {
    const systemInstruction = `
      You are a Video Prompt Engineer. ${IDENTITY_PROMPT_BLOCK}
      Return VALID JSON: { "scenes": [ { "sceneNumber": 1, "prompt": "...", "action": "...", "camera": "..." } ] }
    `;
    const storyboardForText = input.storyboard.scenes.map(({ storyboardImage, ...scene }: any) => scene);
    const rawPrompt = `Analysis: ${JSON.stringify(input.analysis)} Storyboard: ${JSON.stringify(storyboardForText)}.`;
    
    const { text } = await Flow.generate.text(rawPrompt, { systemInstruction });
    const raw = safeExtractJson(text);
    const sourceScenes = Array.isArray(raw?.scenes) ? raw.scenes : Array.isArray(raw) ? raw : [];
    
    return sourceScenes.map((scene: any, index: number) => {
      const storyboardScene = input.storyboard.scenes[index];
      return {
        ...scene,
        sceneNumber: index + 1,
        timeRange: storyboardScene?.timeRange || '',
        action: scene?.action || storyboardScene?.heroAction || '',
        camera: scene?.camera || storyboardScene?.camera || '',
        voiceOver: storyboardScene?.lockedVoiceOver || '',
        storyboardImage: storyboardScene?.storyboardImage || null,
      };
    });
  }
};
