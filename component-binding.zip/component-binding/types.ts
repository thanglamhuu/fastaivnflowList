import { MediaItem } from 'flow-sdk';

export interface GeminiVoice {
  name: string;
  style: string;
}

export interface VietnameseVoice {
  value: string;
  label: string;
  gender: 'female' | 'male' | 'neutral';
  language: 'Vietnamese';
  description: string;
  supportsVietnamese: boolean;
}

export interface VoiceMaster {
  voiceName: string;
  baseStyle: string;
  language: string;
  accent: string;
  ageImpression: string;
  tone: string;
  delivery: string;
  speakingSpeed: number;
  customStyleInstruction: string;
}

export type MasterStatus = 'LOCKED' | 'PARTIAL' | 'NOT_AVAILABLE';

export interface PackageMaster {
  status: MasterStatus;
  sourceReference: number | null;
  packagingDescription: string;
  material: string;
  shape: string;
  colors: string;
  labelAndBranding: string;
}

export interface FoodContentMaster {
  status: MasterStatus;
  sourceReference: number | null;
  productType: string;
  shapeAndSize: string;
  surfaceTexture: string;
  colorAndSeasoning: string;
  internalStructure: string;
  physicalBehavior: string;
}

export interface EnvironmentMaster {
  status: MasterStatus;
  sourceReference: number | null;
  tabletopAndSpace: string;
  background: string;
  lighting: string;
  backgroundObjects: string[];
  visualStyle: string;
}

export interface ComponentCatalogEntry {
  id: string;
  name: string;
  sourceReference: number;
  packagingForm: string; // "jar", "packet", "box", "loose", etc.
  aliases: string[]; // Các từ thay thế như "hũ bơ", "gói hành"
}

export interface DetectedReference {
  referenceIndex: number;
  detectedRoles: ('package' | 'food_content' | 'environment' | 'hand_style' | 'serving_setup')[];
  summary: string;
}

export interface ProductAnalysis {
  references: DetectedReference[];
  componentCatalog: ComponentCatalogEntry[];
  packageMaster: PackageMaster;
  foodContentMaster: FoodContentMaster;
  environmentMaster: EnvironmentMaster;
}

export interface MasterScriptScene {
  sceneNumber: number;
  voiceOver: string;
  lockedVoiceOver?: string;
  timeRange?: string;
  durationSeconds?: number;
  suggestedAction?: string;
}

export interface MasterScriptData {
  coreIdea: string;
  heroSellingPoint: string;
  scenes: MasterScriptScene[];
  cta: string;
  isManual?: boolean;
}

export interface AssetBinding {
  spokenTerm: string;
  componentId: string;
  sourceReference: number;
  visualAction: string;
}

export type StoryboardStatus = 'DRAFT' | 'LOCKED';
export type SceneGenerationStatus = 'pending' | 'generating' | 'done' | 'error';

export interface StoryboardScene {
  sceneNumber: number;
  timeRange: string;
  storyRole: string;
  action: string;
  camera: string;
  framePrompt: string;
  voiceOver: string;
  lockedVoiceOver: string;
  spokenClaims: string[];
  visualProofGoal: string;
  heroAction: string;
  assetBindings?: AssetBinding[];
  mustShow: string[];
  mustNotShow: string[];
  storyboardImage: {
    mediaId: string;
    base64: string;
    mimeType: string;
  } | null;
  generationStatus: SceneGenerationStatus;
  generationError?: string;
  inputReferenceIds?: string[];
}

export interface StoryboardData {
  environmentMaster: EnvironmentMaster;
  scenes: StoryboardScene[];
}

export type TaskStatus = 'idle' | 'queued' | 'running' | 'completed' | 'failed';

export interface BatchTask {
  id: string;
  productName: string;
  references: (MediaItem | null)[];
  status: TaskStatus;
  progress: number;
  currentScene: number;
  error: string | null;
  result: {
    analysis: ProductAnalysis;
    script: MasterScriptData;
    storyboard: StoryboardData;
    finalScenes: any[];
  } | null;
}

export interface LicenseSession {
  key: string;
  machineId: string;
  licenseName: string;
  expiresAt: number;
  issuedAt: number;
  isOnline?: boolean;
  token?: string;
}

export const VIETNAMESE_VOICES: VietnameseVoice[] = [
  { value: "Linh", label: "Linh (Bắc)", gender: "female", language: "Vietnamese", description: "Giọng nữ miền Bắc trẻ trung, thanh lịch.", supportsVietnamese: true },
  { value: "Kim", label: "Kim (Bắc - Pro)", gender: "female", language: "Vietnamese", description: "Giọng nữ miền Bắc chuyên nghiệp, sắc sảo.", supportsVietnamese: true },
  { value: "Minh", label: "Minh (Bắc)", gender: "male", language: "Vietnamese", description: "Giọng nam miền Bắc trầm ấm, tin cậy.", supportsVietnamese: true },
  { value: "Thu", label: "Thu (Nam)", gender: "female", language: "Vietnamese", description: "Giọng nữ miền Nam ngọt ngào, dịu dàng.", supportsVietnamese: true },
  { value: "Nam", label: "Nam (Nam)", gender: "male", language: "Vietnamese", description: "Giọng nam miền Nam năng động, hiện đại.", supportsVietnamese: true },
  { value: "Mai", label: "Mai (Trung)", gender: "female", language: "Vietnamese", description: "Giọng nữ miền Trung truyền cảm, ấm áp.", supportsVietnamese: true },
  { value: "An", label: "An (Tây)", gender: "female", language: "Vietnamese", description: "Giọng nữ miền Tây dễ thương, gần gũi.", supportsVietnamese: true },
  { value: "Ngọc", label: "Ngọc (TikTok - High Energy)", gender: "female", language: "Vietnamese", description: "Giọng nữ trẻ năng lượng cao, cực kỳ bắt tai.", supportsVietnamese: true },
  { value: "Hiếu", label: "Hiếu (TikTok - Male)", gender: "male", language: "Vietnamese", description: "Giọng nam trẻ miền Nam, phong cách review TikTok.", supportsVietnamese: true },
  { value: "Phương", label: "Phương (TikTok - Female)", gender: "female", language: "Vietnamese", description: "Giọng nữ trẻ review tự nhiên, gần gũi.", supportsVietnamese: true },
  { value: "Hùng", label: "Hùng (Nam - Deep)", gender: "male", language: "Vietnamese", description: "Giọng nam miền Nam trầm, mạnh mẽ.", supportsVietnamese: true },
  { value: "Thảo", label: "Thảo (Nhẹ nhàng)", gender: "female", language: "Vietnamese", description: "Giọng nữ kể chuyện chậm rãi, nhẹ nhàng.", supportsVietnamese: true }
];

export const GEMINI_VOICES: GeminiVoice[] = [
  { name: "Zephyr", style: "Bright" },
  { name: "Puck", style: "Upbeat" },
  { name: "Charon", style: "Informative" },
  { name: "Kore", style: "Firm" },
  { name: "Fenrir", style: "Excitable" },
  { name: "Leda", style: "Youthful" },
  { name: "Orus", style: "Firm" },
  { name: "Aoede", style: "Breezy" },
  { name: "Callirrhoe", style: "Easy-going" },
  { name: "Autonoe", style: "Bright" },
  { name: "Enceladus", style: "Breathy" },
  { name: "Iapetus", style: "Clear" },
  { name: "Umbriel", style: "Easy-going" },
  { name: "Algieba", style: "Smooth" },
  { name: "Despina", style: "Smooth" },
  { name: "Erinome", style: "Clear" },
  { name: "Algenib", style: "Gravelly" },
  { name: "Rasalgethi", style: "Informative" },
  { name: "Laomedeia", style: "Upbeat" },
  { name: "Achernar", style: "Soft" },
  { name: "Alnilam", style: "Firm" },
  { name: "Schedar", style: "Even" },
  { name: "Gacrux", style: "Mature" },
  { name: "Pulcherrima", style: "Forward" },
  { name: "Achird", style: "Friendly" },
  { name: "Zubenelgenubi", style: "Casual" },
  { name: "Vindemiatrix", style: "Gentle" },
  { name: "Sadachbia", style: "Lively" },
  { name: "Sadaltager", style: "Knowledgeable" },
  { name: "Sulafat", style: "Warm" }
];
